#! /bin/sh
db2pdf -d presentacion.dsl\#print "$@"
