from Tkinter import *

class agendatk:
    def __init__(self,mod_bd):
        #Nuestra capa de BD es una clase que nos pasan en el constructor
        self.db=mod_bd()
        #Contruimos el interfaz gr�fico
        self.r=Tk()
        self.t=Entry(self.r)
        self.t.pack()
        self.res=Label(self.r,text='Sin resultados')
        self.res.pack()
        Button(self.r,text='Buscar',command=self.busca).pack()
        Button(self.r,text='Encontrar',command=self.encuentra).pack()

    def run(self):
        self.r.mainloop()

    def busca(self):
        texto=self.t.get()
        ret=self.db.busca(texto) or []
        for elem in ret:
            texto = texto + '\n%s = %s - %s ' % (elem[0] , elem[1][0], elem[1][1])
        self.res.configure(text=texto)
        
    def encuentra(self):
        texto=self.t.get()
        ret=self.db.encuentra(texto)
        self.res.configure(text='%s - %s' % ret)

if __name__=='__main__':
    #OJO: Este m�dulo s�lo se importa si se va a usar
    import agendadb
    agtk=agendatk(agendadb.agenda)
    agtk.run()
