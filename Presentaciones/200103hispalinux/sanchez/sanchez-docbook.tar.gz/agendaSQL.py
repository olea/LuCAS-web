import string
class agenda:
    def __init__(self,modDB,info):
        self.db=modDB.connect(info)
        self.db.autoCommit(1)
    def volcado(self):
        ret=[]
        for k in self.db.keys():
            ret.append( (k,self.db[k]) )
        return ret
        
    def encuentra(self, clave):
        clave=string.upper(str(clave))
        cur=self.db.cursor()
        cur.execute('''select clave,nombre,direccion
                            from agenda
                            where clave='%s' ''' % clave)
        k=cur.fetchall()
        cur.close()
        if k:
            k=k[0]
            return (k[0],(k[1],k[2]))
        else:
            return None
        
    def busca(self, clave):
        clave='%'+string.upper(str(clave))+'%'
        cur=self.db.cursor()
        cur.execute('''select clave,nombre,direccion
                            from agenda
                            where clave like '%s' ''' % clave)
        ret=[]
        for k in cur.fetchall():
            ret.append( (k[0],(k[1],k[2])) )
        return ret
    def nuevo(self,clave,contenido):
        clave=string.upper(str(clave))
        nombre,direccion=contenido
        cur=self.db.cursor()
        cur.execute('''insert into agenda(clave,nombre,direccion)
                            values('%s','%s','%s')''' % (clave,nombre,direccion) )
        cur.close()


if __name__=='__main__':
    import PoPy 
    
    import pprint
    ag=agenda(PoPy,'dbname=template1')
    try:
        cur=ag.db.cursor()
        cur.execute('select * from agenda')
        cur.close()
    except:
        print 'creando tabla agenda'
        cur=ag.db.cursor()
        cur.execute("""create table agenda(
                                    clave varchar(255) not null,
                                    nombre varchar(255),
                                    direccion varchar(255) )""")
        print 'creando clave'
        cur=ag.db.cursor()
        cur.execute('create index agenda_pk on agenda(clave)')
        print 'insertando datos de prueba'
        ag.nuevo('ErnestoBKE', ('SQL Ernesto Molina','emolina@grupoburke.com'))
        ag.nuevo('Ernesto', ('SQL Ernesto Molina','rotoxl@jazzfree.com'))
        ag.nuevo('MarcosBKE', ('SQL Marcos S�nchez','msanchez@grupoburke.com'))
        ag.nuevo('Marcos', ('SQL Marcos S�nchez','rapto@arrakis.es'))
    print ag.encuentra('Ernesto')
    pprint.pprint (ag.busca('BKE'))
    ag.db.close()
    
