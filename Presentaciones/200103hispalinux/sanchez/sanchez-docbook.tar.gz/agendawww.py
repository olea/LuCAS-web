from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer,test
import cgi
import string


class AgendaHTTP(BaseHTTPRequestHandler):
	def do_GET(self):
		self.do_HEAD()
		if self.response==404:
			self.wfile.write('404 El m�todo no existe' )
			return
		if self.metodo=='/busca':
			try:
				ret=db.busca(self.dicParams['param'][0])
			except:
				ret=[]
			retHTML=''
			for elem in ret:
				retHTML=retHTML+'<li>%s = %s-%s' % (elem[0],elem[1][0],elem[1][1])
			self.wfile.write('''<html><body>
					<form><input name="param"> <input type="submit"></form>
					<p>Resultados</p>
					<ul>%s</ul>
					</body></html>''' % retHTML)
	def do_HEAD(self):
		if '?' in self.path:
			self.metodo, params=string.split(self.path,'?')
		else:
			self.metodo, params= self.path,''
		self.dicParams=cgi.parse_qs(params)
		if self.metodo in ['/busca']:
			self.response=200
		else:
			self.response=404
		self.send_response(self.response)
		self.send_header("Content-type", 'text/html')
		self.end_headers()
def run(db,host='localhost',port=8000):
    httpd = HTTPServer( (host, port) , AgendaHTTP)
    print "Serving HTTP on port", port, "..."
    httpd.serve_forever()

if __name__=='__main__':
    import sys
    if sys.argv==['sql']:
        import agendaSQL
        import PoPy
        db=agendaSQL.agenda(PoPy,'dbname=template1')
    else:
        import agendadb	
        db=agendadb.agenda()
    run(db)