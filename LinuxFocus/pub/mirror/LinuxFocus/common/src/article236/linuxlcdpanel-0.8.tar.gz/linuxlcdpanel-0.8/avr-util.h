/* vim: set sw=8 ts=8 si : */
/*************************************************************************
 Title	:   C include file for avr utilities routines
 Target:    any AVR device
 Copyright: GPL
***************************************************************************/
#ifndef AVRUTIL_H
#define AVRUTIL_H

extern void delay_ms(unsigned int ms); /* delay ms */
extern void delay_us(unsigned int us); /* delay us */


#endif //AVRUTIL_H
