/* Terminal.h, Uros Platise (c) 1999 */

#ifndef __TERMINAL
#define __TERMINAL

class TTerminal{
public:
  void Run(); 
  TTerminal(){}
  ~TTerminal(){}
};

#endif
