/*********************************************
* vim: set sw=8 ts=8 si :
* Author: Guido Socher, Copyright: GPL 
* This program is to test the led connected to
* PC5 and to display a string on the LCD
* See http://linuxfocus.org/English/September2002/
* for details.
* Chip type           : AT90S4433
* Clock frequency     : 4,19 MHz
*********************************************/
#include <io.h>
#include <progmem.h>
#include <interrupt.h>
#include <string-avr.h>
#include <stdlib.h>
#include <sig-avr.h>
#include "lcd.h" 
#include "avr-util.h" 
#include "uart.h"


#define reply_ok() uart_sendstr_P("ok\n")
#define reply_err() uart_sendstr_P("err\n")


void main(void)
{
	/* initialize display, cursor off */
	lcd_init(LCD_DISP_ON);

	/* initialize rs232 */
	uart_init();

	/* enable  PC5 as output */
	sbi(DDRC,PC5);
	sei(); /* enable interrupt */
	lcd_puts_P("Hello");
	while (1) {
		/* led on, pin=0 */
		cbi(PORTC,PC5);
		delay_ms(500);
		/* set output to 5V, LED off */
		sbi(PORTC,PC5);
		reply_ok();
		delay_ms(500);
	}
}

