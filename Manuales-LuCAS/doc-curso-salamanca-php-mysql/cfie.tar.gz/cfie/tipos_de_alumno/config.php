<?php
//ponemos el nombre del servidor de mysql
$server= 'localhost';
//ponemos el nombre de la bbdd
$database='cfie';
//ponemos el nombre del usuario
$user='root';
//ponemos la contraseña del usuario
$passwd='sta3war2';
?>