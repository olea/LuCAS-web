<html>
<head>
<TITLE>
Gestión de Matrículas
</TITLE>
<LINK REL="stylesheet" TYPE="text/css" HREF="estilo.css">
</head>
<body>
<A href="alumnos/index.php" name="alumnos">Gestión de alumnos</A><br>
<A href="asignaturas/index.php" name="asignaturas">Gestión de asignaturas</A><BR>
<A href="tipos_de_alumno/index.php" name="tipos_de_alumno">Gestión de tipos de alumno</A><BR>
</body>
</html>
