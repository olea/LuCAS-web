# LaTeX2HTML 2002 (1.62)
# Associate labels original text with physical files.


$key = q/table-scsi-devices/;
$external_labels{$key} = "$URL/" . q|node288.html|; 
$noresave{$key} = "$nosave";

$key = q/table-ide-device-drivers/;
$external_labels{$key} = "$URL/" . q|node288.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-generic-x/;
$external_labels{$key} = "$URL/" . q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-adv-using-dip/;
$external_labels{$key} = "$URL/" . q|node354.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-sysadm/;
$external_labels{$key} = "$URL/" . q|node279.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-resolve.conf/;
$external_labels{$key} = "$URL/" . q|node347.html|; 
$noresave{$key} = "$nosave";

$key = q/example-sysadm-fstab/;
$external_labels{$key} = "$URL/" . q|node287.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-uucp/;
$external_labels{$key} = "$URL/" . q|node381.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-tape-backups/;
$external_labels{$key} = "$URL/" . q|node309.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-zip-backup/;
$external_labels{$key} = "$URL/" . q|node308.html|; 
$noresave{$key} = "$nosave";

$key = q/table-dev-settings/;
$external_labels{$key} = "$URL/" . q|node208.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-tcpip/;
$external_labels{$key} = "$URL/" . q|node339.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-filesystem-tour/;
$external_labels{$key} = "$URL/" . q|node241.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-intro-num/;
$external_labels{$key} = "$URL/" . q|node14.html|; 
$noresave{$key} = "$nosave";

$key = q/app-vendor-num/;
$external_labels{$key} = "$URL/" . q|node410.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-manage-links/;
$external_labels{$key} = "$URL/" . q|node254.html|; 
$noresave{$key} = "$nosave";

$key = q/table-redhat-space-requirements/;
$external_labels{$key} = "$URL/" . q|node144.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-manage-groups/;
$external_labels{$key} = "$URL/" . q|node296.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-tutorial/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/installation-slackware/;
$external_labels{$key} = "$URL/" . q|node160.html|; 
$noresave{$key} = "$nosave";

$key = q/dirtree/;
$external_labels{$key} = "$URL/" . q|node227.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-adv-slip-dip/;
$external_labels{$key} = "$URL/" . q|node351.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-ls/;
$external_labels{$key} = "$URL/" . q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-ppp/;
$external_labels{$key} = "$URL/" . q|node355.html|; 
$noresave{$key} = "$nosave";

$key = q/table-ftp-sites/;
$external_labels{$key} = "$URL/" . q|node409.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-init-scripts/;
$external_labels{$key} = "$URL/" . q|node277.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-manage-users/;
$external_labels{$key} = "$URL/" . q|node291.html|; 
$noresave{$key} = "$nosave";

$key = q/table-disk-formats/;
$external_labels{$key} = "$URL/" . q|node306.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-networking/;
$external_labels{$key} = "$URL/" . q|node338.html|; 
$noresave{$key} = "$nosave";

$key = q/table-slackware-scsi-ide-boot-images/;
$external_labels{$key} = "$URL/" . q|node177.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-process/;
$external_labels{$key} = "$URL/" . q|node258.html|; 
$noresave{$key} = "$nosave";

$key = q/table-debian-install-floppies/;
$external_labels{$key} = "$URL/" . q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-sysadm-upgrade/;
$external_labels{$key} = "$URL/" . q|node311.html|; 
$noresave{$key} = "$nosave";

$key = q/ftape-module/;
$external_labels{$key} = "$URL/" . q|node314.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-source-mailing-list/;
$external_labels{$key} = "$URL/" . q|node52.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-install-num/;
$external_labels{$key} = "$URL/" . q|node54.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-set-host_name/;
$external_labels{$key} = "$URL/" . q|node320.html|; 
$noresave{$key} = "$nosave";

$key = q/app-ftplist-num/;
$external_labels{$key} = "$URL/" . q|node402.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-bootfloppy/;
$external_labels{$key} = "$URL/" . q|node281.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-news/;
$external_labels{$key} = "$URL/" . q|node384.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-getting-internet/;
$external_labels{$key} = "$URL/" . q|node409.html|; 
$noresave{$key} = "$nosave";

$key = q/table-redhat-packages/;
$external_labels{$key} = "$URL/" . q|node142.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-job-control/;
$external_labels{$key} = "$URL/" . q|node257.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-lilo/;
$external_labels{$key} = "$URL/" . q|node283.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-inittab/;
$external_labels{$key} = "$URL/" . q|node285.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-swap-file/;
$external_labels{$key} = "$URL/" . q|node290.html|; 
$noresave{$key} = "$nosave";

$key = q/kernel-ppa-driver/;
$external_labels{$key} = "$URL/" . q|node313.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-S.u.S.E./;
$external_labels{$key} = "$URL/" . q|node198.html|; 
$noresave{$key} = "$nosave";

$key = q/app-sourc-ldp-home-page/;
$external_labels{$key} = "$URL/" . q|node387.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-manage-fs/;
$external_labels{$key} = "$URL/" . q|node286.html|; 
$noresave{$key} = "$nosave";

$key = q/app-gpl/;
$external_labels{$key} = "$URL/" . q|node413.html|; 
$noresave{$key} = "$nosave";

$key = q/gnu-license/;
$external_labels{$key} = "$URL/" . q|node413.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-checking-file-system/;
$external_labels{$key} = "$URL/" . q|node289.html|; 
$noresave{$key} = "$nosave";

$key = q/table-slackware-ide-boot-images/;
$external_labels{$key} = "$URL/" . q|node177.html|; 
$noresave{$key} = "$nosave";

$key = q/app-gpl-num/;
$external_labels{$key} = "$URL/" . q|node413.html|; 
$noresave{$key} = "$nosave";

$key = q/table-fs-types/;
$external_labels{$key} = "$URL/" . q|node287.html|; 
$noresave{$key} = "$nosave";

$key = q/table-debian-archive-structure/;
$external_labels{$key} = "$URL/" . q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-tutorial-num/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-file-perms/;
$external_labels{$key} = "$URL/" . q|node249.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-sysadm-shutdown/;
$external_labels{$key} = "$URL/" . q|node284.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-advanced-xconfiguration/;
$external_labels{$key} = "$URL/" . q|node334.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-generic-fdisk/;
$external_labels{$key} = "$URL/" . q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table-tape-devices/;
$external_labels{$key} = "$URL/" . q|node309.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-rc/;
$external_labels{$key} = "$URL/" . q|node319.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-mice/;
$external_labels{$key} = "$URL/" . q|node61.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-upgrade-libs/;
$external_labels{$key} = "$URL/" . q|node315.html|; 
$noresave{$key} = "$nosave";

$key = q/table-debian-package-fields/;
$external_labels{$key} = "$URL/" . q|node101.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-perms/;
$external_labels{$key} = "$URL/" . q|node249.html|; 
$noresave{$key} = "$nosave";

$key = q/app-info/;
$external_labels{$key} = "$URL/" . q|node385.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-walking-redhat/;
$external_labels{$key} = "$URL/" . q|node151.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-xwindow/;
$external_labels{$key} = "$URL/" . q|node327.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-msdos-mount/;
$external_labels{$key} = "$URL/" . q|node239.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-create-account/;
$external_labels{$key} = "$URL/" . q|node220.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-video-card-info/;
$external_labels{$key} = "$URL/" . q|node335.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-maint-diskette/;
$external_labels{$key} = "$URL/" . q|node322.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-floppy/;
$external_labels{$key} = "$URL/" . q|node310.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-xwindows-reqs/;
$external_labels{$key} = "$URL/" . q|node328.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-vi/;
$external_labels{$key} = "$URL/" . q|node261.html|; 
$noresave{$key} = "$nosave";

$key = q/app-sources-num/;
$external_labels{$key} = "$URL/" . q|node385.html|; 
$noresave{$key} = "$nosave";

$key = q/app-tldpes/;
$external_labels{$key} = "$URL/" . q|node395.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-intro-differences/;
$external_labels{$key} = "$URL/" . q|node29.html|; 
$noresave{$key} = "$nosave";

$key = q/debian-installation/;
$external_labels{$key} = "$URL/" . q|node77.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-probs-hardware/;
$external_labels{$key} = "$URL/" . q|node207.html|; 
$noresave{$key} = "$nosave";

$key = q/app-ftp/;
$external_labels{$key} = "$URL/" . q|node402.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-shell-script/;
$external_labels{$key} = "$URL/" . q|node274.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-plumbing/;
$external_labels{$key} = "$URL/" . q|node244.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-microsoftnet/;
$external_labels{$key} = "$URL/" . q|node382.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-rawrite/;
$external_labels{$key} = "$URL/" . q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-copyright/;
$external_labels{$key} = "$URL/" . q|lipp2.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-backfloppy/;
$external_labels{$key} = "$URL/" . q|node307.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-sysadm-num/;
$external_labels{$key} = "$URL/" . q|node279.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-generic-general/;
$external_labels{$key} = "$URL/" . q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-upgrade-gcc/;
$external_labels{$key} = "$URL/" . q|node316.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-command-summ/;
$external_labels{$key} = "$URL/" . q|node240.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-processes/;
$external_labels{$key} = "$URL/" . q|node258.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-add-user/;
$external_labels{$key} = "$URL/" . q|node291.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-shells-cmds/;
$external_labels{$key} = "$URL/" . q|node223.html|; 
$noresave{$key} = "$nosave";

$key = q/device-driver-names/;
$external_labels{$key} = "$URL/" . q|node288.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-mail/;
$external_labels{$key} = "$URL/" . q|node383.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-running-deb/;
$external_labels{$key} = "$URL/" . q|node101.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-probs-postinstall/;
$external_labels{$key} = "$URL/" . q|node212.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2002 (1.62)
# labels from external_latex_labels array.


$key = q/table-scsi-devices/;
$external_latex_labels{$key} = q|4.3|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-probs-install/;
$external_latex_labels{$key} = q|2.9.3|; 
$noresave{$key} = "$nosave";

$key = q/table-ide-device-drivers/;
$external_latex_labels{$key} = q|4.2|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-generic-x/;
$external_latex_labels{$key} = q|2.1.9|; 
$noresave{$key} = "$nosave";

$key = q/sec-adv-using-dip/;
$external_latex_labels{$key} = q|6.1.2|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-probs/;
$external_latex_labels{$key} = q|2.9|; 
$noresave{$key} = "$nosave";

$key = q/chap-sysadm/;
$external_latex_labels{$key} = q|4|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-probs-hardware-conflicts/;
$external_latex_labels{$key} = q|2.9.2|; 
$noresave{$key} = "$nosave";

$key = q/sec-resolve.conf/;
$external_latex_labels{$key} = q|6.1.1|; 
$noresave{$key} = "$nosave";

$key = q/example-sysadm-fstab/;
$external_latex_labels{$key} = q|4.4.1|; 
$noresave{$key} = "$nosave";

$key = q/sec-uucp/;
$external_latex_labels{$key} = q|6.3|; 
$noresave{$key} = "$nosave";

$key = q/sec-tape-backups/;
$external_latex_labels{$key} = q|4.8.3|; 
$noresave{$key} = "$nosave";

$key = q/sec-zip-backup/;
$external_latex_labels{$key} = q|4.8.2|; 
$noresave{$key} = "$nosave";

$key = q/sec-intro-help/;
$external_latex_labels{$key} = q|1.10|; 
$noresave{$key} = "$nosave";

$key = q/table-dev-settings/;
$external_latex_labels{$key} = q|2.8|; 
$noresave{$key} = "$nosave";

$key = q/red-hat-installation/;
$external_latex_labels{$key} = q|2.4|; 
$noresave{$key} = "$nosave";

$key = q/chap-intro-num/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

$key = q/sec-filesystem-tour/;
$external_latex_labels{$key} = q|3.6|; 
$noresave{$key} = "$nosave";

$key = q/sec-tcpip/;
$external_latex_labels{$key} = q|6.1|; 
$noresave{$key} = "$nosave";

$key = q/table-redhat-space-requirements/;
$external_latex_labels{$key} = q|2.5|; 
$noresave{$key} = "$nosave";

$key = q/sec-manage-links/;
$external_latex_labels{$key} = q|3.11|; 
$noresave{$key} = "$nosave";

$key = q/app-vendor-num/;
$external_latex_labels{$key} = q|D|; 
$noresave{$key} = "$nosave";

$key = q/chap-tutorial/;
$external_latex_labels{$key} = q|3|; 
$noresave{$key} = "$nosave";

$key = q/sec-manage-groups/;
$external_latex_labels{$key} = q|4.6.5|; 
$noresave{$key} = "$nosave";

$key = q/installation-slackware/;
$external_latex_labels{$key} = q|2.6|; 
$noresave{$key} = "$nosave";

$key = q/dirtree/;
$external_latex_labels{$key} = q|3.2.8|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-probs-booting/;
$external_latex_labels{$key} = q|2.9.1|; 
$noresave{$key} = "$nosave";

$key = q/sec-adv-slip-dip/;
$external_latex_labels{$key} = q|6.1.2|; 
$noresave{$key} = "$nosave";

$key = q/sec-ls/;
$external_latex_labels{$key} = q|3.3.2|; 
$noresave{$key} = "$nosave";

$key = q/sec-ppp/;
$external_latex_labels{$key} = q|6.2|; 
$noresave{$key} = "$nosave";

$key = q/table-ftp-sites/;
$external_latex_labels{$key} = q|C.1|; 
$noresave{$key} = "$nosave";

$key = q/sec-init-scripts/;
$external_latex_labels{$key} = q|3.14.3|; 
$noresave{$key} = "$nosave";

$key = q/app-sources/;
$external_latex_labels{$key} = q|A|; 
$noresave{$key} = "$nosave";

$key = q/sec-intro-sources/;
$external_latex_labels{$key} = q|1.9|; 
$noresave{$key} = "$nosave";

$key = q/sec-manage-users/;
$external_latex_labels{$key} = q|4.6|; 
$noresave{$key} = "$nosave";

$key = q/table-disk-formats/;
$external_latex_labels{$key} = q|4.4|; 
$noresave{$key} = "$nosave";

$key = q/chap-networking/;
$external_latex_labels{$key} = q|6|; 
$noresave{$key} = "$nosave";

$key = q/table-slackware-scsi-ide-boot-images/;
$external_latex_labels{$key} = q|2.6.9|; 
$noresave{$key} = "$nosave";

$key = q/table-debian-install-floppies/;
$external_latex_labels{$key} = q|2.2|; 
$noresave{$key} = "$nosave";

$key = q/sec-process/;
$external_latex_labels{$key} = q|3.12.1|; 
$noresave{$key} = "$nosave";

$key = q/sec-sysadm-upgrade/;
$external_latex_labels{$key} = q|4.9|; 
$noresave{$key} = "$nosave";

$key = q/sec-source-mailing-list/;
$external_latex_labels{$key} = q|1.9.5|; 
$noresave{$key} = "$nosave";

$key = q/ftape-module/;
$external_latex_labels{$key} = q|4.9.3|; 
$noresave{$key} = "$nosave";

$key = q/chap-install-num/;
$external_latex_labels{$key} = q|2|; 
$noresave{$key} = "$nosave";

$key = q/chap-install/;
$external_latex_labels{$key} = q|2|; 
$noresave{$key} = "$nosave";

$key = q/sec-set-host_name/;
$external_latex_labels{$key} = q|4.10.2|; 
$noresave{$key} = "$nosave";

$key = q/generic-instalation/;
$external_latex_labels{$key} = q|2.1|; 
$noresave{$key} = "$nosave";

$key = q/app-ftplist-num/;
$external_latex_labels{$key} = q|C|; 
$noresave{$key} = "$nosave";

$key = q/sec-bootfloppy/;
$external_latex_labels{$key} = q|4.2|; 
$noresave{$key} = "$nosave";

$key = q/sec-news/;
$external_latex_labels{$key} = q|6.6|; 
$noresave{$key} = "$nosave";

$key = q/sec-getting-internet/;
$external_latex_labels{$key} = q|C|; 
$noresave{$key} = "$nosave";

$key = q/table-redhat-packages/;
$external_latex_labels{$key} = q|2.4|; 
$noresave{$key} = "$nosave";

$key = q/sec-intro-gpl/;
$external_latex_labels{$key} = q|1.5|; 
$noresave{$key} = "$nosave";

$key = q/sec-job-control/;
$external_latex_labels{$key} = q|3.12|; 
$noresave{$key} = "$nosave";

$key = q/sec-lilo/;
$external_latex_labels{$key} = q|4.2.2|; 
$noresave{$key} = "$nosave";

$key = q/sec-inittab/;
$external_latex_labels{$key} = q|4.3.1|; 
$noresave{$key} = "$nosave";

$key = q/sec-swap-file/;
$external_latex_labels{$key} = q|4.5|; 
$noresave{$key} = "$nosave";

$key = q/kernel-ppa-driver/;
$external_latex_labels{$key} = q|4.9.2|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-S.u.S.E./;
$external_latex_labels{$key} = q|2.7|; 
$noresave{$key} = "$nosave";

$key = q/app-sourc-ldp-home-page/;
$external_latex_labels{$key} = q|A|; 
$noresave{$key} = "$nosave";

$key = q/sec-manage-fs/;
$external_latex_labels{$key} = q|4.4|; 
$noresave{$key} = "$nosave";

$key = q/app-gpl/;
$external_latex_labels{$key} = q|E|; 
$noresave{$key} = "$nosave";

$key = q/gnu-license/;
$external_latex_labels{$key} = q|E|; 
$noresave{$key} = "$nosave";

$key = q/sec-checking-file-system/;
$external_latex_labels{$key} = q|4.4.3|; 
$noresave{$key} = "$nosave";

$key = q/table-slackware-ide-boot-images/;
$external_latex_labels{$key} = q|2.6.9|; 
$noresave{$key} = "$nosave";

$key = q/app-gpl-num/;
$external_latex_labels{$key} = q|E|; 
$noresave{$key} = "$nosave";

$key = q/table-fs-types/;
$external_latex_labels{$key} = q|4.1|; 
$noresave{$key} = "$nosave";

$key = q/chap-tutorial-num/;
$external_latex_labels{$key} = q|3|; 
$noresave{$key} = "$nosave";

$key = q/table-debian-archive-structure/;
$external_latex_labels{$key} = q|2.1|; 
$noresave{$key} = "$nosave";

$key = q/sec-file-perms/;
$external_latex_labels{$key} = q|3.10|; 
$noresave{$key} = "$nosave";

$key = q/sec-sysadm-shutdown/;
$external_latex_labels{$key} = q|4.3|; 
$noresave{$key} = "$nosave";

$key = q/sec-generic-fdisk/;
$external_latex_labels{$key} = q|2.1.20|; 
$noresave{$key} = "$nosave";

$key = q/chap-advanced-xconfiguration/;
$external_latex_labels{$key} = q|5.5|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-distrib/;
$external_latex_labels{$key} = q|2.2|; 
$noresave{$key} = "$nosave";

$key = q/table-tape-devices/;
$external_latex_labels{$key} = q|4.5|; 
$noresave{$key} = "$nosave";

$key = q/sec-intro-design/;
$external_latex_labels{$key} = q|1.6|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-mice/;
$external_latex_labels{$key} = q|2.1.6|; 
$noresave{$key} = "$nosave";

$key = q/sec-rc/;
$external_latex_labels{$key} = q|4.10.1|; 
$noresave{$key} = "$nosave";

$key = q/caldera-installation/;
$external_latex_labels{$key} = q|2.5|; 
$noresave{$key} = "$nosave";

$key = q/table-debian-package-fields/;
$external_latex_labels{$key} = q|2.3.5|; 
$noresave{$key} = "$nosave";

$key = q/sec-upgrade-libs/;
$external_latex_labels{$key} = q|4.9.4|; 
$noresave{$key} = "$nosave";

$key = q/sec-perms/;
$external_latex_labels{$key} = q|3.10|; 
$noresave{$key} = "$nosave";

$key = q/app-info/;
$external_latex_labels{$key} = q|A|; 
$noresave{$key} = "$nosave";

$key = q/sec-walking-redhat/;
$external_latex_labels{$key} = q|2.4.11|; 
$noresave{$key} = "$nosave";

$key = q/sec-intro-usenet/;
$external_latex_labels{$key} = q|1.9.4|; 
$noresave{$key} = "$nosave";

$key = q/chap-xwindow/;
$external_latex_labels{$key} = q|5|; 
$noresave{$key} = "$nosave";

$key = q/sec-msdos-mount/;
$external_latex_labels{$key} = q|3.4|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-probs-hardware-scsi/;
$external_latex_labels{$key} = q|2.9.2|; 
$noresave{$key} = "$nosave";

$key = q/sec-create-account/;
$external_latex_labels{$key} = q|3.2.1|; 
$noresave{$key} = "$nosave";

$key = q/sec-video-card-info/;
$external_latex_labels{$key} = q|5.6|; 
$noresave{$key} = "$nosave";

$key = q/sec-maint-diskette/;
$external_latex_labels{$key} = q|4.11.1|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-postinstall/;
$external_latex_labels{$key} = q|2.8|; 
$noresave{$key} = "$nosave";

$key = q/sec-floppy/;
$external_latex_labels{$key} = q|4.8.4|; 
$noresave{$key} = "$nosave";

$key = q/sec-xwindows-reqs/;
$external_latex_labels{$key} = q|5.1|; 
$noresave{$key} = "$nosave";

$key = q/sec-vi/;
$external_latex_labels{$key} = q|3.13|; 
$noresave{$key} = "$nosave";

$key = q/app-sources-num/;
$external_latex_labels{$key} = q|A|; 
$noresave{$key} = "$nosave";

$key = q/app-tldpes/;
$external_latex_labels{$key} = q|B|; 
$noresave{$key} = "$nosave";

$key = q/sec-intro-differences/;
$external_latex_labels{$key} = q|1.7|; 
$noresave{$key} = "$nosave";

$key = q/debian-installation/;
$external_latex_labels{$key} = q|2.3|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-probs-hardware/;
$external_latex_labels{$key} = q|2.9.2|; 
$noresave{$key} = "$nosave";

$key = q/app-ftp/;
$external_latex_labels{$key} = q|C|; 
$noresave{$key} = "$nosave";

$key = q/sec-shell-script/;
$external_latex_labels{$key} = q|3.14.1|; 
$noresave{$key} = "$nosave";

$key = q/sec-plumbing/;
$external_latex_labels{$key} = q|3.9|; 
$noresave{$key} = "$nosave";

$key = q/sec-microsoftnet/;
$external_latex_labels{$key} = q|6.4|; 
$noresave{$key} = "$nosave";

$key = q/sec-rawrite/;
$external_latex_labels{$key} = q|2.1.18|; 
$noresave{$key} = "$nosave";

$key = q/sec-backfloppy/;
$external_latex_labels{$key} = q|4.8.1|; 
$noresave{$key} = "$nosave";

$key = q/chap-sysadm-num/;
$external_latex_labels{$key} = q|4|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-generic-general/;
$external_latex_labels{$key} = q|2.1.5|; 
$noresave{$key} = "$nosave";

$key = q/sec-upgrade-gcc/;
$external_latex_labels{$key} = q|4.9.5|; 
$noresave{$key} = "$nosave";

$key = q/sec-command-summ/;
$external_latex_labels{$key} = q|3.5|; 
$noresave{$key} = "$nosave";

$key = q/sec-processes/;
$external_latex_labels{$key} = q|3.12.1|; 
$noresave{$key} = "$nosave";

$key = q/sec-shells-cmds/;
$external_latex_labels{$key} = q|3.2.4|; 
$noresave{$key} = "$nosave";

$key = q/sec-add-user/;
$external_latex_labels{$key} = q|4.6|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-distributions/;
$external_latex_labels{$key} = q|2.2|; 
$noresave{$key} = "$nosave";

$key = q/sec-intro-hardware/;
$external_latex_labels{$key} = q|1.8|; 
$noresave{$key} = "$nosave";

$key = q/device-driver-names/;
$external_latex_labels{$key} = q|4.4.2|; 
$noresave{$key} = "$nosave";

$key = q/sec-mail/;
$external_latex_labels{$key} = q|6.5|; 
$noresave{$key} = "$nosave";

$key = q/sec-running-deb/;
$external_latex_labels{$key} = q|2.3.5|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-probs-postinstall/;
$external_latex_labels{$key} = q|2.9.4|; 
$noresave{$key} = "$nosave";

$key = q/chap-intro/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

1;

