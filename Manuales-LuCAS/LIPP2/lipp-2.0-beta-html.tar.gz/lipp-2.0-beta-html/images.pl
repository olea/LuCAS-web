# LaTeX2HTML 2002 (1.62)
# Associate images original text with physical files.


$key = q/{tscreen}preform{<verbatim_mark>verbatim2874#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="359" HEIGHT="150" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img359.png"
 ALT="\begin{tscreen}\begin{verbatim}127.0.0.1 localhost
128.253.154.32 loomer.vpizza.com loomer\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#catHellothere.Hellothere.Bye.Bye.key{Ctrl-D}slashhomeslashlarryslashpapers#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="299" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img157.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  cat \\\\
Hello there. \\\\
Hello there. \\\\
Bye. \\\\
Bye. \\\\
\key{Ctrl-D} \\\\
/home/larry/papers\char93
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#more~{}slashpapersslashhistory-final{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="325" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img121.png"
 ALT="\begin{tscreen}
/home/larry\char93  more \&nbsp;{}/papers/history-final
\end{tscreen}">|; 

$key = q/{abib}{DiscoverLinux(1stEd)}{SteveOualline}{IDGBooks,1997}{0764531050}{dollar24.D-ROMincluyelapopulardistribuci�nRedHatLinux4.1deunaf�cilinstalaci�n.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="32" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img425.png"
 ALT="\begin{abib}
{Discover Linux (1st Ed) }
{Steve Oualline }
{IDG Books, 1997 }
{07...
...la popular distribuci�n RedHat
Linux 4.1 de una f�cil instalaci�n.}
\end{abib}">|; 

$key = q/{tscreen}ftp>{{em{getREADME}200PORTcommandsuccessful.150ASCIIdataconnectionforREADMEremote:README1493bytesreceivedin0.03seconds(49Kbytesslashs)ftp>{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="100" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img467.png"
 ALT="\begin{tscreen}
ftp&gt; {\em get README} \\\\
200 PORT command successful. \\\\
150 A...
...DME \\\\
1493 bytes received in 0.03 seconds (49 Kbytes/s) \\\\
ftp&gt;
\end{tscreen}">|; 

$key = q/{tscreen}#dpkg--unpackcparam{nombreFichero}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="223" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img34.png"
 ALT="\begin{tscreen}
\char93  dpkg -unpack \cparam{nombreFichero}
\end{tscreen}">|; 

$key = q/{tscreen}Partitioncheck:hda:hda1hda2hdb:hdb1hdb2hdb3{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="135" HEIGHT="9" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img98.png"
 ALT="\begin{tscreen}
Partition check: \\\\
  hda: hda1 hda2 \\\\
  hdb: hdb1 hdb2 hdb3
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#{{em{PS1=``Suinstrucci�n,porfavor:''}Suinstrucci�n,porfavor:{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="214" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img232.png"
 ALT="\begin{tscreen}
/home/larry\char93  {\em PS1=\lq\lq Su instrucci�n, por favor: ''} \\\\
Su instrucci�n, por favor:
\end{tscreen}">|; 

$key = q/{tscreen}Linux2.0.29(durak.interactivate.com)(ttyp4){linebreak{{linebreak{durakloot{linebreak{rootloginrefusedonthisterminal.{linebreak{duraklogin:{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="60" HEIGHT="121" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img88.png"
 ALT="\begin{tscreen}
Linux 2.0.29 (durak.interactivate.com) (ttyp4) \linebreak\linebr...
...break root login refused on this terminal. \linebreak durak login:
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim1150#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="438" HEIGHT="72" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img58.png"
 ALT="\begin{tscreen}\begin{verbatim}NFS Server name: redhat.infomagic.com
Red Hat Directory: /pub/mirrors/linux/RedHat\end{verbatim}\end{tscreen}">|; 

$key = q/>;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="451" HEIGHT="317" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img77.png"
 ALT="$&gt;$">|; 

$key = q/{tscreen}FDISKslashMBR{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="179" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img105.png"
 ALT="\begin{tscreen}
FDISK /MBR
\end{tscreen}">|; 

$key = q/{tscreen}helpcparam{command}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="172" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img460.png"
 ALT="\begin{tscreen}
help \cparam{command}
\end{tscreen}">|; 

$key = q/{tscreen}#{{em{mount-text2slashdevslashfd0slashmnt}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="231" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img296.png"
 ALT="\begin{tscreen}
\char93  {\em mount -t ext2 /dev/fd0 /mnt}
\end{tscreen}">|; 

$key = q/{tscreen}install-2.0.25-cparam{XXX}.imgmodules-2.0.25-cparam{XXX}.img{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="94" HEIGHT="9" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img66.png"
 ALT="\begin{tscreen}
install-2.0.25-\cparam{XXX}.img \\\\
modules-2.0.25-\cparam{XXX}.img
\end{tscreen}">|; 

$key = q/{abib}{ManagingUUCPandUsenet}{TimO'ReillyandGraceTodino}{O'ReillyandAssociates,1enUUCPoenaccederanoticiasUSENETensusistemanopuededejardeleerestelibro.{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="515" HEIGHT="210" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img437.png"
 ALT="\begin{abib}
{Managing UUCP and Usenet}
{Tim O'Reilly and Grace Todino}
{O'Reill...
...er a noticias USENET en su sistema no puede
dejar de leer este libro.
\end{abib}">|; 

$key = q/{tscreen}#{{em{mount-text2slashdevslashhda2slashmnt}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="358" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img315.png"
 ALT="\begin{tscreen}
\char93  {\em mount -t ext2 /dev/hda2 /mnt}
\end{tscreen}">|; 

$key = q/{abib}{LaBibliadeRedHatLinux}{DavidPitts}{AnayaMultimedia,1999}{84-415-0524-1}{3lacolecci�ndelibrost�cnicosdeAnayayvieneconunCDconladistibuci�nRedHat}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="517" HEIGHT="214" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img446.png"
 ALT="\begin{abib}
{La Biblia de Red Hat Linux}
{David Pitts}
{Anaya Multimedia, 1999}...
...ibros t�cnicos de Anaya
y viene con un CD con la distibuci�n Red Hat}
\end{abib}">|; 

$key = q/{tscreen}#rm-fslashvarslashlockslashLCK..ttyS{{em{x}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="487" HEIGHT="52" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img388.png"
 ALT="\begin{tscreen}
\char93  rm -f /var/lock/LCK..ttyS{\em x}
\end{tscreen}">|; 

$key = q/{tscreen}slashdevslashhda1slashdosmsdosdefaults{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="264" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img142.png"
 ALT="\begin{tscreen}
/dev/hda1     /dos     msdos      defaults
\end{tscreen}">|; 

$key = q/{tscreen}0slashdevslashttyS0(oCOM1:bajoDOS)1slashdevslashttyS1(oCOM2:bajoDOS)2slashdevslashttyS2(oCOM3:bajoDOS)3slashdevslashttyS3(oCOM4:bajoDOS){tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="471" HEIGHT="384" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img79.png"
 ALT="\begin{tscreen}
0 /dev/ttyS0 (o COM1: bajo DOS) \\\\
1 /dev/ttyS1 (o COM2: bajo D...
...v/ttyS2 (o COM3: bajo DOS) \\\\
3 /dev/ttyS3 (o COM4: bajo DOS) \\\\
\end{tscreen}">|; 

$key = q/{tscreen}#fdiskslashdevslashhdb{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="58" HEIGHT="11" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img15.png"
 ALT="\begin{tscreen}
\char93  fdisk /dev/hdb
\end{tscreen}">|; 

$key = q/{tscreen}#slashsbinslashlilo{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="161" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img306.png"
 ALT="\begin{tscreen}
\char93  /sbin/lilo
\end{tscreen}">|; 

$key = q/{tscreen}[hartr@keplerhartr]dollar{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="265" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img405.png"
 ALT="\begin{tscreen}[hartr@kepler hartr]\$
\end{tscreen}">|; 

$key = q/{tscreen}ftp>{{em{ascii}200TypesettoA.ftp>{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="52" HEIGHT="10" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img464.png"
 ALT="\begin{tscreen}
ftp&gt; {\em ascii} \\\\
200 Type set to A. \\\\
ftp&gt;
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2775#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="463" HEIGHT="31" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img340.png"
 ALT="\begin{tscreen}\begin{verbatim}Modes ''1024x768'' ''800x600'' ''640x480''\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}d1:12345:respawn:slashsbinslashagetty-mt6038400,19200,9600,2400,1200ttyS0vt100{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="170" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img246.png"
 ALT="\begin{tscreen}
d1:12345:respawn:/sbin/agetty -mt60 38400,19200,9600,2400,1200 ttyS0 vt100
\end{tscreen}">|; 

$key = q/{tscreen}InitializeaLinuxDiskPartitionNT{``Inicializarunapartici�nLinux''.}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="402" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img23.png"
 ALT="\begin{tscreen}
Initialize a Linux Disk Partition\NT{ \lq\lq Inicializar una partici�n Linux''.}
\end{tscreen}">|; 

$key = q/{tscreen}#tarxvfzbackup.tar.Z{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="365" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img279.png"
 ALT="\begin{tscreen}
\char93  tar xvfz backup.tar.Z
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2780#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="546" HEIGHT="209" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img349.png"
 ALT="\begin{tscreen}\begin{verbatim}(-) S3: clocks: 25.18 28.32 38.02 36.15 40.33 45.32 32.00 00.00\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2455#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="85" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img260.png"
 ALT="\begin{tscreen}\begin{verbatim}...">|; 

$key = q/{tscreen}slashhomeslashlarry#ls-ifoo22192fooslashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="555" HEIGHT="153" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img175.png"
 ALT="\begin{tscreen}
/home/larry\char93  ls -i foo \\\\
22192 foo \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}:rfoo.txt{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="456" HEIGHT="163" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img216.png"
 ALT="\begin{tscreen}
:r foo.txt
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#cdslashhomeslashkarlslashhomeslashkarl#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="211" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img127.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  cd /home/karl \\\\
/home/karl\char93
\end{tscreen}">|; 

$key = q/{tscreen}ftp:slashslashftp.debian.orgslashpubslashdebianslashstableslashPackages{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="136" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img16.png"
 ALT="\begin{tscreen}
ftp://ftp.debian.org/pub/debian/stable/Packages
\end{tscreen}">|; 

$key = q/{tscreen}#gzip-9backup.tar{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="463" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img272.png"
 ALT="\begin{tscreen}
\char93  gzip -9 backup.tar
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3044#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="307" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img374.png"
 ALT="\begin{tscreen}\begin{verbatim}Jun 8 09:52:08 gemini kernel: PPP: version 0.2.7 (4 channels) NEW_TTY_DRIVERS OPTIMIZE_FLAGS\end{verbatim}\end{tscreen}">|; 

$key = q/{abib}{{linux}:ConfigurationandInstallation(3rdEdition)}{PatrickVolkerding}{IDGBnsejosnodocumentadosyt�cnicasinstalar,usaryoptimizarsusistema{linux}.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="659" HEIGHT="132" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img421.png"
 ALT="\begin{abib}
{{\linux}: Configuration and Installation (3rd Edition)}
{Patrick V...
...umentados y t�cnicas
instalar, usar y optimizar su sistema {\linux}.}
\end{abib}">|; 

$key = q/{tscreen}slashhomeslashlarry#cpfoobar{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="384" HEIGHT="56" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img114.png"
 ALT="\begin{tscreen}
/home/larry\char93  cp foo bar
\end{tscreen}">|; 

$key = q/{tscreen}#tarcvfzbackup.tar.gzslashetc{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="213" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img277.png"
 ALT="\begin{tscreen}
\char93  tar cvfz backup.tar.gz /etc
\end{tscreen}">|; 

$key = q/{tscreen}Loginincorrect{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="197" HEIGHT="31" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img111.png"
 ALT="\begin{tscreen}
Login incorrect
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3056#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="187" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img389.png"
 ALT="\begin{tscreen}\begin{verbatim}...">|; 

$key = q/{tscreen}ConfiguretheKeyboard{tscreen};FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="435" HEIGHT="34" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img19.png"
 ALT="\begin{tscreen}
Configure the Keyboard
\end{tscreen}">|; 

$key = q/{tscreen}#{{em{tarcvfzMslashdevslashfd0slash}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="247" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img281.png"
 ALT="\begin{tscreen}
\char93  {\em tar cvfzM /dev/fd0 /}
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#lsfrogjoe{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="187" HEIGHT="56" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img151.png"
 ALT="\begin{tscreen}
/home/larry\char93  ls frog joe
\end{tscreen}">|; 

$key = q/{tscreen}cpcparam{ficheros}cparam{destino}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="398" HEIGHT="78" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img155.png"
 ALT="\begin{tscreen}
cp \cparam{ficheros} \cparam{destino}
\end{tscreen}">|; 

$key = q/{tscreen}ftp>{{em{cdpub}ftp>{{em{dir}200PORTcommandsuccessful.150ASCIIdataconnecransfercomplete.2443bytesreceivedin0.35seconds(6.8Kbytesslashs)ftp>{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="454" HEIGHT="165" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img462.png"
 ALT="\begin{tscreen}
ftp&gt; {\em cd pub} \\\\
ftp&gt; {\em dir} \\\\
200 PORT command succes...
.... \\\\
2443 bytes received in 0.35 seconds (6.8 Kbytes/s) \\\\
ftp&gt;
\end{tscreen}">|; 

$key = q/{tscreen}#sync#swaponslashswap{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="188" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img254.png"
 ALT="\begin{tscreen}
\char93  sync \\\\
\char93  swapon /swap
\end{tscreen}">|; 

$key = q/{tscreen}ftp:slashslashftp.redhat.comslashpubslashredhatslashcurrentslashupdates{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="138" HEIGHT="75" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img52.png"
 ALT="\begin{tscreen}
ftp://ftp.redhat.com/pub/redhat/current/updates
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3061#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="669" HEIGHT="590" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img394.png"
 ALT="\begin{tscreen}\begin{verbatim}ABORT '\nBUSY\r'\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}#hostname-Sgoober.norelco.com{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="239" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img314.png"
 ALT="\begin{tscreen}
\char93  hostname -S goober.norelco.com
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3068#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="375" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img401.png"
 ALT="\begin{tscreen}\begin{verbatim}CONNECT ''\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#{{em{foo=``holaall�''}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="351" HEIGHT="113" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img225.png"
 ALT="\begin{tscreen}
/home/larry\char93  {\em foo=\lq\lq hola all�''}
\end{tscreen}">|; 

$key = q/{abib}{TheNoB.S.GuidetoLinux}{BobRankin}{NoStarchPress,1997}{1886411042}{dollar3rentesatajosas�comohacerlatransici�nalnuevosistemalom�sfluidaposible.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="516" HEIGHT="214" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img428.png"
 ALT="\begin{abib}
{The No B.S. Guide to Linux }
{Bob Rankin }
{No Starch Press, 1997 ...
...� como hacer la transici�n al nuevo sistema lo m�s
fluida posible. }
\end{abib}">|; 

$key = q/{tscreen}From:cajho@uno.eduhfill{linebreak{Date:7Jan199415:48:07GMThfill{linebrear,perodespu�sdeesto,creoquela�nicaelecci�nesinstalarSlackwaretmya.{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="194" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img67.png"
 ALT="\begin{tscreen}
From: cajho@uno.edu \hfill \linebreak Date: 7 Jan 1994 15:48:07 ...
...s de esto, creo que la �nica elecci�n es instalar Slackware\tm ya.
\end{tscreen}">|; 

$key = q/{tscreen}#gunzipbackup.tar.gz#tarxvfbackup.tar{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="239" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img274.png"
 ALT="\begin{tscreen}
\char93  gunzip backup.tar.gz \\\\
\char93  tar xvf backup.tar
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#lsslashusrslashbin{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="187" HEIGHT="97" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img166.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  ls /usr/bin
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3073#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img409.png"
 ALT="\begin{tscreen}
\begin{verbatim}rcvd [LCP ConfReq id=0x2 &lt;asyncmap 0x0&gt; &lt;auth chap 80&gt; &lt;magic 0x46a3&gt;]\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}InstalltheOperatingSystemKernelNT{``Instalareln�cleodelsistemaoperativo''}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="208" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img25.png"
 ALT="\begin{tscreen}
Install the Operating System Kernel\NT{\lq\lq Instalar el n�cleo del sistema operativo''}
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#jobss<verb_mark>28<verb_mark>slashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="135" HEIGHT="122" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img187.png"
 ALT="\begin{tscreen}
/home/larry\char93  jobss \\\\
\verb-[1]+ Running yes &gt;/dev/null &amp;- \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}#{{em{e2fsck-b8193cparam{partici�n}}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="335" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img317.png"
 ALT="\begin{tscreen}
\char93  {\em e2fsck -b 8193 \cparam{partici�n}}
\end{tscreen}">|; 

$key = q/{tscreen}C:>rawritecparam{imagen}cparam{unidad}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="74" HEIGHT="11" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="\begin{tscreen}
C:&gt;rawrite \cparam{imagen} \cparam{unidad}
\end{tscreen}">|; 

$key = q/{tscreen}ftp:slashslashftp.cdrom.comslashpubslash{linux}slashslackwareslashbootdsks.144slashREADME.TXT{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="245" HEIGHT="78" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img82.png"
 ALT="\begin{tscreen}
ftp://ftp.cdrom.com/pub/{\linux}/slackware/bootdsks.144/README.TXT
\end{tscreen}">|; 

$key = q/{tscreen}Connectedtoshoop.vpizza.com.220Shoop.vpizza.comFTPDreadyat15Dec199208:20:42EDTName(shoop.vpizza.com:mdw):{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="515" HEIGHT="167" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img454.png"
 ALT="\begin{tscreen}
Connected to shoop.vpizza.com. \\\\
220 Shoop.vpizza.com FTPD ready at 15 Dec 1992 08:20:42 EDT \\\\
Name (shoop.vpizza.com:mdw):
\end{tscreen}">|; 

$key = q/{tscreen}dollartelnetshoop.vpizza.com{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="584" HEIGHT="53" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img364.png"
 ALT="\begin{tscreen}
\$ telnet shoop.vpizza.com
\end{tscreen}">|; 

$key = q/{tscreen}#gzip-d<slashvarslashtmpslashX33prog.tgz{mid{tarvxf-{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="205" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img320.png"
 ALT="\begin{tscreen}
\char93  gzip -d &lt; /var/tmp/X33prog.tgz $\mid$ tar vxf - \\\\
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#ls{>>{file-list{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="320" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img170.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  ls $&#187;$ file-list
\end{tscreen}">|; 

$key = q/{tscreen}http:slashslashwww.cs.umd.eduslashprojectsslashamandaslashindex.html{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="369" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img92.png"
 ALT="\begin{tscreen}
http://www.cs.umd.edu/projects/amanda/index.html
\end{tscreen}">|; 

$key = q/[;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="154" HEIGHT="12" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img63.png"
 ALT="$[$">|; 

$key = q/{tscreen}ModeLine"640x480"25.175640664760800480491493525{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="592" HEIGHT="348" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img336.png"
 ALT="\begin{tscreen}
ModeLine ''640x480'' 25.175  640 664 760 800  480 491 493 525
\end{tscreen}">|; 

$key = q/{tscreen}#cdslashetc#tarcvfhostsgrouppasswd{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="213" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img270.png"
 ALT="\begin{tscreen}
\char93  cd /etc \\\\
\char93  tar cvf hosts group passwd
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2873#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="50" HEIGHT="8" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img358.png"
 ALT="\begin{tscreen}\begin{verbatim}...">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim1319#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="575" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img83.png"
 ALT="\begin{tscreen}\begin{verbatim}============== Slackware96 Linux Setup (versio...
...=====================================================\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}#{{em{slashsbinslashlilo}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="244" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img239.png"
 ALT="\begin{tscreen}
\char93  {\em /sbin/lilo}
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#ls{>{file-list{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="265" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img169.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  ls $&gt;$ file-list
\end{tscreen}">|; 

$key = q/{tscreen}#rpm--installcparam{paquete}.rpm#instalaacparam{paquete}#rpm--upgradecparam{paquete}#rpm--erasecparam{paquete}.rpm#eliminaacparam{paquete}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="368" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img43.png"
 ALT="\begin{tscreen}
\char93  rpm -install \cparam{paquete}.rpm \char93  instala a \...
... -erase \cparam{paquete}.rpm \char93  elimina a \cparam{paquete}
\end{tscreen}">|; 

$key = q/{tscreen}ConfiguretheBaseSystemNT{``Configurarelsistemabase''}{tscreen};FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="210" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img27.png"
 ALT="\begin{tscreen}
Configure the Base System\NT{\lq\lq Configurar el sistema base''}
\end{tscreen}">|; 

$key = q/{tscreen}0:6091646timer1:40691keyboard2:0cascade4:284686+serial13:1matherror14:192560+ide0{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="369" HEIGHT="100" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img304.png"
 ALT="\begin{tscreen}
0: 6091646 timer \\\\
1: 40691 keyboard \\\\
2: 0 cascade \\\\
4: 284686 + serial \\\\
13: 1 math error \\\\
14: 192560 + ide0 \\\\
\end{tscreen}">|; 

$key = q/{abib}{TheUnixProgrammingEnvironment}{BrianKernighanandBobPike}{Prentice-Hall,19t�ndosedeunabuenalecturaelmundodelaprogramaci�n,untantoamorfo,enUNIX.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="516" HEIGHT="232" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img440.png"
 ALT="\begin{abib}
{The Unix Programming Environment}
{Brian Kernighan and Bob Pike}
{...
...uena lectura el mundo de la
programaci�n, un tanto amorfo, en UNIX.}
\end{abib}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2233#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="65" HEIGHT="9" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img222.png"
 ALT="\begin{tscreen}\begin{verbatim}...">|; 

$key = q/{tscreen}slashhomeslashlarry#{{em{catcap�tulo1cap�tulo2capitulo3{>{libro}slashhoslashlarry#{{em{wc-llibro}slashhomeslashlarry#{{em{lplibro}{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="455" HEIGHT="140" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img221.png"
 ALT="\begin{tscreen}
/home/larry\char93  {\em cat cap�tulo1 cap�tulo2 capitulo3 $&gt;$ ...
...y\char93  {\em wc -l libro} \\\\
/home/larry\char93  {\em lp libro}
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#jobspreform{<verbatim_mark>verbatim2172#preform{slashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="258" HEIGHT="56" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img189.png"
 ALT="\begin{tscreen}
/home/larry\char93  jobs
\begin{verbatim}[1]+ Terminated yes &gt;/dev/null\end{verbatim}/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}Name(shoop.vpizza.com:mdw):{{em{anonymous}331-Guestloginok,sende-mailadzaDelivery[tm]:Downloadpizzain30cyclesorless230-oryougetitFREE!ftp>{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="515" HEIGHT="191" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img455.png"
 ALT="\begin{tscreen}
Name (shoop.vpizza.com:mdw): {\em anonymous} \\\\
331-Guest login...
... pizza in 30 cycles or less \\\\
230- or you get it FREE! \\\\
ftp&gt;
\end{tscreen}">|; 

$key = q/{abib}{VITutorial}{BelindaFrazier}{SpecializedSystemsConsultants}{0-916151-54-9}utorial,�steest�dirigidoalosusuariosprincipiantesonomuyavanzadosdevi.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="516" HEIGHT="276" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img432.png"
 ALT="\begin{abib}
{VI Tutorial}
{Belinda Frazier}
{Specialized Systems Consultants}
{...
...st� dirigido a los usuarios
principiantes o no muy avanzados de vi.}
\end{abib}">|; 

$key = q/{tscreen}{fbox{minipage{{0.8textwidth}Nowisthetimeforallgoodwounderline{m}entocometotheaidoftheparty.~{}~{}~{}~{}~{}minipage{}{{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="455" HEIGHT="142" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img203.png"
 ALT="\begin{tscreen}\fbox{\begin{minipage}{0.8\textwidth}
Now is the time for all goo...
...arty. \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{}
\end{minipage}}\end{tscreen}">|; 

$key = q/{tscreen}:r!ls-F{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="455" HEIGHT="23" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img217.png"
 ALT="\begin{tscreen}
:r! ls -F
\end{tscreen}">|; 

$key = q/{tscreen}#{{em{tarxvfzMslashdevslashfd0}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="213" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img282.png"
 ALT="\begin{tscreen}
\char93  {\em tar xvfzM /dev/fd0}
\end{tscreen}">|; 

$key = q/{tscreen}help{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="309" HEIGHT="56" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img472.png"
 ALT="\begin{tscreen}
help
\end{tscreen}">|; 

$key = q/{dispitems}ditem{texttt{debian-announce@lists.debian.org}}Moderada.AnunciosimporortarsoftwareDebianalasplataformasSPARC,DECAlpha,yMotorolla680x0.{dispitems};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="166" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img41.png"
 ALT="\begin{dispitems}
\ditem{\texttt{debian-announce@lists.debian.org}}
Moderada. An...
...re Debian a las
plataformas SPARC, DEC Alpha, y Motorolla 680x0.
\end{dispitems}">|; 

$key = q/{tscreen}dircparam{file}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="515" HEIGHT="188" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img457.png"
 ALT="\begin{tscreen}
dir \cparam{file}
\end{tscreen}">|; 

$key = q/{tscreen}ftpmail@sunsite.unc.edu{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="151" HEIGHT="56" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img471.png"
 ALT="\begin{tscreen}
ftpmail@sunsite.unc.edu
\end{tscreen}">|; 

$key = q/{tscreen}boot:linuxhd=cparam{partici�n}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="50" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img104.png"
 ALT="\begin{tscreen}
boot: linux hd=\cparam{partici�n}
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2769#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="421" HEIGHT="89" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img332.png"
 ALT="\begin{tscreen}\begin{verbatim}Section ''Monitor''Identifier ''CTX 5468 NI'...
...'' 65 1024 1088 1200 1328 768 783 789 818EndSection\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}nombredegrupo:clave:GID:otrosmiembros{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="275" HEIGHT="33" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img263.png"
 ALT="\begin{tscreen}
nombre de grupo:clave:GID:otros miembros
\end{tscreen}">|; 

$key = q/{tscreen}#tarxvfbackup.tar{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="342" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img267.png"
 ALT="\begin{tscreen}
\char93  tar xvf backup.tar
\end{tscreen}">|; 

$key = q/{tscreen}Gnomovisionversion69,Copyright(C)19yynameofauthorGnomovisioncomeswithABelcometoredistributeitundercertainconditions;type`showc'fordetails.{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="417" HEIGHT="186" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img474.png"
 ALT="\begin{tscreen}
Gnomovision version 69, Copyright (C) 19yy name of author
Gnom...
...istribute it
under certain conditions; type \lq show c' for details.
\end{tscreen}">|; 

$key = q/{tscreen}#ftmt-fslashdevslashqft0status{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="161" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img294.png"
 ALT="\begin{tscreen}
\char93  ftmt -f /dev/qft0 status
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2774#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="599" HEIGHT="110" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img339.png"
 ALT="\begin{tscreen}\begin{verbatim}Identifier '' ...">|; 

$key = q/{tscreen}<verb_mark>62<verb_mark>{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="453" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img369.png"
 ALT="\begin{tscreen}
\verb!/etc/dip/dip -v /etc/dip/mychat 2&gt;&amp;1!
\end{tscreen}">|; 

$key = q/{tscreen}consoletty1tty2#ttyS0#ttyS1{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="109" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img87.png"
 ALT="\begin{tscreen}
console \\\\
\\\\
tty1 \\\\
tty2 \\\\
\char93  ttyS0 \\\\
\char93  ttyS1 \\\\
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#ls--FMailslashlettersslashpapersslashslashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="127" HEIGHT="100" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img130.png"
 ALT="\begin{tscreen}
/home/larry\char93  ls -F \\\\
Mail/ \\\\
letters/ \\\\
papers/ \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}#ftmt-fslashdevslashqft0retension{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="204" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img293.png"
 ALT="\begin{tscreen}
\char93  ftmt -f /dev/qft0 retension
\end{tscreen}">|; 

$key = q/{tscreen}mget*{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="67" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img103.png"
 ALT="\begin{tscreen}
mget *
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashfoo#mvtermcapsellsslashhomeslashlarryslashfoo#ls-Fbellssellsshellsslashhomeslashlarryslashfoo#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="298" HEIGHT="165" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img136.png"
 ALT="\begin{tscreen}
/home/larry/foo\char93  mv termcap sells \\\\
/home/larry/foo\cha...
...
bells     sells     shells \\\\
/home/larry/foo\char93
\end{tscreen}">|; 

$key = q/{tscreen}#{{em{rdevslashetcslashImageslashdevslashhda2}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="255" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img237.png"
 ALT="\begin{tscreen}
\char93  {\em rdev /etc/Image /dev/hda2}
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#yes{>{slashdevslashnullkey{ctrl-Z}<verb_mark>29<verb_mark>slashhomeslashlarry#{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="163" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img191.png"
 ALT="\begin{tscreen}
/home/larry\char93  yes $&gt;$ /dev/null \\\\
\key{ctrl-Z} \\\\
\verb-[1]+ Stopped yes &gt;/dev/null- \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}ModeLinecparam{name}cparam{clock}cparam{horiz-values}cparam{vert-values}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="222" HEIGHT="89" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img334.png"
 ALT="\begin{tscreen}
ModeLine \cparam{name} \cparam{clock} \cparam{horiz-values} \cparam{vert-values}
\end{tscreen}">|; 

$key = q/{tscreen}texttt{slashdevslashfd0u1440}(Discoa:de1.44M)texttt{slashdevslashfd1u14d0h1200}(Discoa:de1.2M)texttt{slashdevslashfd1h1200}(Discob:de1.2M){tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="348" HEIGHT="99" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img75.png"
 ALT="\begin{tscreen}
\texttt{/dev/fd0u1440} (Disco a: de 1.44M ) \\\\
\texttt{/dev/fd1...
...co a: de 1.2M ) \\\\
\texttt{/dev/fd1h1200} (Disco b: de 1.2M ) \\\\
\end{tscreen}">|; 

$key = q/<;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="83" HEIGHT="13" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img418.png"
 ALT="$&lt;$">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3043#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="289" HEIGHT="31" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img371.png"
 ALT="\begin{tscreen}\begin{verbatim}Jun 8 09:52:08 gemini kernel: Swansea University Computer Society TCP/IP for NET3.019\end{verbatim}\end{tscreen}">|; 

$key = q/{abib}{Linux.Utilizaci�n:versi�n2.0a2.2deln�cleo}{BrunoGuerin}{ENI,2000}{2-7460-otextoquepodemosencontraren{linux}.Untesoroparalosamantesdelaconsola.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="517" HEIGHT="213" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img450.png"
 ALT="\begin{abib}
{Linux. Utilizaci�n: versi�n 2.0 a 2.2 del n�cleo}
{Bruno Guerin}
{...
...mos encontrar en {\linux}. Un tesoro para los amantes de la consola.}
\end{abib}">|; 

$key = q/{tscreen}#ftmt-fslashdevslashqft0rewoffl{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="334" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img292.png"
 ALT="\begin{tscreen}
\char93  ftmt -f /dev/qft0 rewoffl
\end{tscreen}">|; 

$key = q/{tscreen}#mount-tvfatslashdevslashhda1slashmnt{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="358" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img143.png"
 ALT="\begin{tscreen}
\char93  mount -t vfat /dev/hda1 /mnt
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#lsslashusrslashbin{mid{more{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="316" HEIGHT="144" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img167.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  ls /usr/bin $\mid$ more
\end{tscreen}">|; 

$key = q/{tscreen}Incompatiblelibraryversion{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="102" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img310.png"
 ALT="\begin{tscreen}
Incompatible library version
\end{tscreen}">|; 

$key = q/{tscreen}ftp:slashslashftp.redhat.comslashpubslashredhatslashcurrentslashi386slashdosutilsslashrawrite.exe{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="515" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img47.png"
 ALT="\begin{tscreen}
ftp://ftp.redhat.com/pub/redhat/current/i386/dosutils/rawrite.exe
\end{tscreen}">|; 

$key = q/{tscreen}#dpkg-rcparam{paquete}#dpkg--purgecparam{paquete}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="190" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img36.png"
 ALT="\begin{tscreen}
\char93  dpkg -r \cparam{paquete} \\\\
\char93  dpkg -purge \cparam{paquete}
\end{tscreen}">|; 

$key = q/{tscreen}ftp:slashslashftp.wsc.comslashpubslashfreewareslashlinuxslashupdate.linuxslash{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="472" HEIGHT="81" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img70.png"
 ALT="\begin{tscreen}
ftp://ftp.wsc.com/pub/freeware/linux/update.linux/
\end{tscreen}">|; 

$key = q/{tscreen}http:slashslashsunsite.unc.eduslashLDPslash{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="428" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img71.png"
 ALT="\begin{tscreen}
http://sunsite.unc.edu/LDP/
\end{tscreen}">|; 

$key = q/{tscreen}<verb_mark>50<verb_mark>{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="667" HEIGHT="30" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img351.png"
 ALT="\begin{tscreen}
\verb! ClockChip ''icd2061a'' !
\end{tscreen}">|; 

$key = q/{tscreen}#{{em{umountslashdevslashfd0}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="247" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img297.png"
 ALT="\begin{tscreen}
\char93  {\em umount /dev/fd0}
\end{tscreen}">|; 

$key = q/{tscreen}#catslashprocslashinterrupt{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="319" HEIGHT="57" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img303.png"
 ALT="\begin{tscreen}
\char93  cat /proc/interrupt
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3060#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="240" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img393.png"
 ALT="\begin{tscreen}\begin{verbatim}TIMEOUT 3\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3067#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="263" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img400.png"
 ALT="\begin{tscreen}\begin{verbatim}OK ATDT\$TELEPHONE\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}#fdisk{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="83" HEIGHT="9" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img14.png"
 ALT="\begin{tscreen}
\char93  fdisk
\end{tscreen}">|; 

$key = q/{tscreen}#dpkg-lcparam{patr�nPaquete}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="130" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img38.png"
 ALT="\begin{tscreen}
\char93  dpkg -l \cparam{patr�nPaquete}
\end{tscreen}">|; 

$key = q/{tscreen}{fbox{minipage{{0.8textwidth}Nowisthetimeforallgoodhumanstocometotheaide'llgooutforpizzaandbeerunderline{.}~{}~{}~{}~{}minipage{}{{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="456" HEIGHT="141" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img204.png"
 ALT="\begin{tscreen}\fbox{\begin{minipage}{0.8\textwidth}
Now is the time for all goo...
...er\underline{.} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{}
\end{minipage}}\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3072#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="222" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img408.png"
 ALT="\begin{tscreen}
\begin{verbatim}...">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#lsenglish-listhistory-finalmasters-thesisnotes{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="300" HEIGHT="101" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img163.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  ls \\\\
english-list \\\\
history-final \\\\
masters-thesis \\\\
notes \\\\
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3079#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="175" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img410.png"
 ALT="\begin{tscreen}\begin{verbatim}...">|; 

$key = q/{tscreen}:shell{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="74" HEIGHT="9" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img220.png"
 ALT="\begin{tscreen}
:shell
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#ls-ifoobar22192bar22192fooslashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="554" HEIGHT="334" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img177.png"
 ALT="\begin{tscreen}
/home/larry\char93  ls -i foo bar \\\\
22192 bar   22192 foo \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}#cdslashusrslashinclude#rm-rfasmlinuxscsi#ln-sslashusrslashsrcslashlinuhlinuxlinux#ln-sslashusrslashsrcslashlinuxslashincludeslashscsiscsi{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="248" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img300.png"
 ALT="\begin{tscreen}
\char93  cd /usr/include \\\\
\char93  rm -rf asm linux scsi \\\\
...
...de/linux linux \\\\
\char93  ln -s /usr/src/linux/include/scsi scsi
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#vitest{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="145" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img199.png"
 ALT="\begin{tscreen}
/home/larry\char93  vi test
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#sortitems{>{listacompraslashhomeslashlarprabananasmanzanaszanahoriasslashhomeslashlarryslashpapers#{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="204" HEIGHT="187" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img161.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  sort items $&gt;$ listacompra \\\\
/home...
...ananas \\\\
manzanas \\\\
zanahorias \\\\
/home/larry/papers\char93
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#lsj?ejoeslashhomeslashlarry#lsf??gfrogslashhomeslashlarry#ls????fstuffslashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="160" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img153.png"
 ALT="\begin{tscreen}
/home/larry\char93  ls j?e \\\\
joe \\\\
/home/larry\char93  ls f?...
...\
/home/larry\char93  ls ????f \\\\
stuff \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{abib}{TCPslashIPNetworkAdministration}{CraigHunt}{O'ReillyandAssociates,1990}{0ibroenelquesediscutenlosconceptosydetallest�cnicosentornoaTCPslashIP.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="516" HEIGHT="214" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img436.png"
 ALT="\begin{abib}
{TCP/IP Network Administration}
{Craig Hunt}
{O'Reilly and Associat...
... que se discuten los conceptos y detalles
t�cnicos entorno a TCP/IP.}
\end{abib}">|; 

$key = q/{tscreen}Linuxlogin:{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="381" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img95.png"
 ALT="\begin{tscreen}
Linux login:
\end{tscreen}">|; 

$key = q/{tscreen}ftp:slashslashftp.redhat.comslashpubslashredhatslashcurrentslashi386slashimagesslashsupp.img{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="507" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img46.png"
 ALT="\begin{tscreen}
ftp://ftp.redhat.com/pub/redhat/current/i386/images/supp.img
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#cathistory-finalmasters-thesis{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="179" HEIGHT="144" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img156.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  cat history-final masters-thesis
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2872#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="435" HEIGHT="162" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img357.png"
 ALT="\begin{tscreen}\begin{verbatim}...">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2879#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="215" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img368.png"
 ALT="\begin{tscreen}\begin{verbatim}main:
...">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2372#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="225" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img244.png"
 ALT="\begin{tscreen}\begin{verbatim}...">|; 

$key = q/{tscreen}<verb_mark>53<verb_mark><verb_mark>54<verb_mark>`Secci�nDevices�loparal_mark>58<verb_mark><verb_mark>59<verb_mark><verb_mark>60<verb_mark>{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="613" HEIGHT="11" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img353.png"
 ALT="\begin{tscreen}
\verb!Section ''Device'' !\\\\
\verb!  ...">|; 

$key = q/{tscreen}slashhomeslashlarry#yes{>{slashdevslashnull{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="548" HEIGHT="78" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img185.png"
 ALT="\begin{tscreen}
/home/larry\char93  yes $&gt;$ /dev/null
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#{{em{echodollarfoo}holaall�slashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="196" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img226.png"
 ALT="\begin{tscreen}
/home/larry\char93  {\em echo \$foo} \\\\
hola all� \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}#{{em{shutdown-r20:00}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="102" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img242.png"
 ALT="\begin{tscreen}
\char93  {\em shutdown -r 20:00}
\end{tscreen}">|; 

$key = q/{tscreen}#ftformat--format-parameterqic40-205ft--mode-auto--omit-erase--discard-header{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="152" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img291.png"
 ALT="\begin{tscreen}
\char93  ftformat -format-parameter qic40-205ft -mode-auto -omit-erase -discard-header
\end{tscreen}">|; 

$key = q/{tscreen}ftp>{{em{lcdslashhomeslashdbslashmdwslashtmp}Localdirectorynowslashhomeslashdbslashmdwslashtmpftp>{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="77" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img465.png"
 ALT="\begin{tscreen}
ftp&gt; {\em lcd /home/db/mdw/tmp} \\\\
Local directory now /home/db/mdw/tmp \\\\
ftp&gt;
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashfoo#rmbellssellsslashhomeslashlarryslashfoo#ls-Fshellsslashhomeslashlarryslashfoo#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="282" HEIGHT="78" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img137.png"
 ALT="\begin{tscreen}
/home/larry/foo\char93  rm bells sells \\\\
/home/larry/foo\char93  ls -F \\\\
shells \\\\
/home/larry/foo\char93
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#{{em{echodollarHOME}slashhomeslashlarry{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="221" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img231.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  {\em echo \$HOME} \\\\
/home/larry
\end{tscreen}">|; 

$key = q/{tscreen}#pppd-dslashdevslashttyS038400&{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="428" HEIGHT="56" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img377.png"
 ALT="\begin{tscreen}
\char93  pppd -d /dev/ttyS0 38400 \&amp;
\end{tscreen}">|; 

$key = q/{tscreen}cdup{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="88" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img459.png"
 ALT="\begin{tscreen}
cdup
\end{tscreen}">|; 

$key = q/{dispitems}ditem{{{bf{Negrita}}Usadopararesaltar{{bf{conceptosnuevos},{{bf{AVISO�n''.Leadetenidamentelosp�rrafosmarcadosdeestaforma.{par{{dispitems};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="641" HEIGHT="592" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\begin{dispitems}
\ditem {{\bf Negrita}} Usado para resaltar {\bf conceptos nuev...
...n''. Lea detenidamente los
p�rrafos marcados de esta forma.
\par\end{dispitems}">|; 

$key = q/{tscreen}nombre:clavecifrada:UID:GID:nombrecompleto:dir.inicio:int�rprete{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="119" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img258.png"
 ALT="\begin{tscreen}
nombre:clave cifrada:UID:GID:nombre completo:dir.inicio:int�rprete
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#bg<verb_mark>30<verb_mark>yes>slashdevslashnull&slashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="178" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img193.png"
 ALT="\begin{tscreen}
/home/larry\char93  bg \\\\
\verb-[1]+- yes &gt;/dev/null \&amp; \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}Suinstrucci�n,porfavor:{{em{PS1=``{<verb_mark>31<verb_mark>}-''}slashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="229" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img233.png"
 ALT="\begin{tscreen}
Su instrucci�n , por favor: {\em PS1=\lq\lq {\verb'-w ...">|; 

$key = q/{tscreen}LILOboot:{linebreak{doslinux{linebreak{boot:{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="376" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img61.png"
 ALT="\begin{tscreen}
LILO boot: \linebreak dos linux \linebreak boot:
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#{{em{hacerlibro}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="48" HEIGHT="9" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img223.png"
 ALT="\begin{tscreen}
/home/larry\char93  {\em hacerlibro}
\end{tscreen}">|; 

$key = q/{tscreen}ftp:slashslashftp.debian.orgslashdebianslashDebian-1.2slashdisks-i386slashcurrentslashdselect.beginner.6.html{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="151" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img31.png"
 ALT="\begin{tscreen}
ftp://ftp.debian.org/debian/Debian-1.2/disks-i386/current/dselect.beginner.6.html
\end{tscreen}">|; 

$key = q/{dispitems}{par{index{cd@{{tt{cd}}ditem{{{tt{cd}}Cambiaeldirectoriodetrabajoactu{{tt{slashetcslashhosts}quecontieneelpatr�n``{{tt{loomer}''.{par{{dispitems};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="255" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img144.png"
 ALT="\begin{dispitems}
\par\index{cd@{\tt cd}}
\ditem {{\tt cd}}
Cambia el directorio...
...ro {\tt /etc/hosts} que contiene el patr�n \lq\lq {\tt loomer}''.
\par\end{dispitems}">|; 

$key = q/{abib}{Unix.SistemaVVersi�n4}{KennethH.Rosenyotros}{OsborneslashMcGrawHill,1998}maconcretosinoquehabladelosdiversosUnixenusoactualmente,incluidoLinux}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="516" HEIGHT="232" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img448.png"
 ALT="\begin{abib}
{Unix. Sistema V Versi�n 4}
{Kenneth H. Rosen y otros}
{Osborne/McG...
...no que habla de los diversos Unix en uso actualmente, incluido Linux}
\end{abib}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2768#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="315" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img331.png"
 ALT="\begin{tscreen}\begin{verbatim}Section ''Pointer''Protocol ''MouseSystems''...
...tones Logitech de 3 botones
...">|; 

$key = q/{abib}{TheXWindowSystem:AUser'sGuide}{NiallMansfield}{Addison-Wesley}{0-201-5134muchadelapotenciaqueproporcionaXnoresultademasiadoobviaaprimeravista.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="517" HEIGHT="209" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img438.png"
 ALT="\begin{abib}
{The X Window System: A User's Guide}
{Niall Mansfield}
{Addison-We...
...encia que proporciona X no resulta
demasiado obvia a primera vista.}
\end{abib}">|; 

$key = q/{tscreen}lscparam{file}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="516" HEIGHT="231" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img456.png"
 ALT="\begin{tscreen}
ls \cparam{file}
\end{tscreen}">|; 

$key = q/{tscreen}InstalltheBaseSystemNT{``Instalarelsistemabase''}.{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="287" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img24.png"
 ALT="\begin{tscreen}
Install the Base System\NT{\lq\lq Instalar el sistema base''}.
\end{tscreen}">|; 

$key = q/{tscreen}#tarcvfslashdevslashqft0slashetc{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="239" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img289.png"
 ALT="\begin{tscreen}
\char93  tar cvf /dev/qft0 /etc
\end{tscreen}">|; 

$key = q/{tscreen}{fbox{minipage{{0.8textwidth}NowisthetimeforallgoodhumanstocometotheaidgooutforpizzaandDietCokeunderline{.}~{}~{}~{}~{}minipage{}{{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="456" HEIGHT="141" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img206.png"
 ALT="\begin{tscreen}\fbox{\begin{minipage}{0.8\textwidth}
Now is the time for all goo...
...e\underline{.} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{}
\end{minipage}}\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2773#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="299" HEIGHT="11" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img338.png"
 ALT="\begin{tscreen}\begin{verbatim}Section ''Screen''
Driver ''Accel''
Device '...
...Port 0 0
Virtual 1024 768
EndSubsection
EndSection\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}papersslashenglish-lit{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="143" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img117.png"
 ALT="\begin{tscreen}
papers/english-lit
\end{tscreen}">|; 

$key = q/{tscreen}#ln--sfslashusrslashX11R6slashbinslashXF86_MONOslashusrslashX11R6slashbinslashX{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="282" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img322.png"
 ALT="\begin{tscreen}
\char93  ln -sf /usr/X11R6/bin/XF86\_MONO  /usr/X11R6/bin/X
\end{tscreen}">|; 

$key = q/{tscreen}#ifconfig{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="299" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img378.png"
 ALT="\begin{tscreen}
\char93  ifconfig
\end{tscreen}">|; 

$key = q/{abib}{RunningLinux(2ndEdition)}{MattWelsh,LarKaufman}{O'ReillyandAssociates,199entodelsistema,herramientasparaeldesarrollodedocumentosyprogramaci�n.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="516" HEIGHT="258" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img427.png"
 ALT="\begin{abib}
{Running Linux (2nd Edition) }
{Matt Welsh, Lar Kaufman }
{O'Reilly...
...ema, herramientas para el desarrollo
de documentos y programaci�n. }
\end{abib}">|; 

$key = q/{tscreen}ftpslashslashftp.redhat.comslashpubslashredhatslashcurrentslashi386slashimagesslashboot.img{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="541" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img45.png"
 ALT="\begin{tscreen}
ftp//ftp.redhat.com/pub/redhat/current/i386/images/boot.img
\end{tscreen}">|; 

$key = q/{tscreen}#{{em{passwdmanuel}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="301" HEIGHT="34" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img262.png"
 ALT="\begin{tscreen}
\char93  {\em passwd manuel}
\end{tscreen}">|; 

$key = q/{tscreen}lp_init:lp1exists(0),usingpollingdriver{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="154" HEIGHT="11" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img94.png"
 ALT="\begin{tscreen}
lp\_init: lp1 exists (0), using polling driver
\end{tscreen}">|; 

$key = q/{tscreen}#mkdirslashzip#chmod0755slashzip{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="213" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img284.png"
 ALT="\begin{tscreen}
\char93  mkdir /zip \\\\
\char93  chmod 0755 /zip
\end{tscreen}">|; 

$key = q/{tscreen}LILOboot:{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="242" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img13.png"
 ALT="\begin{tscreen}
LILO boot:
\end{tscreen}">|; 

$key = q/{tscreen}ftp>{{em{dir}200PORTcommandsuccessful.150OpeningASCIImodedataconnectionTransfercomplete.921bytesreceivedin0.24seconds(3.7Kbytesslashs)ftp>{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="471" HEIGHT="78" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img461.png"
 ALT="\begin{tscreen}
ftp&gt; {\em dir} \\\\
200 PORT command successful. \\\\
150 Opening ...
...te. \\\\
921 bytes received in 0.24 seconds (3.7 Kbytes/s) \\\\
ftp&gt;
\end{tscreen}">|; 

$key = q/{tscreen}Shell-init:permissiondenied{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="99" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img107.png"
 ALT="\begin{tscreen}
Shell-init: permission denied
\end{tscreen}">|; 

$key = q/{tscreen}#ddif=cparam{imagen}of=cparam{unidaddedisquete}bs=512conv=sync;sync{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="184" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="\begin{tscreen}
\char93  dd if=\cparam{imagen} of=\cparam{unidad de disquete} bs=512 conv=sync ; sync
\end{tscreen}">|; 

$key = q/{tscreen}getcparam{nombre-remoto}cparam{nombre-local}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="33" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img466.png"
 ALT="\begin{tscreen}
get \cparam{nombre-remoto} \cparam{nombre-local}
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#ls*frogjoestuffslashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="555" HEIGHT="3774" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img148.png"
 ALT="\begin{tscreen}
/home/larry\char93  ls * \\\\
frog     joe     stuff \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3049#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="214" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img380.png"
 ALT="\begin{tscreen}\begin{verbatim}Kernel routing table
Destination Gateway Genm...
...00 0 35 eth0
default 10.144.153.3 * UG 1500 0 5 ppp0\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}:!ls-F{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="9" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img219.png"
 ALT="\begin{tscreen}
:! ls -F
\end{tscreen}">|; 

$key = q/{tscreen}hd=cparam{cylindros},cparam{cabezas},cparam{sectores}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="294" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img101.png"
 ALT="\begin{tscreen}
hd=\cparam{cylindros},\cparam{cabezas},\cparam{sectores}
\end{tscreen}">|; 

$key = q/{tscreen}#{{em{cp-aslashbinslashloginslashmntslashbinslashlogin}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="275" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img318.png"
 ALT="\begin{tscreen}
\char93  {\em cp -a /bin/login /mnt/bin/login}
\end{tscreen}">|; 

$key = q/{tscreen}#SuperProbe-info{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="442" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img326.png"
 ALT="\begin{tscreen}
\char93  SuperProbe -info
\end{tscreen}">|; 

$key = q/{tscreen}#tarcvf-slashetc{mid{gzip-9c{>{backup.tar.gz{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="170" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img275.png"
 ALT="\begin{tscreen}
\char93  tar cvf - /etc $\mid$ gzip -9c $&gt;$ backup.tar.gz
\end{tscreen}">|; 

$key = q/{tscreen}#tarcvfbackup.tarslashetcslashhostsslashetcslashgroupslashetcslashpasswd{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="198" HEIGHT="74" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img268.png"
 ALT="\begin{tscreen}
\char93  tar cvf backup.tar /etc/hosts /etc/group /etc/passwd
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3066#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="220" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img399.png"
 ALT="\begin{tscreen}\begin{verbatim}TIMEOUT 30\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}slashbinslashdevslashetcslashhomeslashlibslashlost+foundslashprocslashrootslashsbinslashusrslashvar{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="555" HEIGHT="1375" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="\begin{tscreen}
/bin \\\\
/dev \\\\
/etc \\\\
/home \\\\
/lib \\\\
/lost+found \\\\
/proc \\\\
/root \\\\
/sbin \\\\
/usr \\\\
/var \\\\
\end{tscreen}">|; 

$key = q/{tscreen}{fbox{minipage{{0.8textwidth}Nowisthetimeforallunderline{h}umanstocometotheaidoftheparty.~{}~{}~{}~{}~{}minipage{}{{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="456" HEIGHT="141" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img208.png"
 ALT="\begin{tscreen}\fbox{\begin{minipage}{0.8\textwidth}
Now is the time for all \un...
...party. \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{}
\end{minipage}}\end{tscreen}">|; 

$key = q/{tscreen}ftp:slashslashftp.redhat.comslashpubslashredhatslashdosslashfdips11.zip{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="558" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img48.png"
 ALT="\begin{tscreen}
ftp://ftp.redhat.com/pub/redhat/dos/fdips11.zip
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3071#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="152" HEIGHT="9" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img404.png"
 ALT="\begin{tscreen}\begin{verbatim}\$[]\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}#tarzcvfslashzipslashlocal.tar.gzslashusrslashlocal{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="145" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img288.png"
 ALT="\begin{tscreen}
\char93  tar zcvf /zip/local.tar.gz /usr/local
\end{tscreen}">|; 

$key = q/{tscreen}<verb_mark>61<verb_mark>{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="169" HEIGHT="34" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img356.png"
 ALT="\begin{tscreen}
\verb!X &gt; /tmp/x.out 2&gt;&amp;1 !
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#cdpapersslashhomeslashlarryslashpapers#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="10" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img123.png"
 ALT="\begin{tscreen}
/home/larry\char93  cd papers \\\\
/home/larry/papers\char93
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#ls-lfoobar<verb_mark>21<verb_mark><verb_mark>22<verb_mark>slashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="196" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img179.png"
 ALT="\begin{tscreen}
/home/larry\char93  ls -l foo bar \\\\
\verb!-rw-r-r- 2 root ro...
...-rw-r-r- 2 root root 12 Aug 5 16:50 foo! \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#yes{>{slashdevslashnull&<verb_mark>25<verb_mark>slashhomeslashlarry#{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="231" HEIGHT="153" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img186.png"
 ALT="\begin{tscreen}
/home/larry\char93  yes $&gt;$ /dev/null \&amp; \\\\
\verb+[1] 164+ \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}vicparam{fichero}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="146" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img198.png"
 ALT="\begin{tscreen}
vi \cparam{fichero}
\end{tscreen}">|; 

$key = q/{tscreen}#mountslashdevslashsda4slashmnt{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="195" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img283.png"
 ALT="\begin{tscreen}
\char93  mount /dev/sda4 /mnt
\end{tscreen}">|; 

$key = q/{tscreen}slashbinslashhostnameloomer.vpizza.com{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="410" HEIGHT="32" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img363.png"
 ALT="\begin{tscreen}
/bin/hostname loomer.vpizza.com
\end{tscreen}">|; 

$key = q/{tscreen}{linux}-alert-request@tarsier.cv.nrao.edu{linux}-security-request@redhat.com{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="411" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img91.png"
 ALT="\begin{tscreen}
{\linux}-alert-request@tarsier.cv.nrao.edu \\\\
{\linux}-security-request@redhat.com
\end{tscreen}">|; 

$key = q/{tscreen}slashlibslashmodulesslash2.0.30slashmiscslashftape.oslashlibslashmodulet-compressor.oslashlibslashmodulesslash2.0.30slashmiscslashzftape.o{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="153" HEIGHT="118" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img308.png"
 ALT="\begin{tscreen}
/lib/modules/2.0.30/misc/ftape.o \\\\
/lib/modules/2.0.30/misc/zft-compressor.o \\\\
/lib/modules/2.0.30/misc/zftape.o
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashfoo#moreshells{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="264" HEIGHT="78" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img138.png"
 ALT="\begin{tscreen}
/home/larry/foo\char93  more shells
\end{tscreen}">|; 

$key = q/{tscreen}#dpkg-scparam{paquete}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="172" HEIGHT="36" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img37.png"
 ALT="\begin{tscreen}
\char93  dpkg -s \cparam{paquete}
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2878#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="214" HEIGHT="29" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img366.png"
 ALT="\begin{tscreen}\begin{verbatim}...">|; 

$key = q/{tscreen}#tarcvfbackup.tarslashetc#gzip-9backup.tar{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="170" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img273.png"
 ALT="\begin{tscreen}
\char93  tar cvf backup.tar /etc \\\\
\char93  gzip -9 backup.tar
\end{tscreen}">|; 

$key = q/{tscreen}#rmslashswap{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="384" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img256.png"
 ALT="\begin{tscreen}
\char93  rm /swap
\end{tscreen}">|; 

$key = q/{tscreen}#shutdown--rnow{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="413" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img93.png"
 ALT="\begin{tscreen}
\char93  shutdown -r now
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim1149#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="299" HEIGHT="72" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img57.png"
 ALT="\begin{tscreen}\begin{verbatim}Domainname: infomagic.com
Host name: vador.info...
...ita
Tertiary nameserver IP: Introducir si se necesita\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#catlistacomprabananasmanzanaszanahoriasslashhomeslashlarryslashpapers#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="196" HEIGHT="144" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img160.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  cat listacompra \\\\
bananas \\\\
manzanas \\\\
zanahorias \\\\
/home/larry/papers\char93
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#%2{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="152" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img197.png"
 ALT="\begin{tscreen}
/home/larry\char93  \%2
\end{tscreen}">|; 

$key = q/{abib}{LinuxStart-UpGuide:ASelf-ContainedIntroduction}{FredHantelmann,A.Faber(Tr,�rdenesb�sicasde{linux}ylost�picospaquetesdedesarrolloyaplicaciones.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="515" HEIGHT="212" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img429.png"
 ALT="\begin{abib}
{Linux Start-Up Guide : A Self-Contained Introduction }
{Fred Hante...
...s de
{\linux} y los t�picos paquetes de desarrollo y aplicaciones. }
\end{abib}">|; 

$key = q/{abib}{LinuxKernelInternals}{MichaelBeck}{Addison-Wesley,1997}{0201331438}{dollar41.95}{Unvistazoaln�cleoyalgunosdetallest�cnicossobreeln�cleoLinux}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="516" HEIGHT="236" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img445.png"
 ALT="\begin{abib}
{Linux Kernel Internals}
{Michael Beck}
{Addison-Wesley, 1997}
{020...
... vistazo al n�cleo y algunos detalles t�cnicos sobre el n�cleo Linux}
\end{abib}">|; 

$key = q/{tscreen}#dpkg-Scparam{patr�nFichero}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="130" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img40.png"
 ALT="\begin{tscreen}
\char93  dpkg -S \cparam{patr�nFichero}
\end{tscreen}">|; 

$key = q/{tscreen}kiwi:Xv8Q981g71oKK:102:100:LauraVilla:slashhomeslashkiwi:slashbinslashbash{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="127" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img259.png"
 ALT="\begin{tscreen}
kiwi:Xv8Q981g71oKK:102:100:Laura Villa:/home/kiwi:/bin/bash
\end{tscreen}">|; 

$key = q/{abib}{SistemasAbiertos}{LuisJ.CearraZabala}{UniversidadPolit�cnicadeMadrid,1998enes,desdelasm�sb�sicashastalaedici�ndescriptsconexpresionesregulares}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="515" HEIGHT="280" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img451.png"
 ALT="\begin{abib}
{Sistemas Abiertos}
{Luis J. Cearra Zabala}
{Universidad Polit�cnic...
...as m�s b�sicas hasta la edici�n de scripts con expresiones regulares}
\end{abib}">|; 

$key = q/{tscreen}s2:12345:respawn:slashsbinslashagetty-L9600ttyS1vt100{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="161" HEIGHT="11" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img245.png"
 ALT="\begin{tscreen}
s2:12345:respawn:/sbin/agetty -L 9600 ttyS1 vt100
\end{tscreen}">|; 

$key = q/{tscreen}ifconfigsl0128.253.154.32pointopoint128.253.154.2{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="137" HEIGHT="29" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img365.png"
 ALT="\begin{tscreen}
ifconfig sl0 128.253.154.32 pointopoint 128.253.154.2
\end{tscreen}">|; 

$key = q/{abib}{LinuxM�ximaSeguridad}{An�nimo}{PrenticeHallslashPearson,2000}{84-8322-244�ticascorrectasdeseguridad.Muyrecomendableparalosqueseinicieneneltema}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="515" HEIGHT="254" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img449.png"
 ALT="\begin{abib}
{Linux M�xima Seguridad}
{An�nimo}
{Prentice Hall/Pearson, 2000}
{8...
...as de seguridad. Muy recomendable para los que se inicien en el tema}
\end{abib}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#cd.{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="220" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img126.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  cd  .
\end{tscreen}">|; 

$key = q/{tscreen}http:slashslashwww.redhat.comslashpubslashredhatslashupdatesslashtextsl{version}slashimages{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="385" HEIGHT="32" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img59.png"
 ALT="\begin{tscreen}
http://www.redhat.com/pub/redhat/updates/\textsl{version}/images
\end{tscreen}">|; 

$key = q/{tscreen}{fbox{minipage{{0.8textwidth}COWISTHETIMEFORALLWOMENTOCOMETOTHEAIDOFTHEHUNGRY.~{}~{}~{}~{}~{}:efoounderline{}minipage{}{{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="455" HEIGHT="141" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img213.png"
 ALT="\begin{tscreen}\fbox{\begin{minipage}{0.8\textwidth}
COW IS THE TIME FOR ALL WOM...
...\\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
:e foo\underline{ }
\end{minipage}}\end{tscreen}">|; 

$key = q/{tscreen}128.253.154.32goober.norelco.com{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="281" HEIGHT="34" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img313.png"
 ALT="\begin{tscreen}
128.253.154.32       goober.norelco.com
\end{tscreen}">|; 

$key = q/{tscreen}From:widsith@phantom.com(DavidDevejian)hfill{linebreak{Date:10Jan199404,tantosiesporafici�n,estudios,hackearoaprenderaadministrarsistemas.{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="459" HEIGHT="294" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img68.png"
 ALT="\begin{tscreen}
From: widsith@phantom.com (David Devejian) \hfill \linebreak Dat...
... por afici�n, estudios, hackear o aprender
a administrar sistemas.
\end{tscreen}">|; 

$key = q/{tscreen}#passwdroot{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="473" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img86.png"
 ALT="\begin{tscreen}
\char93  passwd root
\end{tscreen}">|; 

$key = q/{tscreen}DebianGNUslashLinuxdselectpackagehandlingfrontend.{linebreak{0.[A]ccessemoveRemoveunwantedsoftware.{linebreak{6.[Q]uitQuitdselect.{tscreen};FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="696" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img32.png"
 ALT="\begin{tscreen}
Debian GNU/Linux dselect package handling front end. \linebreak0...
...emove Remove unwanted software. \linebreak 6. [Q]uit Quit dselect.
\end{tscreen}">|; 

$key = q/{tscreen}ConfigureDeviceDriversNT{``ConfigurarControladoresdeDispositivo''}{tscreen};FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="304" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img26.png"
 ALT="\begin{tscreen}
Configure Device Drivers\NT{\lq\lq Configurar Controladores de Dispositivo''}
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#moreslashhomeslashlarryslashpapersslashhistory-final{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="205" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img119.png"
 ALT="\begin{tscreen}
/home/larry\char93  more /home/larry/papers/history-final
\end{tscreen}">|; 

$key = q/{tscreen}#tarcvfbackup.tarslashetc{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="127" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img266.png"
 ALT="\begin{tscreen}
\char93  tar cvf backup.tar /etc
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2767#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="153" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img330.png"
 ALT="\begin{tscreen}\begin{verbatim}Section ''Keyboard''
Protocol ''Standard''
AutoRepeat 500 5
ServerNumLock
EndSection\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}127.0.0.1floof.orglocalhost{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="352" HEIGHT="57" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img312.png"
 ALT="\begin{tscreen}
127.0.0.1       floof.org localhost
\end{tscreen}">|; 

$key = q/{tscreen}{fbox{minipage{{0.8textwidth}Nowritesincelastchange(":edit!"overrides)minipage{}{{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="456" HEIGHT="140" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img214.png"
 ALT="\begin{tscreen}\fbox{\begin{minipage}{0.8\textwidth}
No write since last change ('':edit!'' overrides)
\end{minipage}}\end{tscreen}">|; 

$key = q/{tscreen}#cdslash#tarxvfbackup.tar{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="134" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img269.png"
 ALT="\begin{tscreen}
\char93  cd / \\\\
\char93  tar xvf backup.tar
\end{tscreen}">|; 

$key = q/{tscreen}ftp>{{em{hash}Hashmarkprintingon(8192bytesslashhashmark).ftp>{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="10" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img463.png"
 ALT="\begin{tscreen}
ftp&gt; {\em hash} \\\\
Hash mark printing on (8192 bytes/hash mark). \\\\
ftp&gt;
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#lsfrogjoestuffslashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="557" HEIGHT="2291" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img146.png"
 ALT="\begin{tscreen}
/home/larry\char93  ls \\\\
frog     joe     stuff \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#bg%3{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="178" HEIGHT="56" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img196.png"
 ALT="\begin{tscreen}
/home/larry\char93  bg \%3
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2772#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="359" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img337.png"
 ALT="\begin{tscreen}\begin{verbatim}Section ''Device''
Identifier '' ...">|; 

$key = q/{tscreen}ReboottheSystemNT{``Reiniciarelsistema''}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="160" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img30.png"
 ALT="\begin{tscreen}
Reboot the System\NT{\lq\lq Reiniciar el sistema''}
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2779#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="222" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img348.png"
 ALT="\begin{tscreen}\begin{verbatim}Clocks 25 28 38 36 40 45 32 0\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}#cdslashusrslashsrc#gzip-cdpatch-2.0.32.gz{mid{patch-p0#gzip-cdpatch-2.0.33.gz{mid{patch-p0{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="187" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img299.png"
 ALT="\begin{tscreen}
\char93  cd /usr/src \\\\
\char93  gzip -cd patch-2.0.32.gz $\mid$ patch -p0 \\\\
\char93  gzip -cd patch-2.0.33.gz $\mid$ patch -p0
\end{tscreen}">|; 

$key = q/{tscreen}dpkg--configurecparam{paquete}{tscreen};FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="224" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img35.png"
 ALT="\begin{tscreen}
dpkg -configure \cparam{paquete}
\end{tscreen}">|; 

$key = q/{tscreen}cpcparam{imagen}cparam{unidaddedisquete};sync{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="457" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img12.png"
 ALT="\begin{tscreen}
cp \cparam{imagen} \cparam{unidad de disquete} ; sync
\end{tscreen}">|; 

$key = q/{abib}{BourneShellTutorial}{PhilHughes}{SpecializedSystemsConsultants}{0-916151-adasenlashellyunres�mende3p�ginasconalgunasdelas�rdenesUNIXm�susadas.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="515" HEIGHT="301" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img433.png"
 ALT="\begin{abib}
{Bourne Shell Tutorial}
{Phil Hughes}
{Specialized Systems Consulta...
...un
res�men de 3 p�ginas con algunas de las �rdenes UNIX m�s usadas.}
\end{abib}">|; 

$key = q/{tscreen}YourIPaddressis128.253.154.44.Serveraddressis128.253.154.2.{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="266" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img367.png"
 ALT="\begin{tscreen}
Your IP address is 128.253.154.44. \\\\
Server address is 128.253.154.2.
\end{tscreen}">|; 

$key = q/{tscreen}#gunzip-cbackup.tar.gz{mid{tarxvf-{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="171" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img276.png"
 ALT="\begin{tscreen}
\char93  gunzip -c backup.tar.gz $\mid$ tar xvf -
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3053#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="170" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img386.png"
 ALT="\begin{tscreen}\begin{verbatim}-- sunsite.unc.edu ping statistics --
5 pac...
... loss
round-trip min/avg/max = 169.8/176.3/190.1 ms\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}append="lp=0x378,0"{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="247" HEIGHT="100" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img302.png"
 ALT="\begin{tscreen}
append=''lp=0x378,0''
\end{tscreen}">|; 

$key = q/{tscreen}#chmod755slash{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="248" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img108.png"
 ALT="\begin{tscreen}
\char93  chmod 755 /
\end{tscreen}">|; 

$key = q/{tscreen}ftpcparam{hostname}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="511" HEIGHT="148" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img452.png"
 ALT="\begin{tscreen}
ftp \cparam{hostname}
\end{tscreen}">|; 

$key = q/{dispitems}%latex2htmlidmarker20643{par{ditem{{{em{Laspreguntasconrespuestam�sfrerosobre{linux}queselistanenelAp�ndice~ref{app-ftplist-num}.{par{{dispitems};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="229" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img417.png"
 ALT="\begin{dispitems}
% latex2html id marker 20643\par\ditem {{\em Las preguntas c...
...{\linux} que se listan en el
Ap�ndice&nbsp;\ref{app-ftplist-num}.
\par\end{dispitems}">|; 

$key = q/{tscreen}slashhomeslashlarry#manls{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="238" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img139.png"
 ALT="\begin{tscreen}
/home/larry\char93  man ls
\end{tscreen}">|; 

$key = q/{abib}{CorelLinux}{FranciscoCharteOjeda}{Anaya,2000}{84-415-1047-4}{12,02{euro}}{Unagu�apr�cticaqueseadjuntaconunCDconladistribuci�nCorelLinux}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="515" HEIGHT="192" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img447.png"
 ALT="\begin{abib}
{Corel Linux}
{Francisco Charte Ojeda}
{Anaya, 2000}
{84-415-1047-4...
...�a pr�ctica que se adjunta con un CD con la distribuci�n Corel Linux}
\end{abib}">|; 

$key = q/{tscreen}slashhomeslashlarry#{{em{PAGER=``more''}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="265" HEIGHT="57" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img230.png"
 ALT="\begin{tscreen}
/home/larry\char93  {\em PAGER=\lq\lq more''}
\end{tscreen}">|; 

$key = q/{tscreen}mget*.*{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="187" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img102.png"
 ALT="\begin{tscreen}
mget *.*
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3065#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="144" HEIGHT="9" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img398.png"
 ALT="\begin{tscreen}\begin{verbatim}OK-+++\c-OK ATH0\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#eatdirteat:commandnotfoundslashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="196" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img115.png"
 ALT="\begin{tscreen}
/home/larry\char93  eat dirt \\\\
eat: command not found \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3070#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="152" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img403.png"
 ALT="\begin{tscreen}\begin{verbatim}assword: \$PASSWORD\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashfoo#cpslashetcslashtermcap.slashhomeslashlarrysshlarryslashfoo#ls--Fbellsshellstermcapslashhomeslashlarryslashfoo#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="188" HEIGHT="188" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img135.png"
 ALT="\begin{tscreen}
/home/larry/foo\char93  cp /etc/termcap  . \\\\
/home/larry/foo...
...ells     shells     termcap \\\\
/home/larry/foo\char93
\end{tscreen}">|; 

$key = q/{tscreen}#swapoffslashswap{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="153" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img255.png"
 ALT="\begin{tscreen}
\char93  swapoff /swap
\end{tscreen}">|; 

$key = q/{tscreen}ftpshoop.vpizza.com{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="514" HEIGHT="169" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img453.png"
 ALT="\begin{tscreen}
ftp shoop.vpizza.com
\end{tscreen}">|; 

$key = q/{tscreen}mousehouselogin:{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="109" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img109.png"
 ALT="\begin{tscreen}
mousehouse login:
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3082#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="677" HEIGHT="291" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img415.png"
 ALT="\begin{tscreen}\begin{verbatim}Oct 21 16:10:45 hwin pppd[19873]: Interrupt re...
... terminated.
Oct 21 16:10:46 hwin pppd[19873]: Exit.\end{verbatim}\end{tscreen}">|; 

$key = q/{abib}{Samba:IntegratingUNIXandWindows}{JohnD.Blair}{SpecializedSystemsConsultanx}oFreeBSD,SambaofreceunaalternativadebajocostealNTServerparaWindows.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="515" HEIGHT="258" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img435.png"
 ALT="\begin{abib}
{Samba: Integrating UNIX and Windows}
{John D. Blair}
{Specialized ...
...mba ofrece una alternativa de bajo coste
al NT Server para Windows.}
\end{abib}">|; 

$key = q/{tscreen}0slashdevslashttyS0(oCOM1:enDOS)1slashdevslashttyS1(oCOM2:enDOS)2slashdevslashttyS2(oCOM3:enDOS)3slashdevslashttyS3(oCOM4:enDOS){tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="144" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img81.png"
 ALT="\begin{tscreen}
0 /dev/ttyS0 (o COM1: en DOS) \\\\
1 /dev/ttyS1 (o COM2: en DOS) ...
... /dev/ttyS2 (o COM3: en DOS) \\\\
3 /dev/ttyS3 (o COM4: en DOS) \\\\
\end{tscreen}">|; 

$key = q/{tscreen}{fbox{minipage{{0.8textwidth}underline{N}owisthetimeforallgoodhumanstocometotheaidoftheparty.~{}~{}~{}~{}~{}minipage{}{{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="455" HEIGHT="141" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img207.png"
 ALT="\begin{tscreen}\fbox{\begin{minipage}{0.8\textwidth}
\underline{N}ow is the time...
...arty. \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{}
\end{minipage}}\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#yes&{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="378" HEIGHT="78" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img194.png"
 ALT="\begin{tscreen}
/home/larry\char93  yes \&amp;
\end{tscreen}">|; 

$key = q/{tscreen}mousehouselogin:larryPassword:{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="144" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img110.png"
 ALT="\begin{tscreen}
mousehouse login: larry \\\\
Password:
\end{tscreen}">|; 

$key = q/{tscreen}Console:colourEGA+80x25,8virtualconsolesSerialdriverversion3.96withnoset0x02e8(irq=3)isa16550Alp_init:lp1exists(0),usingpollingdriverldots{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="100" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img96.png"
 ALT="\begin{tscreen}
Console: colour EGA+ 80x25, 8 virtual consoles \\\\
Serial driver...
...550A \\\\
lp\_init: lp1 exists (0), using polling driver \\\\
\ldots
\end{tscreen}">|; 

$key = q/{tscreen}Theinstallationprogramisdeterminingthecurrentstateofyoursystem.{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="187" HEIGHT="34" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img18.png"
 ALT="\begin{tscreen}
The installation program is determining the current state of your
system.
\end{tscreen}">|; 

$key = q/{tscreen}quit{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="522" HEIGHT="335" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img468.png"
 ALT="\begin{tscreen}
quit
\end{tscreen}">|; 

$key = q/{tscreen}{fbox{minipage{{0.8textwidth}COWISTHETIMEFORALLWOMENTOCOMETOTHEAIDOFTHEHUNGRY.~{}~{}~{}~{}~{}:e!foounderline{}minipage{}{{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="455" HEIGHT="163" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img215.png"
 ALT="\begin{tscreen}\fbox{\begin{minipage}{0.8\textwidth}
COW IS THE TIME FOR ALL WOM...
...\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
:e! foo\underline{ }
\end{minipage}}\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2877#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="265" HEIGHT="430" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img362.png"
 ALT="\begin{tscreen}\begin{verbatim}domain norelco.com
nameserver 127.253.154.5\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}#ddif=slashdevslashzeroof=slashswapbs=1024count=8208{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="402" HEIGHT="93" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img252.png"
 ALT="\begin{tscreen}
\char93  dd if=/dev/zero of=/swap bs=1024 count=8208
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#rmfoo{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="187" HEIGHT="57" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img178.png"
 ALT="\begin{tscreen}
/home/larry\char93  rm foo
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#{{em{chmodu+xhacerlibro}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="57" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img224.png"
 ALT="\begin{tscreen}
/home/larry\char93  {\em chmod u+x hacerlibro}
\end{tscreen}">|; 

$key = q/{tscreen}lsslashbinslashsbinslashusrslashbinslashusrslashsbin{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="188" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img20.png"
 ALT="\begin{tscreen}
ls /bin /sbin /usr/bin /usr/sbin
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim1148#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="161" HEIGHT="11" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img56.png"
 ALT="\begin{tscreen}\begin{verbatim}IP Address: 192.168.181.21
Netmask: 255.255.255...
...eway: 192.168.181.1
Primary Nameserver: 192.168.181.2\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}#{{em{umountslashdevslashhda2}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="77" HEIGHT="8" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img251.png"
 ALT="\begin{tscreen}
\char93  {\em umount /dev/hda2}
\end{tscreen}">|; 

$key = q/{tscreen}shutdowncparam{tiempo}cparam{mensaje-de-aviso}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="204" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img241.png"
 ALT="\begin{tscreen}
shutdown \cparam{tiempo} \cparam{mensaje-de-aviso}
\end{tscreen}">|; 

$key = q/{tscreen}#dpkg-Lcparam{paquete}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="167" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img39.png"
 ALT="\begin{tscreen}
\char93  dpkg -L \cparam{paquete}
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#mkdirfooslashhomeslashlarry#ls-FMailslashfooslashlerry#cdfooslashhomeslashlarryslashfoo#lsslashhomeslashlarryslashfoo#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="151" HEIGHT="99" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img134.png"
 ALT="\begin{tscreen}
/home/larry\char93  mkdir foo \\\\
/home/larry\char93  ls -F \\\\
...
...cd foo \\\\
/home/larry/foo\char93  ls \\\\
/home/larry/foo\char93
\end{tscreen}">|; 

$key = q/{tscreen}Thesystemishalted{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="617" HEIGHT="691" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img243.png"
 ALT="\begin{tscreen}
The system is halted
\end{tscreen}">|; 

$key = q/{tscreen}24-Aug-95NOTA:IntentaractualizaraSlackwareELFdesdeSlackwarea.outcausar�indudablementetodaclasedeproblemas.Nolohagas.{par{PatrickVolkerding{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="471" HEIGHT="146" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img69.png"
 ALT="\begin{tscreen}
24-Aug-95 NOTA: Intentar actualizar a Slackware ELF desde Slackw...
...ente toda clase de problemas. No lo hagas.
\par Patrick Volkerding
\end{tscreen}">|; 

$key = q/{tscreen}PartitionaHardDisk{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="273" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img21.png"
 ALT="\begin{tscreen}
Partition a Hard Disk
\end{tscreen}">|; 

$key = q/{tscreen}hartr--hartrppp{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="213" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img407.png"
 ALT="\begin{tscreen}
hartr-hartr ppp
\end{tscreen}">|; 

$key = q/{tscreen}append="lp=0x378,0ppa=0x278,7"{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="462" HEIGHT="56" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img305.png"
 ALT="\begin{tscreen}
append=''lp=0x378,0 ppa=0x278,7''
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#lsslashetcpreform{<verbatim_mark>verbatim2039#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="222" HEIGHT="122" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img132.png"
 ALT="\begin{tscreen}
/home/larry\char93  ls /etc
\begin{verbatim}Images ftpusers l...
...tty utmp
ftpaccess lilo rc services wtmp
/home/larry ...">|; 

$key = q/{tscreen}http:slashslashsunsite.doc.ic.ac.ukslashsunsiteslashaccessslashnfs.htmlashr�plicaS.TXThttp:slashslashwww.cs.us.esslasharchiveslashnfs.html{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="231" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img72.png"
 ALT="\begin{tscreen}
http://sunsite.doc.ic.ac.uk/sunsite/access/nfs.html \\\\
ftp://ft...
...lackware/r�plicaS.TXT \\\\
http://www.cs.us.es/archive/nfs.html \\\\
\end{tscreen}">|; 

$key = q/{tscreen}#tarcvfbackup.tarslashetc#gzipbackup.tar{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="187" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img278.png"
 ALT="\begin{tscreen}
\char93  tar cvf backup.tar /etc \\\\
\char93  gzip backup.tar
\end{tscreen}">|; 

$key = q/{tscreen}#route-n{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="796" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img379.png"
 ALT="\begin{tscreen}
\char93  route -n
\end{tscreen}">|; 

$key = q/{tscreen}opensunsite.unc.educdslashpubslash{linux}dirquit{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="208" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img473.png"
 ALT="\begin{tscreen}
open sunsite.unc.edu \\\\
cd /pub/{\linux} \\\\
dir \\\\
quit
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#cd..slashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="325" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img125.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  cd  .. \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim629#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="615" HEIGHT="372" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="\begin{tscreen}\begin{verbatim}File system 1024-blocks Used Available Capacity...
...% /usr/X11R6
/dev/hdb1 499620 455044 18773 96% /home
\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}manadduser{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="10" HEIGHT="34" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img65.png"
 ALT="\begin{tscreen}
man adduser
\end{tscreen}">|; 

$key = q/{tscreen}root:*:0:usuarios:*:100:mdw,pepeinvitados:*:200:otros:*:250:kiwi{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="610" HEIGHT="970" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img264.png"
 ALT="\begin{tscreen}
root:*:0: \\\\
usuarios:*:100:mdw,pepe \\\\
invitados:*:200: \\\\
otros:*:250:kiwi
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2766#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="307" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img329.png"
 ALT="\begin{tscreen}\begin{verbatim}Section ''ServerFlags''
...">|; 

$key = q/{abib}{LinuxinPlainEnglish}{PatrickVolkerding,KevinReichard}{IDGBooks,1997}{1558cesadodetextos,laimpresi�n,Internet,elFTPylaadministraci�ndesistemas.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="128" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img422.png"
 ALT="\begin{abib}
{Linux in Plain English }
{Patrick Volkerding, Kevin Reichard }
{ID...
...tos, la impresi�n, Internet, el FTP y la administraci�n de
sistemas.}
\end{abib}">|; 

$key = q/{tscreen}{fbox{minipage{{0.8textwidth}Nowisthetimeforallgoodmentocometotheaidofthepartyunderline{.}~{}~{}~{}~{}~{}minipage{}{{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="66" HEIGHT="10" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img201.png"
 ALT="\begin{tscreen}\fbox{\begin{minipage}{0.8\textwidth}
Now is the time for all goo...
...ne{.} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{}
\end{minipage}}\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#sort{>{listacomprabananaszanahoriasmanzanaskey{Ctrl-D}slashhomeslashlarryslashpapers#{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="444" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img159.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  sort $&gt;$ listacompra \\\\
bananas \ ...
...rias \\\\
manzanas \\\\
\key{Ctrl-D} \\\\
/home/larry/papers\char93
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#kill164{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="401" HEIGHT="57" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img190.png"
 ALT="\begin{tscreen}
/home/larry\char93  kill 164
\end{tscreen}">|; 

$key = q/{tscreen}SCSIsupport?[Yslashnslashm]YSCSIdisksupport?[Yslashnslashm]YIOMEGAParallelPortZipDriveSCSIsupport?[Yslashnslashm]Y{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="144" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img301.png"
 ALT="\begin{tscreen}
SCSI support? [Y/n/m] Y \\\\
SCSI disk support? [Y/n/m] Y \\\\
IOMEGA Parallel Port Zip Drive SCSI support? [Y/n/m] Y
\end{tscreen}">|; 

$key = q/{tscreen}#grep-i``PPP''slashvarslashadmslashmessages{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="624" HEIGHT="1525" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img373.png"
 ALT="\begin{tscreen}
\char93  grep -i \lq\lq PPP'' /var/adm/messages
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2771#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="600" HEIGHT="308" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img335.png"
 ALT="\begin{tscreen}\begin{verbatim}...">|; 

$key = q/{tscreen}{fbox{minipage{{0.8textwidth}underline{C}owisthetimeforallhumanstocometotheaidofthehungry.~{}~{}~{}~{}~{}minipage{}{{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="456" HEIGHT="141" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img210.png"
 ALT="\begin{tscreen}\fbox{\begin{minipage}{0.8\textwidth}
\underline{C}ow is the time...
...ngry. \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{}
\end{minipage}}\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2778#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="256" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img347.png"
 ALT="\begin{tscreen}\begin{verbatim}...">|; 

$key = q/{tscreen}#{{em{mount-text2slashdevslashhda3slashusr}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="418" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img249.png"
 ALT="\begin{tscreen}
\char93  {\em mount -t ext2 /dev/hda3 /usr}
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3047#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="738" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img376.png"
 ALT="\begin{tscreen}
\begin{verbatim}...">|; 

$key = q/{tscreen}papersslashnotesslashcheat-sheet{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="154" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img118.png"
 ALT="\begin{tscreen}
papers/notes/cheat-sheet
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#makelovemake:***Nowaytomaketarget`love'.Stop.slashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="223" HEIGHT="100" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img113.png"
 ALT="\begin{tscreen}
/home/larry\char93  make love \\\\
make: *** No way to make target \lq love'. Stop. \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}#cdslashusrslashX11R6#shslashvarslashtmpslashpreinst.sh{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="256" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img319.png"
 ALT="\begin{tscreen}
\char93  cd /usr/X11R6 \\\\
\char93  sh /var/tmp/preinst.sh \\\\
\end{tscreen}">|; 

$key = q/{tscreen}grep-i``TCPslashIP''slashvarslashadmslashmessages{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="583" HEIGHT="172" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img370.png"
 ALT="\begin{tscreen}
grep -i \lq\lq TCP/IP'' /var/adm/messages
\end{tscreen}">|; 

$key = q/{}^{unhboxvoidb@xhbox{relaxfontsize{5}{6}selectfont{sf{TM}};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="33" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="${}^{\unhbox \voidb@x \hbox {\relax \fontsize {5}{6}\selectfont \sf TM}}$">|; 

$key = q/{tscreen}startx{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="649" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img354.png"
 ALT="\begin{tscreen}
startx
\end{tscreen}">|; 

$key = q/{tscreen}aliaschar-major-27zftapepre-installftapeslashsbinslashswapout5{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="264" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img309.png"
 ALT="\begin{tscreen}
alias char-major-27 zftape \\\\
pre-install ftape /sbin/swapout 5
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3052#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="661" HEIGHT="112" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img385.png"
 ALT="\begin{tscreen}\begin{verbatim}PING sunsite.unc.edu (152.2.254.81): 56 data b...
...s from 152.2.254.81: icmp_seq=4 ttl=254 time=170.6 ms\end{verbatim}\end{tscreen}">|; 

$key = q/{abib}{LinuxforDummiesQuickReference}{PhilHughes}{IDGBooks,1998}{0764503022}{dolsicasdescriptingdeshelly�rdeneshabitualesenlaadministraci�nylasredes.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="561" HEIGHT="1524" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img424.png"
 ALT="\begin{abib}
{Linux for Dummies Quick Reference}
{Phil Hughes}
{IDG Books, 1998}...
...ng de shell y �rdenes habituales en la administraci�n y las
redes.}
\end{abib}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#morehistory-final{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="187" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img124.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  more history-final
\end{tscreen}">|; 

$key = q/{tscreen}(a)FAT(MS-DOS,DR-DOS,OSslash2)(b){linux}SecondExtendedFileSystem(c){linux}Xiafs(d){linux}MINIX(e)OSslash2HPFS{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="397" HEIGHT="100" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img74.png"
 ALT="\begin{tscreen}
(a) FAT (MS-DOS, DR-DOS, OS/2) \\\\
(b) {\linux} Second Extended ...
...\
(c) {\linux} Xiafs \\\\
(d) {\linux} MINIX \\\\
(e) OS/2 HPFS \\\\
\end{tscreen}">|; 

$key = q/{tscreen}slashusrslashX11R6slashlib{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="205" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img323.png"
 ALT="\begin{tscreen}
/usr/X11R6/lib
\end{tscreen}">|; 

$key = q/{tscreen}#SuperProbe-excl0x200-0x230,0x240{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="213" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img325.png"
 ALT="\begin{tscreen}
\char93  SuperProbe -excl 0x200-0x230,0x240
\end{tscreen}">|; 

$key = q/{tscreen}cdcparam{directory}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="517" HEIGHT="301" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img458.png"
 ALT="\begin{tscreen}
cd \cparam{directory}
\end{tscreen}">|; 

$key = q/{tscreen}#mkswapslashswap8208{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="257" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img253.png"
 ALT="\begin{tscreen}
\char93  mkswap /swap 8208
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#ln-sfoobar{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="222" HEIGHT="57" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img180.png"
 ALT="\begin{tscreen}
/home/larry\char93  ln -s foo bar
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#{{em{ls-ifoobar}22195bar22192fooslashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="161" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img181.png"
 ALT="\begin{tscreen}
/home/larry\char93  {\em ls -i foo bar} \\\\
22195 bar   22192 foo \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3064#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="188" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img397.png"
 ALT="\begin{tscreen}\begin{verbatim}'' \rAT\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}(a)Funcionaconlamayor�adelasunidadesATAPIslashIDE(slashdevslashhd*)(b)SR-H94+ISP16soundcard(slashdevslashsjcd)(m)IntentabuscarlaunidaddeCD{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="288" HEIGHT="78" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img76.png"
 ALT="\begin{tscreen}
(a) Funciona con la mayor�a de las unidades ATAPI/IDE (/dev/hd*)...
...ISP16 soundcard (/dev/sjcd) \\\\
(m) Intenta buscar la unidad de CD
\end{tscreen}">|; 

$key = q/{tscreen}#{{em{mke2fsslashdevslashfd01440}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="454" HEIGHT="32" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img295.png"
 ALT="\begin{tscreen}
\char93  {\em mke2fs /dev/fd0 1440}
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#kill%1{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="242" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img188.png"
 ALT="\begin{tscreen}
/home/larry\char93  kill \%1
\end{tscreen}">|; 

$key = q/{abib}{Linux:Installation,Configuration,andUse}{MichaelKofler}{Addison-Wesley,19ontieneRedHat{linux}4.1ylasfuentescompletasdelosn�cleos2.0.29y2.1.28.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="607" HEIGHT="1389" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img420.png"
 ALT="\begin{abib}
{Linux: Installation, Configuration, and Use}
{Michael Kofler}
{Add...
...\linux} 4.1 y
las fuentes completas de los n�cleos 2.0.29 y 2.1.28. }
\end{abib}">|; 

$key = q/{tscreen}�Cu�leselnombredesuordenador?�Susistemaest�conectadoaunared?{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="219" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img28.png"
 ALT="\begin{tscreen}
�Cu�l es el nombre de su ordenador? \\\\
�Su sistema est� conectado a una red?
\end{tscreen}">|; 

$key = q/{tscreen}ether=cparam{IRQ},cparam{IO_PORT},eth0{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="455" HEIGHT="100" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img54.png"
 ALT="\begin{tscreen}
ether=\cparam{IRQ},\cparam{IO\_PORT},eth0
\end{tscreen}">|; 

$key = q/{tscreen}#cdslash#tarxvfslashdevslashqft0{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="195" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img290.png"
 ALT="\begin{tscreen}
\char93  cd / \\\\
\char93  tar xvf /dev/qft0
\end{tscreen}">|; 

$key = q/{abib}{AdvancedProgrammingintheUNIXEnvironment}{W.RichardStevens}{Addison-Wesleyenvariosest�ndaresUNIX,incluidoPOSIX.1,alque{linux}seadhierebastante.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="516" HEIGHT="280" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img441.png"
 ALT="\begin{abib}
{Advanced Programming in the UNIX Environment}
{W. Richard Stevens}...
...�ndares UNIX, incluido POSIX.1, al que {\linux} se
adhiere bastante.}
\end{abib}">|; 

$key = q/{tscreen}rdevcparam{nombre-de-n�cleo}cparam{dispositivo-ra�z}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="350" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img236.png"
 ALT="\begin{tscreen}
rdev \cparam{nombre-de-n�cleo} \cparam{dispositivo-ra�z}
\end{tscreen}">|; 

$key = q/{tscreen}{fbox{minipage{{0.8textwidth}Nowisthetimeforallhumanstocometotheaidofthehungryunderline{.}~{}~{}~{}~{}~{}minipage{}{{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="455" HEIGHT="141" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img209.png"
 ALT="\begin{tscreen}\fbox{\begin{minipage}{0.8\textwidth}
Now is the time for all hum...
...ne{.} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{}
\end{minipage}}\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3081#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="597" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img414.png"
 ALT="\begin{tscreen}\begin{verbatim}Oct 21 16:09:58 hwin chat[19868]: abort on (NO...
...:31 hwin pppd[19873]: remote IP address 10.144.153.51\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}http:slashslashsunsite.unc.eduslashmdwslashlinux.html{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="318" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="\begin{tscreen}
http://sunsite.unc.edu/mdw/linux.html
\end{tscreen}">|; 

$key = q/{dispitems}ditem{{{tt{-rwxr-xr-x}}Elpropietariodelficheropuedeleer,escribir,yejerwxrwxrwx}}Todoslosusuariospuedenleer,escribiryejecutarelfichero.{dispitems};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="293" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img172.png"
 ALT="\begin{dispitems}
\ditem{{\tt -rwxr-xr-x}}
El propietario del fichero puede leer...
...
Todos los usuarios pueden leer, escribir y ejecutar el fichero.
\end{dispitems}">|; 

$key = q/{tscreen}slashhomeslashlarry#{{em{exportPAGER}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="188" HEIGHT="57" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img229.png"
 ALT="\begin{tscreen}
/home/larry\char93  {\em export PAGER}
\end{tscreen}">|; 

$key = q/{tscreen}<verb_mark>39<verb_mark>{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="186" HEIGHT="11" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img343.png"
 ALT="\begin{tscreen}
\verb!X -probeonly &gt; /tmp/x.out 2&gt;&amp;1 !
\end{tscreen}">|; 

$key = q/{abib}{CompleteRedHatLinuxResourceKitCslashDosslashUs}{Obracolectiva}{MacmillanDmbi�nvieneconelservidorwebApache,juegosyunagu�adeusuariode250p�ginas.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="551" HEIGHT="258" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img426.png"
 ALT="\begin{abib}
{Complete Red Hat Linux Resource Kit C/Dos/Us }
{Obra colectiva}
{M...
...el servidor web
Apache, juegos y una gu�a de usuario de 250 p�ginas.}
\end{abib}">|; 

$key = q/{tscreen}http:slashslashsunsite.unc.eduslashLDPslashHOWTOslashConsultants-HOWTO.ashslashsunsite.unc.eduslashLDPslashHOWTOslashCommercial-HOWTO.html{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="84" HEIGHT="11" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img85.png"
 ALT="\begin{tscreen}
http://sunsite.unc.edu/LDP/HOWTO/Consultants-HOWTO.html \\\\
http://sunsite.unc.edu/LDP/HOWTO/Commercial-HOWTO.html \\\\
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#ls{mid{sort-r{mid{head-1notesslashhomeslashlarryslashpapers#{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="270" HEIGHT="123" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img168.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  ls $\mid$ sort -r $\mid$ head -1 \\\\
notes \\\\
/home/larry/papers\char93
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#{{em{echo``holaall�''}holaall�slashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="282" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img227.png"
 ALT="\begin{tscreen}
/home/larry\char93  {\em echo \lq\lq hola all�''} \\\\
hola all� \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#pspreform{<verbatim_mark>verbatim2171#preform{slashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="221" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img183.png"
 ALT="\begin{tscreen}
/home/larry\char93  ps
\begin{verbatim}PID TT STAT TIME COMMA...
...3 S 0:03 (bash)
161 3 R 0:00 ps\end{verbatim}/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}<verb_mark>51<verb_mark><verb_mark>52<verb_mark>{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="246" HEIGHT="9" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img352.png"
 ALT="\begin{tscreen}
\verb! Option ''number_nine'' !\\\\
\verb! Option ''dac_8_bit'' !
\end{tscreen}">|; 

$key = q/{tscreen}{fbox{minipage{{0.8textwidth}COWISTHETIMEFORALLWOMENTOCOMETOTHEAIDOFTHEettersslashmiscslashpapersunderline{slash}~{}~{}minipage{}{{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="456" HEIGHT="163" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img218.png"
 ALT="\begin{tscreen}\fbox{\begin{minipage}{0.8\textwidth}
COW IS THE TIME FOR ALL WOM...
...\
misc/ \\\\
papers\underline{/} \\\\
\&nbsp;{} \\\\
\&nbsp;{}
\end{minipage}}\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#{{em{cpfoobar}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="409" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img235.png"
 ALT="\begin{tscreen}
/home/larry\char93  {\em cp foo bar}
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2876#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="788" HEIGHT="651" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img361.png"
 ALT="\begin{tscreen}\begin{verbatim}order hosts,bind
multi on\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim1147#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="34" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img50.png"
 ALT="\begin{tscreen}\begin{verbatim}/RedHat
\vert--&gt; /RPMS (contiene los .rpm b...
...ficheros \\\\
necesarios para preparar el disco duro)\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim1320#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="619" HEIGHT="405" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img84.png"
 ALT="\begin{tscreen}\begin{verbatim}darkstar&nbsp; ...">|; 

$key = q/{tscreen}#{{em{cpslashetcslashImageslashdevslashfd0}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="197" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img238.png"
 ALT="\begin{tscreen}
\char93  {\em cp /etc/Image /dev/fd0}
\end{tscreen}">|; 

$key = q/{tscreen}C:>sysa:{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="126" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="\begin{tscreen}
C:&gt;sys a:
\end{tscreen}">|; 

$key = q/{tscreen}MakeaBootFloppyNT{``CrearunDisquetedearranque''}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="315" HEIGHT="32" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img29.png"
 ALT="\begin{tscreen}
Make a Boot Floppy\NT{\lq\lq Crear un Disquete de arranque''}
\end{tscreen}">|; 

$key = q/{tscreen}{fbox{minipage{{0.8textwidth}underline{~{}}~{}~{}~{}~{}~{}"test"[Newfile]minipage{}{{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="120" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img200.png"
 ALT="\begin{tscreen}\fbox{\begin{minipage}{0.8\textwidth}
\underline{\&nbsp;{}} \\\\
\&nbsp;{} \...
... \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
''test'' [New file]
\end{minipage}}\end{tscreen}">|; 

$key = q/{tscreen}tarcparam{opciones}cparam{fichero}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="284" HEIGHT="33" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img265.png"
 ALT="\begin{tscreen}
tar \cparam{opciones} \cparam{fichero}
\end{tscreen}">|; 

$key = q/{abib}{TheDesignoftheUNIXOperatingSystem}{MauriceJ.Bach}{Prentice-Hall,1986}{0-1rporelquecomenzarsiquiereentenderlosengranajesinternosdeln�cleoLinux.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="515" HEIGHT="236" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img443.png"
 ALT="\begin{abib}
{The Design of the UNIX Operating System}
{Maurice J. Bach}
{Prenti...
...menzar si quiere
entender los engranajes internos del n�cleo Linux.}
\end{abib}">|; 

$key = q/{tscreen}#pingsunsite.unc.edu{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="84" HEIGHT="11" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img384.png"
 ALT="\begin{tscreen}
\char93  ping sunsite.unc.edu
\end{tscreen}">|; 

$key = q/{tscreen}#tartvfbackup.tar{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="170" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img271.png"
 ALT="\begin{tscreen}
\char93  tar tvf backup.tar
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2421#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="936" HEIGHT="1528" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img248.png"
 ALT="\begin{tscreen}\begin{verbatim}...">|; 

$key = q/{tscreen}#cdslashusrslashX11R6#shslashvarslashtmpslashpostinst.sh{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="195" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img321.png"
 ALT="\begin{tscreen}
\char93  cd /usr/X11R6 \\\\
\char93  sh /var/tmp/postinst.sh \\\\
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#ls{>{file-listslashhomeslashlarryslashpasishistory-finalenglish-listslashhomeslashlarryslashpapers#{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="381" HEIGHT="122" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img164.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  ls $&gt;$ file-list \\\\
/home/larry/pap...
...\\\\
history-final \\\\
english-list \\\\
/home/larry/papers\char93
\end{tscreen}">|; 

$key = q/{tscreen}{fbox{minipage{{0.8textwidth}Nowisthetimeforallgoodunderline{}mentocometotheaidoftheparty.~{}~{}~{}~{}~{}minipage{}{{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="169" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img202.png"
 ALT="\begin{tscreen}\fbox{\begin{minipage}{0.8\textwidth}
Now is the time for all goo...
...arty. \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{}
\end{minipage}}\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#lnfoobar{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="322" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img176.png"
 ALT="\begin{tscreen}
/home/larry\char93  ln foo bar
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim628#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="93" HEIGHT="230" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="\begin{tscreen}\begin{verbatim}m�quina A: / = 120MB
/usr = resto de la unidad...
...ntado desde D)m�quina D: (ejercicio para el lector)\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#lsMailletterspapersslashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="118" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img129.png"
 ALT="\begin{tscreen}
/home/larry\char93  ls \\\\
Mail \\\\
letters \\\\
papers \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2765#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="102" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img328.png"
 ALT="\begin{tscreen}\begin{verbatim}Section ''Files''
RgbPath ''/usr/X11R6/lib/X11...
...ntPath ''/usr/X11R6/lib/X11/fonts/75dpi/''
EndSection\end{verbatim}\end{tscreen}">|; 

$key = q/{abib}{Learningthe{{tt{vi}Editor}{LindaLamb}{O'ReillyandAssociates,1990}{0-93717usar{{tt{vi},porquenosiempretendr�accesoauneditor�deverdad�comoEmacs.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="515" HEIGHT="256" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img431.png"
 ALT="\begin{abib}
{Learning the {\tt vi} Editor}
{Linda Lamb}
{O'Reilly and Associa...
... porque no siempre tendr� acceso a un editor �de
verdad� como Emacs.}
\end{abib}">|; 

$key = q/{tscreen}#mount-tmsdosslashdevslashhda1slashmnt{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="255" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img141.png"
 ALT="\begin{tscreen}
\char93  mount -t msdos /dev/hda1 /mnt
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2770#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="583" HEIGHT="188" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img333.png"
 ALT="\begin{tscreen}\begin{verbatim}HorizSync 31.5, 35.2, 37.9, 35.5, 48.95\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2777#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="546" HEIGHT="113" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img346.png"
 ALT="\begin{tscreen}\begin{verbatim}Section ''Device''
...">|; 

$key = q/{tscreen}{fbox{minipage{{0.8textwidth}Nowisthetimeforallgoodhumanstocometotheaidrds,we'llgooutforpizzaandunderline{}~{}~{}~{}~{}minipage{}{{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="455" HEIGHT="141" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img205.png"
 ALT="\begin{tscreen}\fbox{\begin{minipage}{0.8\textwidth}
Now is the time for all goo...
...\underline{ } \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{}
\end{minipage}}\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2305#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="231" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img240.png"
 ALT="\begin{tscreen}\begin{verbatim}...">|; 

$key = q/{tscreen}linuxlogin:{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="87" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img106.png"
 ALT="\begin{tscreen}
linux login:
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashkarl#cdslashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="282" HEIGHT="34" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img128.png"
 ALT="\begin{tscreen}
/home/karl\char93  cd \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}#uncompressbackup.tar.Z#tarxvfbackup.tar{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="312" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img280.png"
 ALT="\begin{tscreen}
\char93  uncompress backup.tar.Z \\\\
\char93  tar xvf backup.tar
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2782#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="170" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img355.png"
 ALT="\begin{tscreen}\begin{verbatim}...">|; 

$key = q/{tscreen}#PPP{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="150" HEIGHT="9" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img406.png"
 ALT="\begin{tscreen}
\char93  PPP
\end{tscreen}">|; 

$key = q/{tscreen}root::0:0:root:slash:slashbinslashsh{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="298" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img316.png"
 ALT="\begin{tscreen}
root::0:0:root:/:/bin/sh
\end{tscreen}">|; 

$key = q/{tscreen}close{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="617" HEIGHT="475" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img469.png"
 ALT="\begin{tscreen}
close
\end{tscreen}">|; 

$key = q/{tscreen}C:>formata:slashs{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="575" HEIGHT="91" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="\begin{tscreen}
C:&gt;format a: /s
\end{tscreen}">|; 

$key = q/{tscreen}#mount-tmsdosslashdevslashfd0slashmnt{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="161" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img140.png"
 ALT="\begin{tscreen}
\char93  mount -t msdos /dev/fd0 /mnt
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3051#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="84" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img383.png"
 ALT="\begin{tscreen}\begin{verbatim}-- 10.144.153.51 ping statistics --
4 packe...
...t loss
round-trip min/avg/max = 170.7/219.2/328.3 ms\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#morepapersslashhistory-final{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="429" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img120.png"
 ALT="\begin{tscreen}
/home/larry\char93  more papers/history-final
\end{tscreen}">|; 

$key = q/{tscreen}#cdslash#tarzxvfslashzipslashetc.tgz{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="171" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img286.png"
 ALT="\begin{tscreen}
\char93  cd / \\\\
\char93  tar zxvf /zip/etc.tgz
\end{tscreen}">|; 

$key = q/{tscreen}#cdslashusrslashsrc#mkdirlinux-2.0.33#rm-rlinux#ln-slinux-2.0.33linux#tarxzflinux-2.0.33.tar.gz{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="221" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img298.png"
 ALT="\begin{tscreen}
\char93  cd /usr/src \\\\
\char93  mkdir linux-2.0.33 \\\\
\char93...
... ln -s linux-2.0.33 linux \\\\
\char93  tar xzf linux-2.0.33.tar.gz
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3058#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="487" HEIGHT="52" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img391.png"
 ALT="\begin{tscreen}\begin{verbatim}
...">|; 

$key = q/{tscreen}boot:{{em{linuxhd=cparam{cilindros},cparam{cabezas},cparam{sectores}}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="161" HEIGHT="53" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img99.png"
 ALT="\begin{tscreen}
boot: {\em linux hd=\cparam{cilindros},\cparam{cabezas},\cparam{sectores}}
\end{tscreen}">|; 

$key = q/{tscreen}kiwi:*Xv8Q981g71oKK:102:100:LauraVilla:slashhomeslashkiwi:slashbinslashbash{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="555" HEIGHT="666" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img261.png"
 ALT="\begin{tscreen}
kiwi:*Xv8Q981g71oKK:102:100:Laura Villa:/home/kiwi:/bin/bash
\end{tscreen}">|; 

$key = q/backslash;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="403" HEIGHT="13" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img49.png"
 ALT="$\backslash$">|; 

$key = q/{tscreen}slashhomeslashlarry#fgyes>slashdevslashnull{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="377" HEIGHT="113" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img192.png"
 ALT="\begin{tscreen}
/home/larry\char93  fg \\\\
yes &gt;/dev/null
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3063#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="806" HEIGHT="668" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img396.png"
 ALT="\begin{tscreen}\begin{verbatim}ABORT '\nRINGING\r\n\r\nRINGING\r'\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}http:slashslashwww.cs.huji.ac.ilslash~borikslashdebianslashligsslash{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="555" HEIGHT="448" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img42.png"
 ALT="\begin{tscreen}
http://www.cs.huji.ac.il/\&nbsp;borik/debian/ligs/
\end{tscreen}">|; 

$key = q/{tscreen}ether=11,0x300,eth0{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="181" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img55.png"
 ALT="\begin{tscreen}
ether=11,0x300,eth0
\end{tscreen}">|; 

$key = q/{tscreen}ftp:slashslashftp.cdrom.comslashpubslashlinuxslashslackwareslashpatchesslash{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="568" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img90.png"
 ALT="\begin{tscreen}
ftp://ftp.cdrom.com/pub/linux/slackware/patches/
\end{tscreen}">|; 

$key = q/{tscreen}#tarzcvfslashzipslashetc.tgzslashetc{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="188" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img285.png"
 ALT="\begin{tscreen}
\char93  tar zcvf /zip/etc.tgz /etc
\end{tscreen}">|; 

$key = q/{tscreen}#dpkg-icparam{nombredefichero}.deb{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="444" HEIGHT="230" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img33.png"
 ALT="\begin{tscreen}
\char93  dpkg -i \cparam{nombre de fichero}.deb
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#exit{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="188" HEIGHT="57" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img116.png"
 ALT="\begin{tscreen}
/home/larry\char93  exit
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3080#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="11" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img411.png"
 ALT="\begin{tscreen}\begin{verbatim}exec /usr/sbin/pppd debug file options.myserver /dev/ttyS0 38400 \ end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}textsl{n�mero}textsl{categor�a}{linebreak{textsl{paquete}{linebreak{...{linebreak{end{linebreak{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="538" HEIGHT="73" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img51.png"
 ALT="\begin{tscreen}
\textsl{n�mero} \textsl{categor�a} \linebreak\textsl{paquete} \linebreak ... \linebreak end \linebreak\end{tscreen}">|; 

$key = q/{abib}{TheCProgrammingLanguage}{BrianKernighanandDennisRitchie}{Prentice-Hall,19asiadoostensiblepuedeaplicarsebastantebienalaprogramaci�nenCbajoUNIX.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="515" HEIGHT="214" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img439.png"
 ALT="\begin{abib}
{The C Programming Language}
{Brian Kernighan and Dennis Ritchie}
{...
...ble puede aplicarse bastante
bien a la programaci�n en C bajo UNIX.}
\end{abib}">|; 

$key = q/{tscreen}slashhomeslashlarry#cd..slashhome#cd..slash#cdusrslashusr#cdbinslashusrslashbin#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="670" HEIGHT="311" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img133.png"
 ALT="\begin{tscreen}
/home/larry\char93  cd .. \\\\
/home\char93  cd .. \\\\
/\char93  cd usr \\\\
/usr\char93  cd bin \\\\
/usr/bin\char93
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#yesyyyyy{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="223" HEIGHT="57" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img184.png"
 ALT="\begin{tscreen}
/home/larry\char93  yes \\\\
y \\\\
y \\\\
y \\\\
y \\\\
y
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#ls-lfoobar<verb_mark>23<verb_mark><verb_mark>24<verb_mark>slashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="488" HEIGHT="78" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img182.png"
 ALT="\begin{tscreen}
/home/larry\char93  ls -l foo bar \\\\
\verb!lrwxrwxrwx 1 root ro...
...-rw-r-r- 1 root root 12 Aug 5 16:50 foo! \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}boot:linuxtmx8xx=cparam{interrupci�n},cparam{direcci�n}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="287" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img100.png"
 ALT="\begin{tscreen}
boot: linux tmx8xx=\cparam{interrupci�n},\cparam{direcci�n}
\end{tscreen}">|; 

$key = q/{abib}{InsideLinux:ALookatOperatingSystemDevelopment}{RandolphBentson}{Specializmaneraqueellectorpuedaverconmayorclaridadloquesucededentrodelsistema.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="516" HEIGHT="280" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img442.png"
 ALT="\begin{abib}
{Inside Linux: A Look at Operating System Development}
{Randolph Be...
...ctor pueda ver con mayor claridad
lo que sucede dentro del sistema.}
\end{abib}">|; 

$key = q/{tscreen}slashhomeslashlarry#lsf*frogslashhomeslashlarry#ls*ffstuffslashhomeslasry#ls*f*frogstuffslashhomeslashlarry#lss*fstuffslashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="187" HEIGHT="56" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img149.png"
 ALT="\begin{tscreen}
/home/larry\char93  ls f* \\\\
frog \\\\
/home/larry\char93  ls *f...
... \\\\
/home/larry\char93  ls s*f \\\\
stuff \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2875#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="162" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img360.png"
 ALT="\begin{tscreen}\begin{verbatim}default 0.0.0.0  ...">|; 

$key = q/{abib}{LearningtheUNIXOperatingSystem}{GraceTodino&JohnStrang}{O'ReillyandAssociestelibrosiesnuevoenUNIXydesearealmenteiniciarseusandosunuevosistema.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="399" HEIGHT="149" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img430.png"
 ALT="\begin{abib}
{Learning the UNIX Operating System}
{Grace Todino \&amp; John Strang}
...
... nuevo en UNIX y desea realmente iniciarse
usando su nuevo sistema.}
\end{abib}">|; 

$key = q/{tscreen}ASistemab�sicode{linux}APVariasaplicacionesquenonecesitanXDDesarrollodeview(gestordeventanasOpenLook,aplicaciones)YJuegos(quenorequierenX){tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="32" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img78.png"
 ALT="\begin{tscreen}
A Sistema b�sico de {\linux} \\\\
AP Varias aplicaciones que no n...
...anas OpenLook, aplicaciones) \\\\
Y Juegos (que no requieren X) \\\\
\end{tscreen}">|; 

$key = q/{tscreen}#ln-sfslashlibslashlibc.so.4.4.1slashlibslashlibc.so.4{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="195" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img311.png"
 ALT="\begin{tscreen}
\char93  ln -sf /lib/libc.so.4.4.1 /lib/libc.so.4
\end{tscreen}">|; 

$key = q/{tscreen}#setserial-aslashdevslashttyScparam{x}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="307" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img375.png"
 ALT="\begin{tscreen}
\char93  setserial -a /dev/ttyS\cparam{x}
\end{tscreen}">|; 

$key = q/{abib}{TheMagicGardenExplained}{BernyGoodheartandJamesCox}{Prentice-Hall,1994}{0eal.Tambi�nesunlibromuymodernosobreeln�cleoUNIX,puessepublic�en1.994.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="516" HEIGHT="213" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img444.png"
 ALT="\begin{abib}
{The Magic Garden Explained}
{Berny Goodheart and James Cox}
{Prent...
...n libro muy moderno sobre
el n�cleo UNIX, pues se public� en 1.994.}
\end{abib}">|; 

$key = q/{tscreen}slashlibslashmodulesslashcparam{n�cleo-version}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="178" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img307.png"
 ALT="\begin{tscreen}
/lib/modules/\cparam{n�cleo-version}
\end{tscreen}">|; 

$key = q/{tscreen}(a)Rat�nseriecompatibleMicrosoft(b)QuickPortorat�ndelestiloPSslash2(PueoftBusMouse(f)Rat�nserieMouseSystems(g)Rat�nserieLogitech(MouseMan){tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="262" HEIGHT="79" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img80.png"
 ALT="\begin{tscreen}
(a) Rat�n serie compatible Microsoft \\\\
(b) QuickPort o rat�n d...
...�n serie Mouse Systems \\\\
(g) Rat�n serie Logitech (MouseMan) \\\\
\end{tscreen}">|; 

$key = q/{tscreen}<verb_mark>41<verb_mark><verb_mark>42<verb_mark><verb_mark>43<verb_mark_mark>47<verb_mark><verb_mark>48<verb_mark><verb_mark>49<verb_mark>{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="111" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img345.png"
 ALT="\begin{tscreen}
\verb!XFree86 Version 3.1 / X Window System !\\\\
\verb!(protocol...
...chipset: 864 rev. 0 !\\\\
\verb!(-) S3: chipset driver: mmio_928 !
\end{tscreen}">|; 

$key = q/{dispitems}%latex2htmlidmarker14521{par{index{usuarios!nombrede}index{nombredeusEjemplospuedenser{{tt{slashbinslashbash}y{{tt{slashbinslashtcsh}.{dispitems};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="160" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img257.png"
 ALT="\begin{dispitems}
% latex2html id marker 14521\par\index{usuarios!nombre de }
...
... usuario. Ejemplos pueden ser {\tt /bin/bash} y {\tt /bin/tcsh}.
\end{dispitems}">|; 

$key = q/{tscreen}boot:rescueroot=slashdevslashcparam{xxxx}roload_ramdisk=0{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="472" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img60.png"
 ALT="\begin{tscreen}
boot: rescue root=/dev/\cparam{xxxx} ro load\_ramdisk=0
\end{tscreen}">|; 

$key = q/{tscreen}Loading...Uncompressinglinux...{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="402" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img17.png"
 ALT="\begin{tscreen}
Loading... \\\\
Uncompressing linux... \\\\
\end{tscreen}">|; 

$key = q/{tscreen}<verb_mark>40<verb_mark>{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="334" HEIGHT="9" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img344.png"
 ALT="\begin{tscreen}
\verb!X -probeonly &amp;&gt; /tmp/x.out !
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#ls{mid{sort-rnotesmasters-thesishistory-finalenglish-listslashhomeslashlarryslashpapers#{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="276" HEIGHT="101" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img165.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  ls $\mid$ sort -r \\\\
notes \\\\
mast...
...\\\\
history-final \\\\
english-list \\\\
/home/larry/papers\char93
\end{tscreen}">|; 

$key = q/{tscreen}{fbox{minipage{{0.8textwidth}COWISTHETIMEFORALLWOMENTOCOMETOTHEAIDOFTHEHUNGRYunderline{.}~{}~{}~{}~{}~{}minipage{}{{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="455" HEIGHT="141" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img211.png"
 ALT="\begin{tscreen}\fbox{\begin{minipage}{0.8\textwidth}
COW IS THE TIME FOR ALL WOM...
...ine{.}\\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{}
\end{minipage}}\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#sortbananaszanahoriasmanzanaskey{Ctrl-D}bananasmanzanaszanahoriasslashhomeslashlarryslashpapers#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="121" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img158.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  sort \\\\
bananas \\\\
zanahorias \\\\
m...
...ananas \\\\
manzanas \\\\
zanahorias \\\\
/home/larry/papers\char93
\end{tscreen}">|; 

$key = q/{abib}{EssentialSystemAdministration}{AEleenFrisch}{O'ReillyandAssociates,1991}{rpersonaresponsabledeunsistemaUNIX.�Yomismonolopodr�ahaberdichomejor.}{abib};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="516" HEIGHT="236" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img434.png"
 ALT="\begin{abib}
{Essential System Administration}
{\AE leen Frisch}
{O'Reilly and A...
...nsable de un sistema UNIX.� Yo mismo no lo podr�a haber dicho
mejor.}
\end{abib}">|; 

$key = q/{tscreen}execslashusrslashsbinslashchat-v{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="76" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img392.png"
 ALT="\begin{tscreen}
exec /usr/sbin/chat -v
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#fg%2{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="128" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img195.png"
 ALT="\begin{tscreen}
/home/larry\char93  fg \%2
\end{tscreen}">|; 

$key = q/{dispitems}ditem{{{tt{chmoda+rstuff}}Daatodoslosusuariospermisodelecturaalficheruci�ndelosusuariosquenosoneldue�onilosusuariosdelgrupodelfichero.{dispitems};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="514" HEIGHT="113" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img174.png"
 ALT="\begin{dispitems}
\ditem{{\tt chmod a+r stuff}}
Da a todos los usuarios permiso ...
...arios que no
son el due�o ni los usuarios del grupo del fichero.
\end{dispitems}">|; 

$key = q/{tscreen}#tail-fslashvarslashlogslashmessages{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="137" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img412.png"
 ALT="\begin{tscreen}
\char93  tail -f /var/log/messages
\end{tscreen}">|; 

$key = q/{tscreen}#{{em{e2fsck-avslashdevslashhda2}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="324" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img250.png"
 ALT="\begin{tscreen}
\char93  {\em e2fsck -av /dev/hda2}
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#cpslashetcslashs*slashhomeslashlarry{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="205" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img154.png"
 ALT="\begin{tscreen}
/home/larry\char93  cp /etc/s* /home/larry
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2776#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="419" HEIGHT="208" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img342.png"
 ALT="\begin{tscreen}\begin{verbatim}XFree86 Version 3.1 / X Window System
(protocol...
...raphics adaptors (Patchlevel 0)
mmio_928, s3_generic\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}#SuperProbe{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="363" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img324.png"
 ALT="\begin{tscreen}
\char93  SuperProbe
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#ls-a....bash_profile.bashrcfrogjoestuffslashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="162" HEIGHT="187" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img152.png"
 ALT="\begin{tscreen}
/home/larry\char93  ls -a \\\\
.     ..     .bash\_prof...
...    frog
     joe     stuff \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}Partitioncheck:{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="419" HEIGHT="140" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img97.png"
 ALT="\begin{tscreen}
Partition check:
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim2781#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="341" HEIGHT="109" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img350.png"
 ALT="\begin{tscreen}\begin{verbatim}(-) SVGA: cldg5434: Specifying a Clocks line makes no sense for this driver\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}#mke2fsslashdevslashsda4{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="186" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img287.png"
 ALT="\begin{tscreen}
\char93  mke2fs /dev/sda4
\end{tscreen}">|; 

$key = q/];MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="8" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img64.png"
 ALT="$]$">|; 

$key = q/{tscreen}slashhomeslashlarry#ls--Fpapersenglish-lithistory-finalmasters-thesisnotesslashslashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="162" HEIGHT="100" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img131.png"
 ALT="\begin{tscreen}
/home/larry\char93  ls -F papers \\\\
english-lit \\\\
history-final \\\\
masters-thesis \\\\
notes/ \\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}mousehouselogin:larryPassword:larry'spasswordWelcometoMousehouse!slashhomeslashlarry#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="127" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img112.png"
 ALT="\begin{tscreen}
mousehouse login: larry \\\\
Password: larry's password \\\\
Welcome to Mousehouse! \\\\
\\\\
/home/larry\char93
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashfoo#ls-lstuffpreform{<verbatim_mark>verbatim2141#preform{slashhomeslashlarryslashfoo#{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="350" HEIGHT="57" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img171.png"
 ALT="\begin{tscreen}
/home/larry/foo\char93  ls -l stuff
\begin{verbatim}-rw-r-r-...
... users 505 Mar 13 19:05 stuff\end{verbatim}/home/larry/foo\char93
\end{tscreen}">|; 

$key = q/{tscreen}http:slashslashwww.redhat.comslashsupportslashdocsslashrpmslashRPM-HOWTOslashRPM-HOWTO.html{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="389" HEIGHT="58" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img44.png"
 ALT="\begin{tscreen}
http://www.redhat.com/support/docs/rpm/RPM-HOWTO/RPM-HOWTO.html
\end{tscreen}">|; 

$key = q/{tscreen}chmod{a,u,g,o}{+,-}{r,w,x}cparam{nombre_fichero}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="304" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img173.png"
 ALT="\begin{tscreen}
chmod \{a,u,g,o\}\{+,-\}\{r,w,x\} \cparam{nombre\_fichero}
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarryslashpapers#sort{<{itemsbananasmanzanaszanahoriasslashhomeslashlarryslashpapers#{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="329" HEIGHT="122" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img162.png"
 ALT="\begin{tscreen}
/home/larry/papers\char93  sort $&lt;$ items \\\\
bananas \\\\
manzanas \\\\
zanahorias \\\\
/home/larry/papers\char93
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3050#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="238" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img382.png"
 ALT="\begin{tscreen}\begin{verbatim}PING 10.144.153.51 (10.144.153.51): 56 data by...
... from 10.144.153.51: icmp_seq=3 ttl=255 time=170.7 ms\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}X-showconfig{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="539" HEIGHT="109" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img341.png"
 ALT="\begin{tscreen}
X -showconfig
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3057#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="512" HEIGHT="112" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img390.png"
 ALT="\begin{tscreen}\begin{verbatim}...">|; 

$key = q/{tscreen}(a)Instalardesdeunapartici�ndediscoduro.(b)InstalardesdedisquetesdisqueNFS.(d)Instalardesdeundirectoriopre-montado.(e)InstalardesdeCD-ROM.{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="481" HEIGHT="57" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img73.png"
 ALT="\begin{tscreen}
(a) Instalar desde una partici�n de disco duro. \\\\
(b) Instalar...
...esde un directorio pre-montado. \\\\
(e) Instalar desde CD-ROM. \\\\
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#{{em{PAGER=``cat''}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="255" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img228.png"
 ALT="\begin{tscreen}
/home/larry\char93  {\em PAGER=\lq\lq cat''}
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3062#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="626" HEIGHT="331" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img395.png"
 ALT="\begin{tscreen}\begin{verbatim}ABORT '\nNO ANSWER\r'\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}slashbin:slashusrslashbin:slashusrslashlocalslashbin:.{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="257" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img234.png"
 ALT="\begin{tscreen}
/bin:/usr/bin:/usr/local/bin:.
\end{tscreen}">|; 

$key = q/{tscreen}preform{<verbatim_mark>verbatim3069#preform{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="161" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img402.png"
 ALT="\begin{tscreen}\begin{verbatim}ogin:-ogin: \$ACCOUNT\end{verbatim}\end{tscreen}">|; 

$key = q/{tscreen}#ppp-on&{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="702" HEIGHT="472" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img413.png"
 ALT="\begin{tscreen}
\char93  ppp-on \&amp;
\end{tscreen}">|; 

$key = q/{tscreen}pingmi.isp.net{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="565" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img416.png"
 ALT="\begin{tscreen}
ping mi.isp.net
\end{tscreen}">|; 

$key = q/{tscreen}{fbox{minipage{{0.8textwidth}COWISTHETIMEFORALLWOMENTOCOMETOTHEAIDOFTHEHUNGRY.~{}~{}~{}~{}~{}:underline{}minipage{}{{tscreen};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="456" HEIGHT="141" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img212.png"
 ALT="\begin{tscreen}\fbox{\begin{minipage}{0.8\textwidth}
COW IS THE TIME FOR ALL WOM...
...\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
\&nbsp;{} \\\\
:\underline{ }
\end{minipage}}\end{tscreen}">|; 

$key = q/{tscreen}boot:linuxsingle{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="84" HEIGHT="52" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img62.png"
 ALT="\begin{tscreen}
boot: linux single
\end{tscreen}">|; 

$key = q/{tscreen}#SuperProbe-verbose>superprobe.out{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="119" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img327.png"
 ALT="\begin{tscreen}
\char93  SuperProbe -verbose &gt;superprobe.out
\end{tscreen}">|; 

$key = q/{tscreen}cdcparam{directorio}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="343" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img122.png"
 ALT="\begin{tscreen}
cd \cparam{directorio}
\end{tscreen}">|; 

$key = q/{tscreen}[root@happyRPMS]rpm-q-p-Rbash-1.14.7-1.i386.rpm{linebreak{{linebreak{libc.so.5{linebreak{{linebreak{libtermcap.so.2{linebreak{{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="402" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img53.png"
 ALT="\begin{tscreen}[root@happy RPMS]rpm -q -p -R bash-1.14.7-1.i386.rpm \linebreak\linebreak libc.so.5 \linebreak\linebreak libtermcap.so.2 \linebreak\end{tscreen}">|; 

$key = q/{tscreen}http:slashslashcesdis.gsfc.nasa.govslashlinux-webslashsimplefixesslashsimplefixes.html{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="390" HEIGHT="100" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img89.png"
 ALT="\begin{tscreen}
http://cesdis.gsfc.nasa.gov/linux-web/simplefixes/simplefixes.html
\end{tscreen}">|; 

$key = q/{tscreen}InitializeandActivatetheSwapDiskPartition{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="180" HEIGHT="9" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img22.png"
 ALT="\begin{tscreen}
Initialize and Activate the Swap Disk Partition
\end{tscreen}">|; 

$key = q/{tscreen}#ping10.144.153.51{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="661" HEIGHT="452" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img381.png"
 ALT="\begin{tscreen}
\char93  ping 10.144.153.51
\end{tscreen}">|; 

$key = q/{tscreen}slashhomeslashlarry#ls*o*{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="161" HEIGHT="56" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img150.png"
 ALT="\begin{tscreen}
/home/larry\char93  ls *o*
\end{tscreen}">|; 

$key = q/{tscreen}#ppp-off{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="522" HEIGHT="92" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img387.png"
 ALT="\begin{tscreen}
\char93  ppp-off
\end{tscreen}">|; 

$key = q/{tscreen}ftp>{{em{close}221Goodbye.ftp>{{em{quit}{tscreen};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="384" HEIGHT="55" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img470.png"
 ALT="\begin{tscreen}
ftp&gt; {\em close} \\\\
221 Goodbye. \\\\
ftp&gt; {\em quit}
\end{tscreen}">|; 

1;

