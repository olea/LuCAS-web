# LaTeX2HTML 2002 (1.62)
# Associate internals original text with physical files.


$key = q/table-scsi-devices/;
$ref_files{$key} = "$dir".q|node288.html|; 
$noresave{$key} = "$nosave";

$key = q/table-ide-device-drivers/;
$ref_files{$key} = "$dir".q|node288.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-generic-x/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-adv-using-dip/;
$ref_files{$key} = "$dir".q|node354.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-sysadm/;
$ref_files{$key} = "$dir".q|node279.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-resolve.conf/;
$ref_files{$key} = "$dir".q|node347.html|; 
$noresave{$key} = "$nosave";

$key = q/example-sysadm-fstab/;
$ref_files{$key} = "$dir".q|node287.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-uucp/;
$ref_files{$key} = "$dir".q|node381.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-tape-backups/;
$ref_files{$key} = "$dir".q|node309.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-zip-backup/;
$ref_files{$key} = "$dir".q|node308.html|; 
$noresave{$key} = "$nosave";

$key = q/table-dev-settings/;
$ref_files{$key} = "$dir".q|node208.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-tcpip/;
$ref_files{$key} = "$dir".q|node339.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-filesystem-tour/;
$ref_files{$key} = "$dir".q|node241.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-intro-num/;
$ref_files{$key} = "$dir".q|node14.html|; 
$noresave{$key} = "$nosave";

$key = q/app-vendor-num/;
$ref_files{$key} = "$dir".q|node410.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-manage-links/;
$ref_files{$key} = "$dir".q|node254.html|; 
$noresave{$key} = "$nosave";

$key = q/table-redhat-space-requirements/;
$ref_files{$key} = "$dir".q|node144.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-manage-groups/;
$ref_files{$key} = "$dir".q|node296.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-tutorial/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/installation-slackware/;
$ref_files{$key} = "$dir".q|node160.html|; 
$noresave{$key} = "$nosave";

$key = q/dirtree/;
$ref_files{$key} = "$dir".q|node227.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-adv-slip-dip/;
$ref_files{$key} = "$dir".q|node351.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-ls/;
$ref_files{$key} = "$dir".q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-ppp/;
$ref_files{$key} = "$dir".q|node355.html|; 
$noresave{$key} = "$nosave";

$key = q/table-ftp-sites/;
$ref_files{$key} = "$dir".q|node409.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-init-scripts/;
$ref_files{$key} = "$dir".q|node277.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-manage-users/;
$ref_files{$key} = "$dir".q|node291.html|; 
$noresave{$key} = "$nosave";

$key = q/table-disk-formats/;
$ref_files{$key} = "$dir".q|node306.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-networking/;
$ref_files{$key} = "$dir".q|node338.html|; 
$noresave{$key} = "$nosave";

$key = q/table-slackware-scsi-ide-boot-images/;
$ref_files{$key} = "$dir".q|node177.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-process/;
$ref_files{$key} = "$dir".q|node258.html|; 
$noresave{$key} = "$nosave";

$key = q/table-debian-install-floppies/;
$ref_files{$key} = "$dir".q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-sysadm-upgrade/;
$ref_files{$key} = "$dir".q|node311.html|; 
$noresave{$key} = "$nosave";

$key = q/ftape-module/;
$ref_files{$key} = "$dir".q|node314.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-source-mailing-list/;
$ref_files{$key} = "$dir".q|node52.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-install-num/;
$ref_files{$key} = "$dir".q|node54.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-set-host_name/;
$ref_files{$key} = "$dir".q|node320.html|; 
$noresave{$key} = "$nosave";

$key = q/app-ftplist-num/;
$ref_files{$key} = "$dir".q|node402.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-bootfloppy/;
$ref_files{$key} = "$dir".q|node281.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-news/;
$ref_files{$key} = "$dir".q|node384.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-getting-internet/;
$ref_files{$key} = "$dir".q|node409.html|; 
$noresave{$key} = "$nosave";

$key = q/table-redhat-packages/;
$ref_files{$key} = "$dir".q|node142.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-job-control/;
$ref_files{$key} = "$dir".q|node257.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-lilo/;
$ref_files{$key} = "$dir".q|node283.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-inittab/;
$ref_files{$key} = "$dir".q|node285.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-swap-file/;
$ref_files{$key} = "$dir".q|node290.html|; 
$noresave{$key} = "$nosave";

$key = q/kernel-ppa-driver/;
$ref_files{$key} = "$dir".q|node313.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-S.u.S.E./;
$ref_files{$key} = "$dir".q|node198.html|; 
$noresave{$key} = "$nosave";

$key = q/app-sourc-ldp-home-page/;
$ref_files{$key} = "$dir".q|node387.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-manage-fs/;
$ref_files{$key} = "$dir".q|node286.html|; 
$noresave{$key} = "$nosave";

$key = q/app-gpl/;
$ref_files{$key} = "$dir".q|node413.html|; 
$noresave{$key} = "$nosave";

$key = q/gnu-license/;
$ref_files{$key} = "$dir".q|node413.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-checking-file-system/;
$ref_files{$key} = "$dir".q|node289.html|; 
$noresave{$key} = "$nosave";

$key = q/table-slackware-ide-boot-images/;
$ref_files{$key} = "$dir".q|node177.html|; 
$noresave{$key} = "$nosave";

$key = q/app-gpl-num/;
$ref_files{$key} = "$dir".q|node413.html|; 
$noresave{$key} = "$nosave";

$key = q/table-fs-types/;
$ref_files{$key} = "$dir".q|node287.html|; 
$noresave{$key} = "$nosave";

$key = q/table-debian-archive-structure/;
$ref_files{$key} = "$dir".q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-tutorial-num/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-file-perms/;
$ref_files{$key} = "$dir".q|node249.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-sysadm-shutdown/;
$ref_files{$key} = "$dir".q|node284.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-advanced-xconfiguration/;
$ref_files{$key} = "$dir".q|node334.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-generic-fdisk/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table-tape-devices/;
$ref_files{$key} = "$dir".q|node309.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-rc/;
$ref_files{$key} = "$dir".q|node319.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-mice/;
$ref_files{$key} = "$dir".q|node61.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-upgrade-libs/;
$ref_files{$key} = "$dir".q|node315.html|; 
$noresave{$key} = "$nosave";

$key = q/table-debian-package-fields/;
$ref_files{$key} = "$dir".q|node101.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-perms/;
$ref_files{$key} = "$dir".q|node249.html|; 
$noresave{$key} = "$nosave";

$key = q/app-info/;
$ref_files{$key} = "$dir".q|node385.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-walking-redhat/;
$ref_files{$key} = "$dir".q|node151.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-xwindow/;
$ref_files{$key} = "$dir".q|node327.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-msdos-mount/;
$ref_files{$key} = "$dir".q|node239.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-create-account/;
$ref_files{$key} = "$dir".q|node220.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-video-card-info/;
$ref_files{$key} = "$dir".q|node335.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-maint-diskette/;
$ref_files{$key} = "$dir".q|node322.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-floppy/;
$ref_files{$key} = "$dir".q|node310.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-xwindows-reqs/;
$ref_files{$key} = "$dir".q|node328.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-vi/;
$ref_files{$key} = "$dir".q|node261.html|; 
$noresave{$key} = "$nosave";

$key = q/app-sources-num/;
$ref_files{$key} = "$dir".q|node385.html|; 
$noresave{$key} = "$nosave";

$key = q/app-tldpes/;
$ref_files{$key} = "$dir".q|node395.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-intro-differences/;
$ref_files{$key} = "$dir".q|node29.html|; 
$noresave{$key} = "$nosave";

$key = q/debian-installation/;
$ref_files{$key} = "$dir".q|node77.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-probs-hardware/;
$ref_files{$key} = "$dir".q|node207.html|; 
$noresave{$key} = "$nosave";

$key = q/app-ftp/;
$ref_files{$key} = "$dir".q|node402.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-shell-script/;
$ref_files{$key} = "$dir".q|node274.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-plumbing/;
$ref_files{$key} = "$dir".q|node244.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-microsoftnet/;
$ref_files{$key} = "$dir".q|node382.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-rawrite/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-copyright/;
$ref_files{$key} = "$dir".q|lipp2.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-backfloppy/;
$ref_files{$key} = "$dir".q|node307.html|; 
$noresave{$key} = "$nosave";

$key = q/chap-sysadm-num/;
$ref_files{$key} = "$dir".q|node279.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-generic-general/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-upgrade-gcc/;
$ref_files{$key} = "$dir".q|node316.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-command-summ/;
$ref_files{$key} = "$dir".q|node240.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-processes/;
$ref_files{$key} = "$dir".q|node258.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-add-user/;
$ref_files{$key} = "$dir".q|node291.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-shells-cmds/;
$ref_files{$key} = "$dir".q|node223.html|; 
$noresave{$key} = "$nosave";

$key = q/device-driver-names/;
$ref_files{$key} = "$dir".q|node288.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-mail/;
$ref_files{$key} = "$dir".q|node383.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-running-deb/;
$ref_files{$key} = "$dir".q|node101.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-install-probs-postinstall/;
$ref_files{$key} = "$dir".q|node212.html|; 
$noresave{$key} = "$nosave";

1;

