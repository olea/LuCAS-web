# LaTeX2HTML 2002 (1.62)
# Associate internals original text with physical files.


$key = q/cite_beowulf/;
$ref_files{$key} = "$dir".q|node14.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_linux-ha/;
$ref_files{$key} = "$dir".q|node14.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Kimberlite/;
$ref_files{$key} = "$dir".q|node14.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_TLDP/;
$ref_files{$key} = "$dir".q|node14.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LVS/;
$ref_files{$key} = "$dir".q|node14.html|; 
$noresave{$key} = "$nosave";

1;

