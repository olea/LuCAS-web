# LaTeX2HTML 2002 (1.62)
# Associate images original text with physical files.


$key = q/includegraphics[%%width=0.80columnwidth]{simple.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="155" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\includegraphics[%%
width=0.80\columnwidth]{simple.eps}">|; 

$key = q/includegraphics[%%width=1.0columnwidth]{avanzada.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="168" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\includegraphics[%%
width=1.0\columnwidth]{avanzada.eps}">|; 

1;

