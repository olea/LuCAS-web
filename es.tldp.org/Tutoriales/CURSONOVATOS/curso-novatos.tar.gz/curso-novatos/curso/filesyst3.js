function result(){
   with (self.document.formtest) {
   	buenas=0; malas=0; puntuacion=0;
   	comprobar(op1.checked, false);
   	comprobar(op2.checked, true);
   	comprobar(op3.checked, false );
   	comprobar(op4.checked, false);
   	comprobar(op5.checked, true );
   	comprobar(op6.checked, true );
   	comprobar(op7.checked, false );
	ExplicacionResultado=
	"1) Falso. No son simb�licos sino r�gidos.\n" +
	"2) Cierto.\n" +
	"3) Falso. Solo recuperaremos 10Mbytes porque.\n" +
	"   comparten los tr�s el mismo espacio f�sico.\n" +
	"4) Falso. Eso ocurr�a con los enlaces r�gidos.\n" +
	"5) Cierto.\n" +
	"6) Cierto.\n" +
	"7) Falso. Por ejemplo /proc no reside en disco.\n" ;
	Explicar();
   }
}

function limpia1(){
    with (self.document.formtest){
   	 respuesta.value="";
	 op1.checked=false;
	 op2.checked=false;
	 op3.checked=false;
	 op4.checked=false;
	 op5.checked=false;
	 op6.checked=false;
	 op7.checked=false;
    }
}

function mensaje(){
    self.document.formtest.respuesta.value="  Aqui aparecer� el resultado del test"
}

