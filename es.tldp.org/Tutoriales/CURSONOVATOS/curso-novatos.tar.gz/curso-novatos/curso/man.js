function result(){
   with (self.document.formtest) {
   	buenas=0; malas=0; puntuacion=0;
   	comprobar(op1.checked, true );
   	comprobar(op2.checked, false);
   	comprobar(op3.checked, false);
   	comprobar(op4.checked, true );
   	comprobar(op5.checked, true );
      	respuesta.value= "Aciertos=" + buenas + " Fallos=" + malas + 
	"\n\nPuede probar de nuevo o consultar la\n" + 
	"soluci�n que mostramos a continuaci�n:\n\n" +
	"1) Cierto. Para algunos es la secci�n m�s interesante. \n" +
	"2) Falso. Era la opci�n -a\n" +
	"3) Falso. Consulte el manual man(1) ver� que hay m�s\n" +
	"4) Cierto. \n" +
	"5) Cierto. \n" ;
   }
}

function limpia1(){
    with (self.document.formtest){
   	 respuesta.value="";
	 op1.checked=false;
	 op2.checked=false;
	 op3.checked=false;
	 op4.checked=false;
	 op5.checked=false;
    }
}

function mensaje(){
    self.document.formtest.respuesta.value="  Aqui aparecer� el resultado del test"
}

