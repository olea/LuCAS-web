function result(){
   with (self.document.formtest) {
   	buenas=0; malas=0; puntuacion=0;
   	comprobar(op1.checked, false);
   	comprobar(op2.checked, false);
   	comprobar(op3.checked, false);
   	comprobar(op4.checked, false);
   	comprobar(op5.checked, false);
   	comprobar(op6.checked, true);
   	comprobar(op7.checked, false);
      	respuesta.value= "Aciertos=" + buenas + " Fallos=" + malas + 
	"\n\nPuede probar de nuevo o consultar la\n" + 
	"soluci�n que mostramos a continuaci�n:\n\n" +
	"1) Falso. Msdos se inspir� en los SO Unix de la �poca \n" +
	"2) Falso. El sistema de mantenimiento de paquetes es uno de los puntos fuertes de Debian\n" +
	"3) Falso. Son cosas distintas. El interprete de comandos fu� realizado por GNU y el nucleo por Linus Torwalds.\n" +
	"4) Falso. El compilador de C fu� desarrollado por GNU\n" +
	"5) Falso. \n" +
	"6) Cierto. \n"  +
	"7) Falso.  Debian trabaja solo con software libre pero GPL no es la unica licencia considerada libre por Debian\n" ;
	; 
   }
}

function limpia1(){
    with (self.document.formtest){
   	 respuesta.value="";
	 op1.checked=false;
	 op2.checked=false;
	 op3.checked=false;
	 op4.checked=false;
	 op5.checked=false;
	 op6.checked=false;
	 op7.checked=false;
    }
}

function mensaje(){
    self.document.formtest.respuesta.value="  Aqui aparecer� el resultado del test"
}

