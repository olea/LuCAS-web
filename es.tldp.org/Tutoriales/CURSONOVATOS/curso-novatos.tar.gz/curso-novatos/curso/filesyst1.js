function result(){
   with (self.document.formtest) {
   	buenas=0; malas=0; puntuacion=0;
   	comprobar(op1.checked, false);
   	comprobar(op2.checked, false );
   	comprobar(op3.checked, false );
   	comprobar(op4.checked, false );
   	comprobar(op5.checked, true );
   	comprobar(op6.checked, true );
   	comprobar(op7.checked, true );
   	comprobar(op8.checked, false);
   	comprobar(op9.checked, false);
   	comprobar(op10.checked, false);
   	comprobar(op11.checked, true);
   	comprobar(op12.checked, true);
   	comprobar(op13.checked, false);
   	comprobar(op14.checked, true);
   	comprobar(op15.checked, false);
   	comprobar(op16.checked, true);
	ExplicacionResultado=
	"1) Falso. No es buena idea usar el '*' pero puede hacerse.\n" +
	"2) Falso. Para el kernel son ficheros normales.\n" +
	"3) Falso. Eso es cierto en MSDOS per en Linux no.\n" +
	"4) Falso. No es buena idea pero puede hacerse.\n" +
	"5) Cierto.\n" +
	"6) Cierto.\n" +
	"7) Cierto.'\n" +
	"8) Falso. Se usa en ambos casos 'mv'\n" +
	"9) Falso. Si todav�a no sabe que la peligrosa opci�n de borrado\n" +
	"recursivo es '-r' se expone a un disgusto. !Cuidado con ella!\n" +
	"10) Falso. No solo no copia al directorio actual sino que lo\n" +
	"copiar� al �ltimo fichero expandido por la bash que quizas sea el\n" +
	"que ten�a la informaci�n m�s valiosa. Lo correcto era cp 'seg/* .'\n" +
	"11) Cierto. Es una cualidad muy importante de este tipo de links\n" +
	"12) Cierto.\n" +
	"13) Falso. Es una limitaci�n importante de este tipo de links\n" +
	"14) Cierto.\n" +
	"15) Falso.\n" +
	"16) Cierto.\n" ;
	Explicar();
   }
}

function limpia1(){
    with (self.document.formtest){
   	 respuesta.value="";
	 op1.checked=false;
	 op2.checked=false;
	 op3.checked=false;
	 op4.checked=false;
	 op5.checked=false;
	 op6.checked=false;
	 op7.checked=false;
	 op8.checked=false;
	 op9.checked=false;
	 op10.checked=false;
	 op11.checked=false;
	 op12.checked=false;
	 op13.checked=false;
	 op14.checked=false;
	 op15.checked=false;
	 op16.checked=false;
    }
}

function mensaje(){
    self.document.formtest.respuesta.value="  Aqui aparecer� el resultado del test"
}

