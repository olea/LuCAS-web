function result(){
   with (self.document.formtest) {
   	buenas=0; malas=0; puntuacion=0;
   	comprobar(op1.checked, false);
   	comprobar(op2.checked, false);
   	comprobar(op3.checked, false);
   	comprobar(op4.checked, false);
   	comprobar(op5.checked, false);
   	comprobar(op6.checked, false);
   	comprobar(op7.checked, false);
      	respuesta.value= "Aciertos=" + buenas + " Fallos=" + malas + 
	"\n\nPuede probar de nuevo o consultar la\n" + 
	"soluci�n que mostramos a continuaci�n:\n\n" +
	"1) Falso. El caracter '#' no tiene porque estar al principio de l�nea.\n" +
	"2) Falso. Saca las opciones del comando man. \n" +
	"3) Falso. No siempre. \n" +
	"4) Falso. Los ficheros del sistema no. Solo los del directorio actual. \n" +
	"5) Falso. No se usa ning�n fichero temporal. \n" +
	"6) Falso. Basta con probar y se dar� cuenta de ello. \n" +
	"7) Falso. Basta con probar y se dar� cuenta de ello. \n" ;
   }
}

function limpia1(){
    with (self.document.formtest){
   	 respuesta.value="";
	 op1.checked=false;
	 op2.checked=false;
	 op3.checked=false;
	 op4.checked=false;
	 op5.checked=false;
	 op6.checked=false;
	 op7.checked=false;
	 op8.checked=false;
    }
}

function mensaje(){
    self.document.formtest.respuesta.value="  Aqui aparecer� el resultado del test"
}

