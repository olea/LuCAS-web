
function result(){
   with (self.document.formtest) {
   	buenas=0; malas=0; puntuacion=0;
   	comprobar(op1.checked, true );
   	comprobar(op2.checked, false);
   	comprobar(op3.checked, false);
   	comprobar(op4.checked, true );
   	comprobar(op5.checked, false );
   	comprobar(op6.checked, true  );
      	respuesta.value= "Aciertos=" + buenas + " Fallos=" + malas + 
	"\n\nPuede probar de nuevo o consultar la\n" + 
	"soluci�n que mostramos a continuaci�n:\n\n" +
	"1) Cierto. \n" +
	"2) Falso. El directorio actual es el '.' \n" +
	"3) Falso. El UID de root si que es 0.\n" +
	"4) Cierto. \n" +
	"5) Falso. Un solo procesador puede repartir su tiempo entre varios procesos\n" +
	"6) Cierto. \n" ;
   }
}

function limpia1(){
    with (self.document.formtest){
   	 respuesta.value="";
	 op1.checked=false;
	 op2.checked=false;
	 op3.checked=false;
	 op4.checked=false;
	 op5.checked=false;
	 op6.checked=false;
    }
}

function mensaje(){
    self.document.formtest.respuesta.value="  Aqui aparecer� el resultado del test"
}

