function result(){
   with (self.document.formtest) {
   	buenas=0; malas=0; puntuacion=0;
   	comprobar(op1.checked, false);
   	comprobar(op2.checked, false);
   	comprobar(op3.checked, false);
   	comprobar(op4.checked, false);
   	comprobar(op5.checked, false);
   	comprobar(op6.checked, false);
	ExplicacionResultado=
	"1) Falso. Init permanece vivo todo el rato.\n" +
	"2) Falso. Solo es posible hacerlo de padre a hijo.\n" +
	"3) Falso. Son el mismo proceso en instantes distintos.\n" +
	"4) Falso. Sleep no consume tiempo de CPU.\n" +
	"5) Falso. Es al rev�s. Primero kill -15 y luego kill -9.\n" +
	"6) Falso. El comando 'nice -10' incrementa el valor de NICE y decrementa la prioridad.\n" +
        Explicar();	
   }
}

function limpia1(){
    with (self.document.formtest){
   	 respuesta.value="";
	 op1.checked=false;
	 op2.checked=false;
	 op3.checked=false;
	 op4.checked=false;
	 op5.checked=false;
	 op6.checked=false;
    }
}


