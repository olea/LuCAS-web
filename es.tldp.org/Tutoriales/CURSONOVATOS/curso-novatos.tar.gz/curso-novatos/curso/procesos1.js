function result(){
   with (self.document.formtest) {
   	buenas=0; malas=0; puntuacion=0;
   	comprobar(op1.checked, false);
   	comprobar(op2.checked, true );
   	comprobar(op3.checked, true );
   	comprobar(op4.checked, true );
   	comprobar(op5.checked, true );
   	comprobar(op6.checked, true );
   	comprobar(op7.checked, false);
	ExplicacionResultado=
	"1) Falso. Pueden estar funcionando simultaneamente varios procesos que ejecutan el mismo programa.\n" +
	"2) Falso. Con el mismo PID no pero con el mismo PPID si.\n" +
	"3) Cierto.\n" +
	"4) Cierto.\n" +
	"5) Cierto.\n" +
	"6) Cierto.\n" +
	"7) Falso. La primera instrucci�n del nuevo proceso continua con la siguiente instrucci�n al fork() que lo origin�.\n" ;
	Explicar();
   }
}

function limpia1(){
    with (self.document.formtest){
   	 respuesta.value="";
	 op1.checked=false;
	 op2.checked=false;
	 op3.checked=false;
	 op4.checked=false;
	 op5.checked=false;
	 op6.checked=false;
	 op7.checked=false;
    }
}

function mensaje(){
    self.document.formtest.respuesta.value="  Aqui aparecer� el resultado del test"
}

