malas=0;
buenas=0;
puntuacion=0;
ExplicacionResultado="";

function GoBack(){
   history.go(-1);
}

function comprobar(valobtenido, valcorrecto){
	if (valobtenido==valcorrecto){
		buenas++;
	}
	else{
		malas++;
	}
	puntuacion=buenas-malas;
}

function Explicar(){
      self.document.formtest.respuesta.value= "Aciertos=" + buenas + " Fallos=" + malas +
        "\n\nPuede probar de nuevo o consultar la\n" +
        "soluci�n que mostramos a continuaci�n:\n\n" + ExplicacionResultado;
}			


function mensaje(){
    self.document.formtest.respuesta.value="  Aqui aparecer� el resultado del test"
}
    
