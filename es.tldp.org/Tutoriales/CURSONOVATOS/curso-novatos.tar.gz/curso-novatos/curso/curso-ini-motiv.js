function limpia1(){
    with (self.document.formtest){
   	 respuesta.value="";
	 op1.checked=false;
	 op2.checked=false;
	 op3.checked=false;
    }
}

function mensaje(){
    self.document.formtest.respuesta.value="  Aqui aparecer� el resultado del test"
}

function result(){
   with (self.document.formtest) {
   	buenas=0; malas=0; puntuacion=0;
   	comprobar(op1.checked, true);
   	comprobar(op2.checked, false);
   	comprobar(op3.checked, true);
       
       if (puntuacion== 3){
         respuesta.value="  El curso es apropiado para usted"
       } 
       else if (puntuacion== -3){
         respuesta.value="Usted necesita este curso urgentemente"
       } 
       else {
         respuesta.value="Este curso es muy apropiado para usted"
       }
   }
}
