# LaTeX2HTML 2K.1beta (1.62)
# Associate internals original text with physical files.


$key = q/sec:comandos-texto/;
$ref_files{$key} = "$dir".q|Guia-Vim.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:cambios-visual/;
$ref_files{$key} = "$dir".q|Guia-Vim.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:vimrc/;
$ref_files{$key} = "$dir".q|Guia-Vim.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:cmd-set/;
$ref_files{$key} = "$dir".q|Guia-Vim.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:movsimples/;
$ref_files{$key} = "$dir".q|Guia-Vim.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:marcas/;
$ref_files{$key} = "$dir".q|Guia-Vim.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:objtexto/;
$ref_files{$key} = "$dir".q|Guia-Vim.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:visual/;
$ref_files{$key} = "$dir".q|Guia-Vim.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:next/;
$ref_files{$key} = "$dir".q|Guia-Vim.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:saltos-linea/;
$ref_files{$key} = "$dir".q|Guia-Vim.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:rango/;
$ref_files{$key} = "$dir".q|Guia-Vim.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:nombteclas/;
$ref_files{$key} = "$dir".q|Guia-Vim.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:apendice/;
$ref_files{$key} = "$dir".q|Guia-Vim.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-ambito/;
$ref_files{$key} = "$dir".q|Guia-Vim.html|; 
$noresave{$key} = "$nosave";

1;

