
/* Copyright (c) Miguel Angel Sepulveda, 1998. */

/* This program is freely distributable without licensing fees 
   and is provided without guarantee or warrantee expressed or 
   implied. This program is -not- in the public domain. */

#ifndef __GD_DEFINITIONS_H  
#define __GD_DEFINITIONS_H 1  
 
#include <GL/glut.h> 
#include <string.h> 
#include <iostream.h> 
#include <stdio.h> 
#include <math.h> 
 
 
/********************************************************************\  
*         D E F I N I T I O N S    
\********************************************************************/  
#define GD_COMPRESSION_FACTOR      0.01  
#define GD_EXPANSION_FACTOR        0.01  
#define GD_MAX_DENSITY             0.800  
#define GD_MAX_EQUILIBRATION_STEPS 1000  
#define GD_EQUILIBRIUM_TOLERANCE   0.05 
#define GD_EQUILIBRIUM_STEPS       50 
#define GD_DENSITY_CHANGE          0.005 
 
#ifndef pi 
#define pi  3.141592 
#endif 
 
 
#define nearest(x) (x > 0.0? int(x + 0.5) : int(x - 0.5)) 
 
 
 
#endif 
