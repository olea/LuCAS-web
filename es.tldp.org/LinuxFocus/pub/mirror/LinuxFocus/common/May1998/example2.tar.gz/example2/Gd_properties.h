
/* Copyright (c) Miguel Angel Sepulveda, 1998. */

/* This program is freely distributable without licensing fees 
   and is provided without guarantee or warrantee expressed or 
   implied. This program is -not- in the public domain. */

#ifndef __GD_PROPERTIES_H 
#define __GD_PROPERTIES_H 1 
 
 
class GdProperties{  
  /* Static class of physical properties meassurable */  
   
public:  
  /* Interface */  
  static double kineticEnergy(GdMonomer&);  
  static double temperature(GdMonomer&);  
    
  static double kineticEnergy(GdPolymer&);   
  static double temperature(GdPolymer&);   
   
  
};  
 
 
 
 
#endif 
