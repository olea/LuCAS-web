
/* Copyright (c) Miguel Angel Sepulveda, 1998. */

/* This program is freely distributable without licensing fees 
   and is provided without guarantee or warrantee expressed or 
   implied. This program is -not- in the public domain. */

#ifndef __GD_NOISE_H  
#define __GD_NOISE_H 1  
 
 
#define IA 16807   
#define IM 2147483647   
#define AM (1.0F/IM)   
#define IQ 127773   
#define IR 2836   
#define MASK 123459876   
 
 
double ran0(long *idum);  
 
 
inline double ran1(unsigned long *idum){  
  unsigned long itemp;  
  float rand;  
  static unsigned long jflone = 0x3f800000;  
  static unsigned long jflmsk = 0x007fffff;  
  *idum = 1664525L * *idum + 1013904223L;  
  itemp = jflone | (jflmsk & *idum);  
  rand = (*(float *)&itemp)-1.0F;  
  return (double)rand;  
};  
 
 
double ranGauss0(unsigned long *idum);  
 
 
#endif  
