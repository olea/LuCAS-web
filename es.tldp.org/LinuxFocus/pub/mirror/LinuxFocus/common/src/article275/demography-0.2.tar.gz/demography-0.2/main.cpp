#include <qapplication.h>
#include "form1.h"
#include "demogra/demogra1.h"

int main( int argc, char ** argv )
{
    QApplication a( argc, argv );
    Form1 *w = new Form1;
    w->show();
    a.connect( &a, SIGNAL( lastWindowClosed() ), &a, SLOT( quit() ) );
    return a.exec();
}
