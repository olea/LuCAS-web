// Einfaches Diagramm fuer die Demographiemodelle
// Programmer: Dr. Ralf Wieland
// Version 0.1
// Date: 12.3.2002

#ifndef _DIAGRAMM_H_
#define _DIAGRAMM_H_

#include <qwidget.h>
#include <qstring.h>
#include <qarray.h>
#include <qcolor.h>
#include <qframe.h>
#include <qwidget.h>
#include <qpainter.h>
#include <qbrush.h>
#include <stdio.h>
#include <iostream.h>
#include <math.h>
#include <float.h>
#include <values.h>

class QPaintEvent;

class diagramm : public QFrame
{
  Q_OBJECT

 public:
    diagramm( int,int, QWidget* parent = 0
	      , const char* name = 0, WFlags fl = 0 );
  // Diagrammgroesse [0..x][0..y] 
  void paintEvent(QPaintEvent *);
  void set_fields(float*, float*,int);  // frau mann step
  private:
  int ix,iy;
  int step;
  float *mann, *frau;
  float mmax, fmax;
};

#endif
