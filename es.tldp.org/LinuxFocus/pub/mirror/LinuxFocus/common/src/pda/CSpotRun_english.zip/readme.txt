see http://www.pobox.com/~wtc/palmos/cspotrun
