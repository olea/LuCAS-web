
Peanut Reader(tm) version 3.1
--------------------------------
This package contains:

 - Peanut Reader application (PeanutReader.prc)
 - peanutpress.com books you have purchased (*.pdb files)
 - README.txt (this file)

*NOTE* Your peanutpress.com books are password protected!

To unlock your new Peanut Press book, follow these simple instructions:

1) Load the Peanut Reader application and books onto your 
   Palm Pilot using HotSync(R). 

2) Launch the Peanut Reader application and select Menu->Open to select 
   the book you would like to open.

3) When prompted for your name and password, enter the following 
   information:

       Name:     your name as it appears on your credit card
       Password: your credit card number

4) Happy reading!


Notes
------------------------------
We have designed the Peanut Reader to allow the reading experience to
match, as closely as possible, the reading experience of a paper-based
book. For this reason, peanutpress.com books, like paper-based books,
have pages.

peanutpress.com books allow the reader to read in the standard font or
to switch to a larger font for easier reading. Therefore, books will
effectively have two different page counts and layouts, one for each
font size. Note that changing font sizes will, by design, have no
effect on the strictly formatted title pages of a book. Font changes
will only affect the pages that follow.

Peanut Reader books are shipped in a proprietary encrypted
format. They are not readable using other text-reading software.
Books are encrypted to protect the intellectual property rights of
publishers and authors.


System Requirements
-------------------

Hardware:
* Palm OS device (Palm Pilot, Handspring Visor, etc.)
  Note: Palm Pilot Personal is not supported.
* 97K of free memory for the Peanut Reader application, plus sufficient
  free memory for each book (varies from 200K to 700K, depending upon the
  length of the book).

Software:
* Palm OS 2.0 or greater
* Synchronization software for downloading the Peanut Reader and books
  to your Palm device.



Copyright (c) 1998-2000 by peanutpress.com, Inc.  All rights reserved.

HotSync(R) is a registered trademark of 3Com Corporation.
