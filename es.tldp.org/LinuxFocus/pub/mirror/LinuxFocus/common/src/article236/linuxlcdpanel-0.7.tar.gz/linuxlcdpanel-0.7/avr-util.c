/* vim: set sw=8 ts=8 si : */
/*********************************************
* Copyright: GPL
*********************************************/
#include <io.h>

void delay_ms(unsigned int ms)
/* delay for a minimum of <ms> */
/* with a 4Mhz crystal, the resolution is 1 ms */
{
	unsigned int outer1, outer2;
     	outer1 = 200; /* 4 MHZ */
    	/* outer1 = 300;  6 MHZ */

    	while (outer1) {
		outer2 = 1000;
		while (outer2) {
			while ( ms ) ms--;
			outer2--;
		}
		outer1--;
	}
}

void delay_us(unsigned int us) 
/* delay for a minimum of <us> microseconds    */
/* with a 4Mhz crystal, the resolution is 1 us */
{
    while ( us ) us--;
} 


