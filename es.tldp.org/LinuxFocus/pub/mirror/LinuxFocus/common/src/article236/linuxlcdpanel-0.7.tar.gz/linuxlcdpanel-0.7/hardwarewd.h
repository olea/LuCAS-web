/* vim: set sw=8 ts=8 si : */
/*************************************************************************
 Title	:   C include file for watchdog reset
 Target:    any AVR device
 Copyright: GPL
***************************************************************************/
#ifndef WDHW_H
#define WDHW_H
/* watch dog connector */
#define WD PD7
#define WDDDR DDRD
#define WDPORT PORTD

extern void wd_settime(unsigned char timeout);
extern void wd_gettime(unsigned char *timeout);
extern unsigned char wd_status(void);
extern void wd_stop(void);
extern void wd_start(void);
extern void wd_init(void);
#endif /* WDHW_H */
