/* vim: set sw=8 ts=8 si : */
/*************************************************************************
 Title	:   C include file for analog conversion
 Target:    any AVR device
 Copyright: GPL
***************************************************************************/
#ifndef ANALOG_H
#define ANALOG_H

/* return analog value of a given channel. You must enable interrupt with
* * sei() in the main program */
extern int convertanalog(unsigned char channel);
#endif /* ANALOG_H */
