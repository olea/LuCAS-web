# LaTeX2HTML 2K.1beta (1.62)
# Associate labels original text with physical files.


$key = q/fig:Entornos-Graficos/;
$external_labels{$key} = "$URL/" . q|node20.html|; 
$noresave{$key} = "$nosave";

$key = q/enu:Cdigo-qlistview.cpp/;
$external_labels{$key} = "$URL/" . q|node256.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Esmertec/;
$external_labels{$key} = "$URL/" . q|node32.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Archivo-control/;
$external_labels{$key} = "$URL/" . q|node149.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-tx-IrDa/;
$external_labels{$key} = "$URL/" . q|node144.html|; 
$noresave{$key} = "$nosave";

$key = q/arch-conf-php/;
$external_labels{$key} = "$URL/" . q|node98.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-1/;
$external_labels{$key} = "$URL/" . q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-2/;
$external_labels{$key} = "$URL/" . q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-3/;
$external_labels{$key} = "$URL/" . q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-5/;
$external_labels{$key} = "$URL/" . q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-6/;
$external_labels{$key} = "$URL/" . q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-7/;
$external_labels{$key} = "$URL/" . q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-8/;
$external_labels{$key} = "$URL/" . q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-9/;
$external_labels{$key} = "$URL/" . q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Sharp-Zaurus-SL5500/;
$external_labels{$key} = "$URL/" . q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Impresion-IrDa-PersonalJava/;
$external_labels{$key} = "$URL/" . q|node193.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-JDBCTest.class/;
$external_labels{$key} = "$URL/" . q|node188.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Empleo-de-qvfb/;
$external_labels{$key} = "$URL/" . q|node107.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Inst-de-aplicaciones-php/;
$external_labels{$key} = "$URL/" . q|node213.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Codigo-programa-JDBCTest.java/;
$external_labels{$key} = "$URL/" . q|node263.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Controladores-JDBC/;
$external_labels{$key} = "$URL/" . q|node36.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Mizi/;
$external_labels{$key} = "$URL/" . q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:Jeode-edicion-PDA/;
$external_labels{$key} = "$URL/" . q|node32.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:Si-se-cambia/;
$external_labels{$key} = "$URL/" . q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Localizacin-de-imagenes/;
$external_labels{$key} = "$URL/" . q|node229.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-l10n-deutch.class/;
$external_labels{$key} = "$URL/" . q|node225.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Instalacion-de-PHP-Desktop/;
$external_labels{$key} = "$URL/" . q|node118.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:impresion-en-Qt/;
$external_labels{$key} = "$URL/" . q|node143.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:Catedral_Bazar/;
$external_labels{$key} = "$URL/" . q|node239.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Localizacion-de-inclusion/;
$external_labels{$key} = "$URL/" . q|node230.html|; 
$noresave{$key} = "$nosave";

$key = q/ite:variables_entorno_ARM/;
$external_labels{$key} = "$URL/" . q|node104.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Install-packages/;
$external_labels{$key} = "$URL/" . q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Codigo-archivo-HTML/;
$external_labels{$key} = "$URL/" . q|node183.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:programa-holamundo/;
$external_labels{$key} = "$URL/" . q|node130.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Configuracin-IrDa/;
$external_labels{$key} = "$URL/" . q|node85.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Localizacion-con-sprintf/;
$external_labels{$key} = "$URL/" . q|node228.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-l10n-English.class/;
$external_labels{$key} = "$URL/" . q|node225.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Codigo-applet-holaPJavaApplet/;
$external_labels{$key} = "$URL/" . q|node183.html|; 
$noresave{$key} = "$nosave";

$key = q/enu:direcorio-inicio-Apache/;
$external_labels{$key} = "$URL/" . q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Script-de-PHP-adivina.php/;
$external_labels{$key} = "$URL/" . q|node267.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Soporte-en-Chino/;
$external_labels{$key} = "$URL/" . q|node220.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-Qtscribble/;
$external_labels{$key} = "$URL/" . q|node136.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-holaPJava.class/;
$external_labels{$key} = "$URL/" . q|node182.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Archivo-control-iPKG/;
$external_labels{$key} = "$URL/" . q|node149.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-ir.php/;
$external_labels{$key} = "$URL/" . q|node212.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Impresion-Qt/;
$external_labels{$key} = "$URL/" . q|node143.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Cdigo-fuente-ir.php/;
$external_labels{$key} = "$URL/" . q|node269.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Programa-l10n.java/;
$external_labels{$key} = "$URL/" . q|node272.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Qtopia-Aleman/;
$external_labels{$key} = "$URL/" . q|node216.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:vars_entorno_ARM/;
$external_labels{$key} = "$URL/" . q|node167.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Lista-de-archivos/;
$external_labels{$key} = "$URL/" . q|node161.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Q-Reader/;
$external_labels{$key} = "$URL/" . q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Codigo-de-barra/;
$external_labels{$key} = "$URL/" . q|node143.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Open-PDA/;
$external_labels{$key} = "$URL/" . q|node30.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Localizacin-msgs-sprintf/;
$external_labels{$key} = "$URL/" . q|node228.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Compaq-iPaq/;
$external_labels{$key} = "$URL/" . q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Arquitectura-Sharp-Zaurus/;
$external_labels{$key} = "$URL/" . q|node28.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Add_Remove-Software/;
$external_labels{$key} = "$URL/" . q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Forma-Inserta-Datos/;
$external_labels{$key} = "$URL/" . q|node210.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Archivo-ir.desktop/;
$external_labels{$key} = "$URL/" . q|node164.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Opie-en-ipaq/;
$external_labels{$key} = "$URL/" . q|node27.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Terminal/;
$external_labels{$key} = "$URL/" . q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Traduccion-de-aplicaciones/;
$external_labels{$key} = "$URL/" . q|node223.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Yopy/;
$external_labels{$key} = "$URL/" . q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Stack-Qt/;
$external_labels{$key} = "$URL/" . q|node28.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:interactuando-MySQL-pJava/;
$external_labels{$key} = "$URL/" . q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Consideraciones-escenciales-PJAE/;
$external_labels{$key} = "$URL/" . q|node171.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Runtime-de-PersonalJava/;
$external_labels{$key} = "$URL/" . q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/enu:Codigo-qtscribble.cpp/;
$external_labels{$key} = "$URL/" . q|node254.html|; 
$noresave{$key} = "$nosave";

$key = q/append:Codigo-fuente-ir.java/;
$external_labels{$key} = "$URL/" . q|node265.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Prog-JDBCTest-otro-Servidor/;
$external_labels{$key} = "$URL/" . q|node189.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:localizacion-de-mensajes/;
$external_labels{$key} = "$URL/" . q|node227.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Opie-en-C-7xx/;
$external_labels{$key} = "$URL/" . q|node27.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Codigo-fuente-select.php/;
$external_labels{$key} = "$URL/" . q|node268.html|; 
$noresave{$key} = "$nosave";

$key = q/capi:Herramientas-de-Desarrollo./;
$external_labels{$key} = "$URL/" . q|node29.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Archivo-ir.control/;
$external_labels{$key} = "$URL/" . q|node163.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Backup_media/;
$external_labels{$key} = "$URL/" . q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Instalacin-phpMyAdmin-Zaurus/;
$external_labels{$key} = "$URL/" . q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:HanGil/;
$external_labels{$key} = "$URL/" . q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-l10n-spanish.class/;
$external_labels{$key} = "$URL/" . q|node225.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Programa-ir-Java/;
$external_labels{$key} = "$URL/" . q|node193.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Configuracin-MIME/;
$external_labels{$key} = "$URL/" . q|node121.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Softfield-VR3/;
$external_labels{$key} = "$URL/" . q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:SK-Telecom/;
$external_labels{$key} = "$URL/" . q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Script-PHP-InsertaDatos/;
$external_labels{$key} = "$URL/" . q|node210.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Programa-locale.php/;
$external_labels{$key} = "$URL/" . q|node274.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Cdigo-fuente-Ir-print-Qt/;
$external_labels{$key} = "$URL/" . q|node257.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:SL-5x00/;
$external_labels{$key} = "$URL/" . q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-adivina.php/;
$external_labels{$key} = "$URL/" . q|node206.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:backup-restore/;
$external_labels{$key} = "$URL/" . q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-10/;
$external_labels{$key} = "$URL/" . q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-11/;
$external_labels{$key} = "$URL/" . q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-12/;
$external_labels{$key} = "$URL/" . q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Applet-holaPJavaApplet.class/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:gspda/;
$external_labels{$key} = "$URL/" . q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Navegador-en-Chino/;
$external_labels{$key} = "$URL/" . q|node226.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Instalacion-Apache-con/;
$external_labels{$key} = "$URL/" . q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Codigo-fuente-holaPJava/;
$external_labels{$key} = "$URL/" . q|node179.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Unicode-en-Z/;
$external_labels{$key} = "$URL/" . q|node219.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Programa-ir-PHP/;
$external_labels{$key} = "$URL/" . q|node212.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Ligas-a-librerias/;
$external_labels{$key} = "$URL/" . q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Qt-Stack/;
$external_labels{$key} = "$URL/" . q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/anexo:Comandos-importantes-de/;
$external_labels{$key} = "$URL/" . q|node275.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Jeode/;
$external_labels{$key} = "$URL/" . q|node33.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Informat-Kaii/;
$external_labels{$key} = "$URL/" . q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Estructura-directorios-iPKG/;
$external_labels{$key} = "$URL/" . q|node147.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:script-select.php/;
$external_labels{$key} = "$URL/" . q|node211.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Sof-admin-reMota-MySQL/;
$external_labels{$key} = "$URL/" . q|node96.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Ventana-Details/;
$external_labels{$key} = "$URL/" . q|node154.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Creacin-courses/;
$external_labels{$key} = "$URL/" . q|node255.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Actualizacion-del-ROM/;
$external_labels{$key} = "$URL/" . q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Script-PHP-Create/;
$external_labels{$key} = "$URL/" . q|node209.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Codigo-tx-Irda/;
$external_labels{$key} = "$URL/" . q|node258.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Archivo-ir.html/;
$external_labels{$key} = "$URL/" . q|node166.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Cdigo-fuente-JDBCInserta.java/;
$external_labels{$key} = "$URL/" . q|node264.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:4P-DAT500/;
$external_labels{$key} = "$URL/" . q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Wecker-en-Aleman/;
$external_labels{$key} = "$URL/" . q|node216.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Comandos-escenciales/;
$external_labels{$key} = "$URL/" . q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Descripcion-de-archivos/;
$external_labels{$key} = "$URL/" . q|node148.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:creacion-del-ipk-ir_1.0.0_arm.ipk/;
$external_labels{$key} = "$URL/" . q|node167.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:aml-m7100/;
$external_labels{$key} = "$URL/" . q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Instalacion-del-SDK/;
$external_labels{$key} = "$URL/" . q|node101.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Instalacion-JDBC-desktop/;
$external_labels{$key} = "$URL/" . q|node116.html|; 
$noresave{$key} = "$nosave";

$key = q/ite:Definiendo-variables-Qt/;
$external_labels{$key} = "$URL/" . q|node127.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:uso-de-PHP/;
$external_labels{$key} = "$URL/" . q|node39.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Herramienta-ipkg-build/;
$external_labels{$key} = "$URL/" . q|node195.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:-Quepasa/;
$external_labels{$key} = "$URL/" . q|node18.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Filewalker/;
$external_labels{$key} = "$URL/" . q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Transfer-archivos-a-Z/;
$external_labels{$key} = "$URL/" . q|node158.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Creacion-ipk-con-mkipks/;
$external_labels{$key} = "$URL/" . q|node160.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Script-PHP-conexion-MySQL/;
$external_labels{$key} = "$URL/" . q|node208.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Jerarquia-de-directorios/;
$external_labels{$key} = "$URL/" . q|node196.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Aspectos-para-i18n/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Qt-C++/;
$external_labels{$key} = "$URL/" . q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Arranque-Apache/;
$external_labels{$key} = "$URL/" . q|node77.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Forma-Insertar-Datos/;
$external_labels{$key} = "$URL/" . q|node210.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Definiendo-variables-Java/;
$external_labels{$key} = "$URL/" . q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-JDBCInserta.class/;
$external_labels{$key} = "$URL/" . q|node191.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Variables-de-entorno/;
$external_labels{$key} = "$URL/" . q|node104.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Qtopia-en-Chino/;
$external_labels{$key} = "$URL/" . q|node226.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Localizacion-mensajes-PHP/;
$external_labels{$key} = "$URL/" . q|node227.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Creacion-directorios-ipk/;
$external_labels{$key} = "$URL/" . q|node196.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Archivo-desktop/;
$external_labels{$key} = "$URL/" . q|node150.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:SL-C7xx/;
$external_labels{$key} = "$URL/" . q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Sintaxis-URL-JDBC/;
$external_labels{$key} = "$URL/" . q|node37.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Instalacion-JDBC-Zaurus/;
$external_labels{$key} = "$URL/" . q|node74.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Royal/;
$external_labels{$key} = "$URL/" . q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Impresora-Cameo-3/;
$external_labels{$key} = "$URL/" . q|node143.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:config-arch-inicio-php/;
$external_labels{$key} = "$URL/" . q|node119.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Arrancando-MySQL/;
$external_labels{$key} = "$URL/" . q|node72.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2K.1beta (1.62)
# labels from external_latex_labels array.


1;

