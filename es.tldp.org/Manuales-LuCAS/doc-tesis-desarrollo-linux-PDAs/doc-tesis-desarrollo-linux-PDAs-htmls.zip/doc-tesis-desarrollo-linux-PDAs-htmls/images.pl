# LaTeX2HTML 2K.1beta (1.62)
# Associate images original text with physical files.


$key = q/{table}list{{}{{setlength{rightmargin}{leftmargin}{{setlength{listparindent}{0pt{}~else~{par{echo~''algo~sali�~mal'';{par{}{par{?>list{{par{{{{table};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="640" HEIGHT="312" BORDER="0"
 SRC="|."$dir".q|img13.png"
 ALT="\begin{table}\begin{list}{}{
\setlength{\rightmargin}{\leftmargin} \setlength{\...
...\}&nbsp;else&nbsp;\{
\par echo&nbsp;''algo&nbsp;sali�&nbsp;mal'';
\par\}
\par ?&gt;\end{list}\par\end{table}">|; 

$key = q/{table}selectlanguage{english}list{{}{{setlength{rightmargin}{leftmargin}{{setle<slashBODY>{par{<slashHTML>list{{par{selectlanguage{spanish}{{{table};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="563" HEIGHT="243" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="\begin{table}\selectlanguage{english}
\begin{list}{}{
\setlength{\rightmargin}{...
...LET&gt;
\par &lt;/BODY&gt;
\par &lt;/HTML&gt;\end{list}\par\selectlanguage{spanish}
\end{table}">|; 

$key = q/{table}selectlanguage{english}list{{}{{setlength{rightmargin}{leftmargin}{{setle*}{*}{*}{*}{*}{*}slashlist{{par{{{selectlanguage{spanish}{par{{table};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="612" HEIGHT="686" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="\begin{table}\selectlanguage{english}
\begin{list}{}{
\setlength{\rightmargin}{...
...}{*}{*}{*}{*}{*}{*}{*}{*}/\end{list}\par\selectlanguage{spanish}
\par\end{table}">|; 

$key = q/{table}description{item[M-Package:]Elnombredelpaquetequedebedeconcordarconlaexpraracterdeespacioseguidaporunpunto,ej{}``.''description{{par{{{{table};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="556" HEIGHT="995" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="\begin{table}\begin{description}
\item [M-Package:]El nombre del paquete que deb...
...er de espacio seguida por un
punto, ej {}\lq\lq  .''
\end{description}\par\end{table}">|; 

$key = q/{table}selectlanguage{english}list{{}{{setlength{rightmargin}{leftmargin}{{setleclude_pathchar`"{});{par{?>list{{par{selectlanguage{spanish}{{{table};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="649" HEIGHT="128" BORDER="0"
 SRC="|."$dir".q|img16.png"
 ALT="\begin{table}\selectlanguage{english}
\begin{list}{}{
\setlength{\rightmargin}{...
...e\_path\char\lq \uml {});
\par ?&gt;\end{list}\par\selectlanguage{spanish}
\end{table}">|; 

$key = q/{table}selectlanguage{english}list{{}{{setlength{rightmargin}{leftmargin}{{setles~old.'),12,7);{par{?>{par{list{{par{selectlanguage{spanish}{{{table};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="561" HEIGHT="404" BORDER="0"
 SRC="|."$dir".q|img14.png"
 ALT="\begin{table}\selectlanguage{english}
\begin{list}{}{
\setlength{\rightmargin}{...
...ths&nbsp;old.'),12,7);
\par ?&gt;
\par\end{list}\par\selectlanguage{spanish}
\end{table}">|; 

$key = q/{table}selectlanguage{english}list{{}{{setlength{rightmargin}{leftmargin}{{setle,10,50);{par{~~}{par{}{par{list{{par{selectlanguage{spanish}{{{table};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="542" HEIGHT="154" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="\begin{table}\selectlanguage{english}
\begin{list}{}{
\setlength{\rightmargin}{...
...,10,50);
\par&nbsp;&nbsp;\}
\par\}
\par\end{list}\par\selectlanguage{spanish}
\end{table}">|; 

$key = q/includegraphics[%%width=0.20paperwidth]{imagenesslashlogosslashlogo_anahuac2.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="148" HEIGHT="40" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\includegraphics[%%
width=0.20\paperwidth]{imagenes/logos/logo_anahuac2.eps}">|; 

$key = q/{table}list{{}{{setlength{rightmargin}{leftmargin}{{setlength{listparindent}{0pticador~del~resultado{par{echo~dollarresult;{par{?>list{{par{{{{table};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="623" HEIGHT="289" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="\begin{table}\begin{list}{}{
\setlength{\rightmargin}{\leftmargin} \setlength{\...
...ndentificador&nbsp;del&nbsp;resultado
\par echo&nbsp;\$result;
\par ?&gt;\end{list}\par\end{table}">|; 

$key = q/{table}selectlanguage{english}list{{}{{setlength{rightmargin}{leftmargin}{{setle;{par{~~}{par{}{par{?>{par{list{{par{selectlanguage{spanish}{{{table};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="571" HEIGHT="358" BORDER="0"
 SRC="|."$dir".q|img15.png"
 ALT="\begin{table}\selectlanguage{english}
\begin{list}{}{
\setlength{\rightmargin}{...
...
\par&nbsp;&nbsp;\}
\par\}
\par ?&gt;
\par\end{list}\par\selectlanguage{spanish}
\end{table}">|; 

$key = q/{table}list{{}{{setlength{rightmargin}{leftmargin}{{setlength{listparindent}{0ptp>{par{<slashFORM>{par{<slashBODY>{par{<slashHTML>list{{par{{{{table};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="447" HEIGHT="289" BORDER="0"
 SRC="|."$dir".q|img12.png"
 ALT="\begin{table}\begin{list}{}{
\setlength{\rightmargin}{\leftmargin} \setlength{\...
...&nbsp;registro''&gt;&lt;/p&gt;
\par &lt;/FORM&gt;
\par &lt;/BODY&gt;
\par &lt;/HTML&gt;\end{list}\par\end{table}">|; 

$key = q/{table}list{{}{{setlength{rightmargin}{leftmargin}{{setlength{listparindent}{0ptho~dollarconn;{par{mysql_close(dollarconn);{par{?>list{{par{{{{table};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="455" HEIGHT="104" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="\begin{table}\begin{list}{}{
\setlength{\rightmargin}{\leftmargin} \setlength{\...
...);
\par echo&nbsp;\$conn;
\par mysql\_close(\$conn);
\par ?&gt;\end{list}\par\end{table}">|; 

$key = q/{table}list{{}{{setlength{rightmargin}{leftmargin}{{setlength{listparindent}{0ptist{{par{selectlanguage{english}{{selectlanguage{spanish}{par{{table};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="525" HEIGHT="86" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="\begin{table}\begin{list}{}{
\setlength{\rightmargin}{\leftmargin} \setlength{\...
...+\end{list}\par\selectlanguage{english}
\selectlanguage{spanish}
\par\end{table}">|; 

$key = q/mathbf{copyright};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="24" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="$ \mathbf{\copyright}$">|; 

1;

