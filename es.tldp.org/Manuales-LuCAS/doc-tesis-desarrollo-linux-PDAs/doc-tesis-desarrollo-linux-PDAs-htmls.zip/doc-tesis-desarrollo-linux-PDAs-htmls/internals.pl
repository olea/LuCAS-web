# LaTeX2HTML 2K.1beta (1.62)
# Associate internals original text with physical files.


$key = q/fig:Entornos-Graficos/;
$ref_files{$key} = "$dir".q|node20.html|; 
$noresave{$key} = "$nosave";

$key = q/enu:Cdigo-qlistview.cpp/;
$ref_files{$key} = "$dir".q|node256.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Esmertec/;
$ref_files{$key} = "$dir".q|node32.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Archivo-control/;
$ref_files{$key} = "$dir".q|node149.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-tx-IrDa/;
$ref_files{$key} = "$dir".q|node144.html|; 
$noresave{$key} = "$nosave";

$key = q/arch-conf-php/;
$ref_files{$key} = "$dir".q|node98.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-1/;
$ref_files{$key} = "$dir".q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-2/;
$ref_files{$key} = "$dir".q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-3/;
$ref_files{$key} = "$dir".q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-5/;
$ref_files{$key} = "$dir".q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-6/;
$ref_files{$key} = "$dir".q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-7/;
$ref_files{$key} = "$dir".q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-8/;
$ref_files{$key} = "$dir".q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-9/;
$ref_files{$key} = "$dir".q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Sharp-Zaurus-SL5500/;
$ref_files{$key} = "$dir".q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Impresion-IrDa-PersonalJava/;
$ref_files{$key} = "$dir".q|node193.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-JDBCTest.class/;
$ref_files{$key} = "$dir".q|node188.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Empleo-de-qvfb/;
$ref_files{$key} = "$dir".q|node107.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Inst-de-aplicaciones-php/;
$ref_files{$key} = "$dir".q|node213.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Codigo-programa-JDBCTest.java/;
$ref_files{$key} = "$dir".q|node263.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Controladores-JDBC/;
$ref_files{$key} = "$dir".q|node36.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Mizi/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:Jeode-edicion-PDA/;
$ref_files{$key} = "$dir".q|node32.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:Si-se-cambia/;
$ref_files{$key} = "$dir".q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Localizacin-de-imagenes/;
$ref_files{$key} = "$dir".q|node229.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-l10n-deutch.class/;
$ref_files{$key} = "$dir".q|node225.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Instalacion-de-PHP-Desktop/;
$ref_files{$key} = "$dir".q|node118.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:impresion-en-Qt/;
$ref_files{$key} = "$dir".q|node143.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:Catedral_Bazar/;
$ref_files{$key} = "$dir".q|node239.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Localizacion-de-inclusion/;
$ref_files{$key} = "$dir".q|node230.html|; 
$noresave{$key} = "$nosave";

$key = q/ite:variables_entorno_ARM/;
$ref_files{$key} = "$dir".q|node104.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Install-packages/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Codigo-archivo-HTML/;
$ref_files{$key} = "$dir".q|node183.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:programa-holamundo/;
$ref_files{$key} = "$dir".q|node130.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Configuracin-IrDa/;
$ref_files{$key} = "$dir".q|node85.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Localizacion-con-sprintf/;
$ref_files{$key} = "$dir".q|node228.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-l10n-English.class/;
$ref_files{$key} = "$dir".q|node225.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Codigo-applet-holaPJavaApplet/;
$ref_files{$key} = "$dir".q|node183.html|; 
$noresave{$key} = "$nosave";

$key = q/enu:direcorio-inicio-Apache/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Script-de-PHP-adivina.php/;
$ref_files{$key} = "$dir".q|node267.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Soporte-en-Chino/;
$ref_files{$key} = "$dir".q|node220.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-Qtscribble/;
$ref_files{$key} = "$dir".q|node136.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-holaPJava.class/;
$ref_files{$key} = "$dir".q|node182.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Archivo-control-iPKG/;
$ref_files{$key} = "$dir".q|node149.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-ir.php/;
$ref_files{$key} = "$dir".q|node212.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Impresion-Qt/;
$ref_files{$key} = "$dir".q|node143.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Cdigo-fuente-ir.php/;
$ref_files{$key} = "$dir".q|node269.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Programa-l10n.java/;
$ref_files{$key} = "$dir".q|node272.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Qtopia-Aleman/;
$ref_files{$key} = "$dir".q|node216.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:vars_entorno_ARM/;
$ref_files{$key} = "$dir".q|node167.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Lista-de-archivos/;
$ref_files{$key} = "$dir".q|node161.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Q-Reader/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Codigo-de-barra/;
$ref_files{$key} = "$dir".q|node143.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Open-PDA/;
$ref_files{$key} = "$dir".q|node30.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Localizacin-msgs-sprintf/;
$ref_files{$key} = "$dir".q|node228.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Compaq-iPaq/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Arquitectura-Sharp-Zaurus/;
$ref_files{$key} = "$dir".q|node28.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Add_Remove-Software/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Forma-Inserta-Datos/;
$ref_files{$key} = "$dir".q|node210.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Archivo-ir.desktop/;
$ref_files{$key} = "$dir".q|node164.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Opie-en-ipaq/;
$ref_files{$key} = "$dir".q|node27.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Terminal/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Traduccion-de-aplicaciones/;
$ref_files{$key} = "$dir".q|node223.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Yopy/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Stack-Qt/;
$ref_files{$key} = "$dir".q|node28.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:interactuando-MySQL-pJava/;
$ref_files{$key} = "$dir".q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Consideraciones-escenciales-PJAE/;
$ref_files{$key} = "$dir".q|node171.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Runtime-de-PersonalJava/;
$ref_files{$key} = "$dir".q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/enu:Codigo-qtscribble.cpp/;
$ref_files{$key} = "$dir".q|node254.html|; 
$noresave{$key} = "$nosave";

$key = q/append:Codigo-fuente-ir.java/;
$ref_files{$key} = "$dir".q|node265.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Prog-JDBCTest-otro-Servidor/;
$ref_files{$key} = "$dir".q|node189.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:localizacion-de-mensajes/;
$ref_files{$key} = "$dir".q|node227.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Opie-en-C-7xx/;
$ref_files{$key} = "$dir".q|node27.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Codigo-fuente-select.php/;
$ref_files{$key} = "$dir".q|node268.html|; 
$noresave{$key} = "$nosave";

$key = q/capi:Herramientas-de-Desarrollo./;
$ref_files{$key} = "$dir".q|node29.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Archivo-ir.control/;
$ref_files{$key} = "$dir".q|node163.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Backup_media/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Instalacin-phpMyAdmin-Zaurus/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:HanGil/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-l10n-spanish.class/;
$ref_files{$key} = "$dir".q|node225.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Programa-ir-Java/;
$ref_files{$key} = "$dir".q|node193.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Configuracin-MIME/;
$ref_files{$key} = "$dir".q|node121.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Softfield-VR3/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:SK-Telecom/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Script-PHP-InsertaDatos/;
$ref_files{$key} = "$dir".q|node210.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Programa-locale.php/;
$ref_files{$key} = "$dir".q|node274.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Cdigo-fuente-Ir-print-Qt/;
$ref_files{$key} = "$dir".q|node257.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:SL-5x00/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-adivina.php/;
$ref_files{$key} = "$dir".q|node206.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:backup-restore/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-10/;
$ref_files{$key} = "$dir".q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-11/;
$ref_files{$key} = "$dir".q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_key-12/;
$ref_files{$key} = "$dir".q|node232.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Applet-holaPJavaApplet.class/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:gspda/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Navegador-en-Chino/;
$ref_files{$key} = "$dir".q|node226.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Instalacion-Apache-con/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Codigo-fuente-holaPJava/;
$ref_files{$key} = "$dir".q|node179.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Unicode-en-Z/;
$ref_files{$key} = "$dir".q|node219.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Programa-ir-PHP/;
$ref_files{$key} = "$dir".q|node212.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Ligas-a-librerias/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Qt-Stack/;
$ref_files{$key} = "$dir".q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/anexo:Comandos-importantes-de/;
$ref_files{$key} = "$dir".q|node275.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Jeode/;
$ref_files{$key} = "$dir".q|node33.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Informat-Kaii/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Estructura-directorios-iPKG/;
$ref_files{$key} = "$dir".q|node147.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:script-select.php/;
$ref_files{$key} = "$dir".q|node211.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Sof-admin-reMota-MySQL/;
$ref_files{$key} = "$dir".q|node96.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Ventana-Details/;
$ref_files{$key} = "$dir".q|node154.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Creacin-courses/;
$ref_files{$key} = "$dir".q|node255.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Actualizacion-del-ROM/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Script-PHP-Create/;
$ref_files{$key} = "$dir".q|node209.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Codigo-tx-Irda/;
$ref_files{$key} = "$dir".q|node258.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Archivo-ir.html/;
$ref_files{$key} = "$dir".q|node166.html|; 
$noresave{$key} = "$nosave";

$key = q/appen:Cdigo-fuente-JDBCInserta.java/;
$ref_files{$key} = "$dir".q|node264.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:4P-DAT500/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Wecker-en-Aleman/;
$ref_files{$key} = "$dir".q|node216.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Comandos-escenciales/;
$ref_files{$key} = "$dir".q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Descripcion-de-archivos/;
$ref_files{$key} = "$dir".q|node148.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:creacion-del-ipk-ir_1.0.0_arm.ipk/;
$ref_files{$key} = "$dir".q|node167.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:aml-m7100/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Instalacion-del-SDK/;
$ref_files{$key} = "$dir".q|node101.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Instalacion-JDBC-desktop/;
$ref_files{$key} = "$dir".q|node116.html|; 
$noresave{$key} = "$nosave";

$key = q/ite:Definiendo-variables-Qt/;
$ref_files{$key} = "$dir".q|node127.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:uso-de-PHP/;
$ref_files{$key} = "$dir".q|node39.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Herramienta-ipkg-build/;
$ref_files{$key} = "$dir".q|node195.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:-Quepasa/;
$ref_files{$key} = "$dir".q|node18.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Filewalker/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Transfer-archivos-a-Z/;
$ref_files{$key} = "$dir".q|node158.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Creacion-ipk-con-mkipks/;
$ref_files{$key} = "$dir".q|node160.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:Script-PHP-conexion-MySQL/;
$ref_files{$key} = "$dir".q|node208.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Jerarquia-de-directorios/;
$ref_files{$key} = "$dir".q|node196.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Aspectos-para-i18n/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Qt-C++/;
$ref_files{$key} = "$dir".q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Arranque-Apache/;
$ref_files{$key} = "$dir".q|node77.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Forma-Insertar-Datos/;
$ref_files{$key} = "$dir".q|node210.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Definiendo-variables-Java/;
$ref_files{$key} = "$dir".q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Programa-JDBCInserta.class/;
$ref_files{$key} = "$dir".q|node191.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Variables-de-entorno/;
$ref_files{$key} = "$dir".q|node104.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Qtopia-en-Chino/;
$ref_files{$key} = "$dir".q|node226.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Localizacion-mensajes-PHP/;
$ref_files{$key} = "$dir".q|node227.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Creacion-directorios-ipk/;
$ref_files{$key} = "$dir".q|node196.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Archivo-desktop/;
$ref_files{$key} = "$dir".q|node150.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:SL-C7xx/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Sintaxis-URL-JDBC/;
$ref_files{$key} = "$dir".q|node37.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Instalacion-JDBC-Zaurus/;
$ref_files{$key} = "$dir".q|node74.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Royal/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Impresora-Cameo-3/;
$ref_files{$key} = "$dir".q|node143.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:config-arch-inicio-php/;
$ref_files{$key} = "$dir".q|node119.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Arrancando-MySQL/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

1;

