# LaTeX2HTML 2002 (1.62)
# Associate internals original text with physical files.


$key = q/sec:OK/;
$ref_files{$key} = "$dir".q|node33.html|; 
$noresave{$key} = "$nosave";

1;

