# LaTeX2HTML 2002 (1.62)
# Associate images original text with physical files.


$key = q/{figure}vbox{include{instalacion}}{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="978" HEIGHT="1265" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\begin{figure}\vbox{\include{instalacion}
}\end{figure}">|; 

$key = q/to;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img21.png"
 ALT="$ \to $">|; 

$key = q/sim;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img20.png"
 ALT="$\sim $">|; 

$key = q/Rightarrow;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="$\Rightarrow$">|; 

$key = q/^{o};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img26.png"
 ALT="$^{o}$">|; 

$key = q/>;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="$&gt;$">|; 

$key = q/backslash;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img22.png"
 ALT="$\backslash $">|; 

1;

