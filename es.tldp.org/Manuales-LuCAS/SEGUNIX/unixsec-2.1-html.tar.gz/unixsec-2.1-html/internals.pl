# LaTeX2HTML 2K.1beta (1.48)
# Associate internals original text with physical files.


$key = q/cite_kn:hec88/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ran93/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/scriptrhosts/;
$ref_files{$key} = "$dir".q|node194.html|; 
$noresave{$key} = "$nosave";

$key = q/vig/;
$ref_files{$key} = "$dir".q|node313.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:aks96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ran98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:army/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:rus00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:kle90/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bell93/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:rus02/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:noo99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ibm00b/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ora/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:rob94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:eve92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:steg99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:sto88/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:sto89/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/bufover/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:jay95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:gob96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:rad92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:rad93/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ven92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:rad95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/admintool/;
$ref_files{$key} = "$dir".q|node127.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:rad97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:tho82/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:tho84/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ncsc91/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:vel02/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:swi92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:apo88/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/hand/;
$ref_files{$key} = "$dir".q|node120.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:cos97a/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:cos97b/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:syk70/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:row96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:hp00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:glo/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:gren00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:nee78/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:fly00a/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:fly00b/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:dea96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/switch/;
$ref_files{$key} = "$dir".q|node290.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:oss/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ark99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mos94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:fre98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ste90/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:rit86/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:cab96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ans98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ste98b/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ked99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:duf89/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ste94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/backups/;
$ref_files{$key} = "$dir".q|node38.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:fips81/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/ataques/;
$ref_files{$key} = "$dir".q|node9.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ste98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:and80/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:sg91/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:rfc1498/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:nist97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mar88a/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:lan94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mar88b/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:cou94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:det01/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:kah67/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bis95b/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:meh98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/perm/;
$ref_files{$key} = "$dir".q|node55.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:lu92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:sei99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/sensores-ids/;
$ref_files{$key} = "$dir".q|node288.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:win93/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ins97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:win95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ibm97b/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mcg96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:sal90/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:sch94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ibm97c/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:sch97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:sch98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:and94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bec96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:kla95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:gal96a/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:and96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:gal96b/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:and97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:car97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:smi92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:gli93/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:cap01/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:kra/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:cesid/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:tan91/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ran93a/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:pfl97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:hal94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/fingerprint/;
$ref_files{$key} = "$dir".q|node116.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:smi97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:phone02/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:tan95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/eavesdropping/;
$ref_files{$key} = "$dir".q|node37.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:tan96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/kerb/;
$ref_files{$key} = "$dir".q|node301.html|; 
$noresave{$key} = "$nosave";

$key = q/unixua/;
$ref_files{$key} = "$dir".q|node121.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:axe98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:sun96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:sun98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:hig88/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:tom75/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:hun92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:iso88/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/privgrp/;
$ref_files{$key} = "$dir".q|node178.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:il93/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/restoreops/;
$ref_files{$key} = "$dir".q|node104.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:her00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:cfs93/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:pla83/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:men96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:see89/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:dae96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ben96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/serv/;
$ref_files{$key} = "$dir".q|node203.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:kim94a/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:gon97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:kim94b/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ano97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:gon99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ran00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:kir95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/snort/;
$ref_files{$key} = "$dir".q|node290.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bha01/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:gra00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mcm97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/puertos/;
$ref_files{$key} = "$dir".q|node289.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:noo01/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ids99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:che92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:fis95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:che94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:rcg96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/linux_netsys/;
$ref_files{$key} = "$dir".q|node149.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:kim93/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ris01/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mey89/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:pro92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ell70/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:roy88/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mch95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:par81/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:open/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:tom94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:sho82/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mil87/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ks94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:phi97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:rfc1244/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bal99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:dau97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:skl01/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:dau98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:vic94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bus99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:sha49/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/fwlv/;
$ref_files{$key} = "$dir".q|node246.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ibm97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/tarops/;
$ref_files{$key} = "$dir".q|node105.html|; 
$noresave{$key} = "$nosave";

$key = q/iriscode/;
$ref_files{$key} = "$dir".q|node119.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:pon01/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mil90/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:sim90/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:olo92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:dif77/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:tit98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:par94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mil95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:rei88/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:dh76/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:rei89/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/attr/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:huo98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:lip75/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:par98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ss98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:vol97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:fel90/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:esc98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/secure-del/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:fel96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ches92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:cor86/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:gl91/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:kra97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:hol83/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bou96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ste00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/arq/;
$ref_files{$key} = "$dir".q|node235.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:san82/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mci89/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:goo94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:lap91/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mau00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:smu90/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:coc73/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:cow92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:den83/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:cow98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:kob92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/kerb-abbr/;
$ref_files{$key} = "$dir".q|node298.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:dav84/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/fixdist/;
$ref_files{$key} = "$dir".q|node172.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:rc570/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:riv90/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/fw1log/;
$ref_files{$key} = "$dir".q|node247.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:phrack54/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:nor99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:riv92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/vision/;
$ref_files{$key} = "$dir".q|node14.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:cor91/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:dik99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bre95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:axe98b/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:spa91b/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:san90/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:hpfaq/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:roe99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:gal96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:den90/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:cha92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:jv93/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/userdir/;
$ref_files{$key} = "$dir".q|node345.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:com95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:pep94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bac86/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:kat88/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:hea90/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:hu91/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ko96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ko97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:coh94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:gun96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ale97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/auth/;
$ref_files{$key} = "$dir".q|node109.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:zim95a/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:zim95b/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:coh99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:wra91a/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:wra91b/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:thu00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:tod96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/devices/;
$ref_files{$key} = "$dir".q|node102.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:pol93/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:gui92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/subsystem/;
$ref_files{$key} = "$dir".q|node161.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:hp96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:por92a/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:wil74/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:wil76/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/crypsys/;
$ref_files{$key} = "$dir".q|node306.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ree84/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:isv95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:dae96b/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/linkernel/;
$ref_files{$key} = "$dir".q|node150.html|; 
$noresave{$key} = "$nosave";

$key = q/fw1/;
$ref_files{$key} = "$dir".q|node243.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ke98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:nem89/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:koh95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:hou01/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:reh00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:fyo98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:nsa85/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ano01/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mog89/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cdrom/;
$ref_files{$key} = "$dir".q|node107.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:wack94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:gar95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:pin93/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mol92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ker84/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:gre99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:gar97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:zie01/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:spa88/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:spa89/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:spi01/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bis86/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:kru00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/progseg/;
$ref_files{$key} = "$dir".q|node82.html|; 
$noresave{$key} = "$nosave";

$key = q/nessus/;
$ref_files{$key} = "$dir".q|node329.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:man91/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ha99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:cert99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:siy95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/dmz/;
$ref_files{$key} = "$dir".q|node239.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:man96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ku95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mor79/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:gut96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/sc/;
$ref_files{$key} = "$dir".q|node112.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:lun90/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bal00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:nrc99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ylo96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:spa90/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mcc00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:por91/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:spa91/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/scav/;
$ref_files{$key} = "$dir".q|node47.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:por92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mai96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:lam73/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bis90/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:noo01b/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bis91/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:noo01c/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:spa96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:eck85/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:noo01d/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ibm00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bis92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:noo01e/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:schy94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bis95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bis96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bai97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:nist186/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mor85/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:er89/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:hp00b/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/lanwan/;
$ref_files{$key} = "$dir".q|node229.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:atk93/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:vas01/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:sho00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ciu99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/inspect/;
$ref_files{$key} = "$dir".q|node248.html|; 
$noresave{$key} = "$nosave";

$key = q/dumpops/;
$ref_files{$key} = "$dir".q|node104.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:alv88/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cpioops/;
$ref_files{$key} = "$dir".q|node106.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:lam81/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:fen99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:fri95/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:jan97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bet00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bel89/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:won01/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:chr94/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:muf93/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mou00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:ser91/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:gue97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:spi01b/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:wre98/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/biocomp/;
$ref_files{$key} = "$dir".q|node113.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:tox00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:pit99/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/agingcodes/;
$ref_files{$key} = "$dir".q|node127.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:iso/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:cow00/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:mel97/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:sem96/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bel91/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bel92/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:bel93/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kn:firefaq/;
$ref_files{$key} = "$dir".q|node380.html|; 
$noresave{$key} = "$nosave";

1;

