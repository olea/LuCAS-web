# LaTeX2HTML 2K.1beta (1.48)
# Associate images original text with physical files.


$key = q/textstyleparbox{4in}{vspace{8cm}itCopyrightcopyright2000,2002AntonioVillal'onHuelicenseisincludedinthesectionentitled`GNUFreeDocumentationLicense'.};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="522" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="$\textstyle \parbox{4in}{
\vspace{8cm}
\it Copyright \copyright 2000,2002 Anton...
...license is included in the section entitled
\lq GNU Free Documentation License'.}$">|; 

$key = q/ast;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="$\ast $">|; 

1;

