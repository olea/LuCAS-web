# LaTeX2HTML 2002-2-1 (1.70)
# Associate images original text with physical files.


$key = q/{figure}vspace{0.5in}{setlength{unitlength}{0.00083300in}<comment_mark>14{begingult}fontshape{updefault}selectfontDatos}}}picture{{{{figure};MSF=1.6;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="462" HEIGHT="159" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="\begin{figure}\vspace{0.5in}\setlength{\unitlength}{0.00083300in}%
\begingrou...
...\mddefault}\fontshape{\updefault}\selectfont Datos}}}
\end{picture}
\end{figure}">|; 

$key = q/textstyleparbox{4in}{vspace{8cm}itCopyrightcopyright2000,2002AntonioVillal'onHuelicenseisincludedinthesectionentitled`GNUFreeDocumentationLicense'.};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="9" HEIGHT="12" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="$\textstyle \parbox{4in}{
\vspace{8cm}
\it Copyright \copyright 2000,2002 Anton...
...license is included in the section entitled
\lq GNU Free Documentation License'.}$">|; 

1;

