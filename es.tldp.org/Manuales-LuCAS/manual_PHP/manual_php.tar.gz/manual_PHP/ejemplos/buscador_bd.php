<html>
<body>
<?php
	if (!isset($buscar)){
		echo "Debe especificar una cadena a buscar";
		echo "<p>Debe especificar una cadena a buscar</p> \n";
		echo "<p><a href=buscador_bd.htm>Volver</p> \n";echo "</html></body> \n";
		exit;
	}
	$link = mysql_connect("localhost", "nobody");
	mysql_select_db("mydb", $link);
	$sql = "SELECT * FROM agenda WHERE nombre LIKE '%$buscar%' ORDER BY nombre";
	$result = mysql_query($sql, $link);
	if ($row = mysql_fetch_array($result)){
		echo "<table border = '1'> \n";
		//Mostramos los nombres de las tablas
		echo "<tr> \n";
		mysql_field_seek($result,0);
		while ($field = mysql_fetch_field($result)){
			echo "<td><b>$field->name</b></td> \n";
		}
		echo "</tr> \n";
		do {
			echo "<tr> \n";
			echo "<td>".$row["id"]."</td> \n";
			echo "<td>".$row["nombre"]."</td> \n";
			echo "<td>".$row["direccion"]."</td> \n";
			echo "<td>".$row["telefono"]."</td> \n";
			echo "<td><a href='mailto:".$row["email"]."'>".$row["email"]."</a></td> \n";
			echo "</tr> \n";
		} while ($row = mysql_fetch_array($result));
		echo "</table> \n";
		echo "<p><a href=buscador_bd.htm>Volver</p> \n";echo "</html></body> \n";
	} else {
	echo "<p>�No se ha encontrado ning�n registro!</p>\n";
	echo "<p><a href=buscador_bd.htm>Volver</p> \n";
}
?>
</body>
</html>
