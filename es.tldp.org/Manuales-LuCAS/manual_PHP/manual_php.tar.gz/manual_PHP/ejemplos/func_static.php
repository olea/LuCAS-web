<htm>
<body>

<?PHP
	function contador (){
		static $count = 0;
		$count = $count + 1;
		return $count;
	}
	
	echo contador()."<BR>"; // imprimir� 1
	echo contador()."<BR>"; // imprimir� 2
	echo contador()."<BR>"; // imprimir� 3
?>

</body>
</htm>