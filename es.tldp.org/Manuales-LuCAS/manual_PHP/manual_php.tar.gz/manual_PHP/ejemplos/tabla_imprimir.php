<html>
<body>

<?PHP
	$ciudad = array("Par�s", "Roma", "Sevilla", "Londres");
	
	//contamos el n�mero de elementos de la tabla
	$numelentos = count($ciudad);
	
	//imprimimos todos los elementos de la tabla
	for ($i=0; $i < $numelentos; $i++)	{
		echo "La ciudad $i es $ciudad[$i] <BR>\n";
	}
?>



</body>
</html>