<html>
<body>
<?PHP
	$myvar = "Hola. Este es mi primer script en PHP \n";
	
	//Esto es un comentario
	echo $myvar;
?>
</body>
</html>