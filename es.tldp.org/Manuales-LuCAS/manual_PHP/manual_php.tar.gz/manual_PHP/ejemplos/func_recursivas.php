<html>
<body>

<?PHP
	function esEntero($numero) {
		if ($numero > 1) {
			return (esEntero($numero -1));
		
		} elseif ($numero < 0) {
			/* como los n�m. son sim�tricos�
			chequeamos lo convertimos a positvo */
			return (esEntero((-1) * $numero -1));
		
		} elseif (($numero > 0) AND ($numero < 1)) {
			return ("NO");

		} else {
			/* el cero es entero por definici�n */
			return ("SI");
		}

	} //fin function

	if ($enviar) {
		$numero = doubleval($numero);
		echo $numero." ".esEntero($numero)." es un n�mero entero<BR>\n";
		echo "<hr>\n";
	} 
?>
<p>utilice el punto(.) como separador de decimales</p>
<FORM METHOD="post" ACTION="<?PHP echo $PHP_SELF ?>">
	<p>N�mero <input type="text" name="numero" size="10" value="0"></p>
	<p><input type="submit" value="Enviar datos" name="enviar">�
</FORM>

</body>
</html>