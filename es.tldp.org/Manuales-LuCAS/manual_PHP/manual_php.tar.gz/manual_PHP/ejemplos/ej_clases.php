

<html>
<body>

<?php

require ("clase_mysql.inc.php");
$miconexion = new DB_mysql;
$miconexion->conectar("mydb", "localhost", "nobody", "");
$miconexion->consulta("SELECT * FROM agenda");
$miconexion->verconsulta();

?>
</body>
</html>
