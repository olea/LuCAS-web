<html>
<body>

<?PHP
	require ("clase_calendario.php");

	$nombremes = array (1=>"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre");
	
	echo "<h3 align='center'>Seleccione mes y a�o</h3>\n";
	echo "<form method='POST' action='$PHP_SELF'>\n";
	echo "<div align='center'>\n";
    echo "<center>\n";
    echo "<table border='0'>\n";
    echo "<tr>\n";
    echo "<td>Mes&nbsp;<select size='1' name='mes'>\n";
	
	for ($i=1; $i<=12; $i++){
		if ($i == $mes) {
			echo "<option value='$i' selected>".$nombremes[$i]."</option>";
		} else {
			echo "<option value='$i'>".$nombremes[$i]."</option>";
		}
	}
	echo "</select>&nbsp;&nbsp\n";
    echo "A�o<input type='text' name='anno' size='4' value='$anno'>&nbsp;&nbsp;\n";
    echo "<input type='submit' value=' Ver ' name='enviar'></td>\n";
    echo "</tr>\n";
    echo "</table>\n";
    echo "</center>\n";
	echo "</div>\n";
	echo "</form>\n";
	echo "<br>\n";

	if ($enviar) {
		$calendario = new calendario($anno, $mes);
//		$calendario->setTabla("center",0,45,55);
		$calendario->imprimir();
	}
?>
</body>
</html>
