<?PHP
	if ($enviar) {
		echo "Hola <b>" . $nombre . "</b> que tal est�s<BR>\n";
		echo "Eres " . $sexo . "<BR>\n";
		echo "Tienes " . $edad . "<BR>\n";
		echo "Tu sistema favorito es " . $sistema . "<BR>\n";
		if ($futbol) {
			echo "Te gusta el futbol <BR>\n";
		} else {
			echo "NO te gusta el futbol <BR>\n";
		}
		if ($aficiones != "") {
			echo "Tus aficiones son: <BR>\n";
			echo "<blockquote>\n";
			echo nl2br($aficiones);
			echo "</blockquote>\n";
		} else {
			echo "NO tienes aficiones <BR>\n";
		}
	}
	echo "<p><a href='formulario.htm'>VOLVER AL FORMULARIO</a></p>"
?>
