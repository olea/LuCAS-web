<html>
<body>
<p>Consulta con mysql_fetch_array()</p>
<?php
	$link = mysql_connect("localhost", "nobody");
	mysql_select_db("mydb", $link);
	$result = mysql_query("SELECT nombre, email FROM agenda", $link);
	if ($row = mysql_fetch_array($result)){
		echo "<table border = '1'> \n";
		echo "<tr> \n";
		echo "<td><b>Nombre</b></td> \n";
		echo "<td><b>E-Mail</b></td> \n";
		echo "</tr> \n";
		do {
			echo "<tr> \n";
			echo "<td>".$row["nombre"]."</td> \n";
			echo "<td>".$row["email"]."</td>\n";
			echo "</tr> \n";
		} while ($row = mysql_fetch_array($result));
		echo "</table> \n";
	} else {
		echo "� No se ha encontrado ning�n registro !";
	}
?>
</body>
</html>
