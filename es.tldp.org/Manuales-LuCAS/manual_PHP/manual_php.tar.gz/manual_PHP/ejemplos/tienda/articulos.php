<html>
<body>
<?PHP

	function form_articulo() {
		global $link, $id, $idsec, $articulo, $descripcion, $precio, $oferta, $disponible; 
		
		// obtenemos las secciones disponibles
		$res = mysql_query ("SELECT id_seccion, seccion FROM seccion", $link);
		$select_sec = "<select name='idsec'>\n";
		while ($sec = mysql_fetch_object($res)) {
			if ($sec->id_seccion == $idsec) {
				$select_sec .= "<option selected value=$sec->id_seccion>$sec->seccion</option>\n";
			} else {
				$select_sec .= "<option value=$sec->id_seccion>$sec->seccion</option>\n";
			}
		}
		$select_sec .= "</select>\n";
		if ($disponible == "NO") {
			$dis  = "<input type='radio' value='SI' name='disponible'><b>SI</b>\n";
			$dis .=	"&nbsp;<input type='radio' name='disponible' checked value='NO'><b>NO</b>\n";
		} else {
			$dis  = "<input type='radio' value='SI' checked name='disponible'><b>SI</b>\n";
			$dis .=	"&nbsp;<input type='radio' name='disponible' value='NO'><b>NO</b>\n";
		}
				
		?>
			<p>&nbsp;</p>
			<div align="center">
			<center>
			<table border="1" bgcolor="#00CC99" width="312" cellspacing="0" cellpadding="10">
			  <tr>
				<td bgcolor="#0099FF" height="30">
				  <p align="center"><b><font color="#FFFF00">Agregar / Editar ARTICULOS</font></b></td>
			  </tr>
			  <tr>
				<td>
				  <form method="POST" action="" enctype='multipart/form-data'>
					<input type="hidden" name='id' value="<?PHP echo $id ?>">
					<p><b>Nombre</b>&nbsp;<input type="text" name="articulo" size="50" value="<?PHP echo $articulo ?>"></p>
					<p><b>Precio</b>&nbsp;<input type="text" name="precio" size="10" value="<?PHP echo $precio ?>">&nbsp;&nbsp;
					   <b>Precio de Oferta</b>&nbsp;<input type="text" name="oferta" size="10" value="<?PHP echo $oferta ?>"></p>
					<p><b>Disponible:</b>&nbsp;&nbsp;<?PHP echo $dis ?>&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;&nbsp;<b>Seccion</b>&nbsp;&nbsp;<?PHP echo $select_sec ?></p>
					<p><b>Descripci�n</b><br><textarea rows="10" name="descripcion" cols="65"><?PHP echo $descripcion ?></textarea></p>
					<input type="hidden" name='MAX_FILE_SIZE' value='100000'>
					<p><b>Imagen del enlace</b>&nbsp;<input type="file" name="gif"></p>
					<p align="center"><input type="submit" value="Enviar" name="enviar"></p>
				  </form>
				</td>
			  </tr>
			</table>
			<p><a href="articulos.php">Listado de articuloes</a></p>
			</center>
			</div>

		<?PHP
	}

	function list_articulo(){
		
		global $link;

		//REVISAR
		$sql  = "SELECT DISTINCT a.id_articulo, a.articulo, a.precio, a.oferta, a.disponible, ";
		$sql .= "a.img_name, a.img_size, s.id_seccion, s.seccion FROM articulos AS a ";
		$sql .= "LEFT JOIN seccion AS s ON a.id_seccion = s.id_seccion";

		if (! $res = mysql_query($sql, $link)) {
			return mysql_error();
		}


		echo "<div align='center'>\n";
		echo "<table width='700' bgcolor='#00CC99' cellspacing='1' cellpadding='5'>\n";
		echo "<tr>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>ID</b></td>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>Seccion</b></td>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>Articulo</b></td>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>Precio</b></td>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>Oferta</b></td>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>Disponible</b></td>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>Imagen</b></td>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>Kb</b></td>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>&nbsp;</b></td>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>&nbsp;</b></td>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>&nbsp;</b></td>\n";

		echo "</tr>\n";

		while ($art = mysql_fetch_array($res)) {
			echo "<tr>\n";
			echo "<td>".$art["id_articulo"]."</td>\n";
			echo "<td>".$art["seccion"]."</td>\n";
			echo "<td>".$art["articulo"]."</td>\n";
			echo "<td>".$art["precio"]."</td>\n";
			echo "<td>".$art["oferta"]."</td>\n";
			echo "<td>".$art["disponible"]."</td>\n";
			echo "<td>".$art["img_name"]."</td>\n";
			echo "<td>".round($art["img_size"]/1024)."</td>\n";
			echo "<td><a href='$PHP_SELF?Eid=".$art["id_articulo"]."'>Editar</a></td>\n";
			echo "<td><a href='$PHP_SELF?Bid=".$art["id_articulo"]."'>Borrar</a></td>\n";
			if ($art["img_name"] <> "" ) {
				echo "<td><a href='img.php?id=".$art["id_articulo"]."' target='_blank'>Ver imagen</a></td>\n";
			} else {
				echo "<td>&nbsp;</td>\n";
			}
			echo "</tr>\n";
		}
		echo "</table>\n";
		echo "<p align='center'><a href='articulos.php?n=1'>Nueava articulo</a></p>\n";
		echo "</div>\n";

	}
	
	function editar_articulo($Eid){
		global $link, $id, $idsec, $articulo, $precio, $oferta, $descripcion, $gif;

			//REVISAR
		$sql  = "SELECT id_seccion, id_articulo, articulo, precio, oferta, disponible, img_name ";
		$sql .= "FROM articulos WHERE id_articulo=$Eid";

		$res = mysql_query($sql, $link);
		
		while ($art = mysql_fetch_object($res)) {
			$id = $art->id_articulo;			
			$idsec = $art->id_seccion;
			$articulo = $art->articulo;
			$precio = $art->precio;
			$oferta = $art->oferta;
			$descripcion = $art->descripcion;
			$gif = $art->img_name;
		}
		
		form_articulo();
	}


	function guardar_articulo($id=0){
		
		global $link, $idsec;
		global $articulo, $descripcion, $precio, $oferta, $disponible, $gif, $gif_name, $gif_size, $gif_type;


		if ($id <> 0) { //editar
			if ($gif <> "none" AND $gif_size > 0) {
				$imagen  = "img_name = '$gif_name', ";
				$imagen .= "img_size = $gif_size, ";
				$imagen .= "img_type = '$gif_type', ";
				$imagen .= "img_data = '".addslashes(fread(fopen($gif, "r"), filesize($gif)))."'";
			}
			$sql  = "UPDATE articulos SET id_seccion='$idsec', articulo='$articulo', descripcion='$descripcion', ";
			$sql .= "precio='$precio', oferta='$oferta', disponible='$disponible'";
			if ($imagen) $sql .= ", ".$imagen ;
			$sql .= " WHERE id_articulo=$id";

		} else { //a�adir
			if ($gif <> "none" AND $gif_size > 0) {
				$imagen  = "'$gif_name', $gif_size, '$gif_type', ";
				$imagen .= "'".addslashes(fread(fopen($gif, "r"), filesize($gif)))."'";
			} else {
				$imagen = "'','', 0, ''";
			}
			
			$sql  = "INSERT INTO articulos VALUES (0, '$idsec', '$articulo', '$descripcion', '$precio', '$oferta', '$disponible', $imagen)";
			
		}
//echo $sql;
		$error = "";
		if (! mysql_query($sql, $link)) {
			$error = mysql_error();
		}

		return $error;

	}

	
	function borrar_articulo($id) {
		
		global $link;

		$sql = "DELETE FROM articulos WHERE id_articulo= $id";
		if (! mysql_query($sql, $link)){
			$error = mysql_error();
		}
		
		return $error;
	
	}

	function validar_campos(){
		
		global $articulo, $precio, $oferta, $disponible; 

		$vale = TRUE;
		
		if ($articulo == "") $vale = FALSE;

		//solo permitimos 11 caracteres, lo que soporta el campo
		$precio = (substr(strval($precio), 0, 11));
		$oferta = (substr(strval($oferta), 0, 11));
		
		//REVISAR 
		if (! ereg("([0-9]+)", $precio)) $vale = FALSE;
		if (! ereg("([0-9]+)", $oferta)) $vale = FALSE;

		return $vale;
	
	}

	// AQU� TERMINAN LAS FUNCIONES


	// conectamos al servidor 
	
	if ( $link = mysql_connect("localhost", "root","")) {
		mysql_select_db("tienda");
	} else {
		echo "Imposible conectar con el servidor";
		exit;
	}

	if ($enviar) {
		if (validar_campos()) {
			echo guardar_articulo($Eid);
			$id = 0;
			$articulo = "";
			$descripcion = "";
			list_articulo();
		} else {
			form_articulo();
		}

	} elseif ($Eid) {
		echo editar_articulo($Eid);

	} elseif ($Bid) {
		echo borrar_articulo($Bid);
		list_articulo();
	
	} elseif ($n == 1) {
		form_articulo();

	} else {
//	form_articulo();
	echo list_articulo();
	}


?>
</body>
</html>