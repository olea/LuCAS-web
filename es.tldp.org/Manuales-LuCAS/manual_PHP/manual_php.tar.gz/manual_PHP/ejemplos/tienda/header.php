<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>La Supertienda</title>
</head>

<body bgcolor="#FF9966">

<table border="0" width="100%" height="180">
  <tr>
    <td width="100%" height="38">
      <h1 align="center"><i>La Supertienda</i></h1>
    </td>
  </tr>
  <tr>
    <td width="100%" height="134">
      <p align="center">&nbsp;</p>
      <h3 align="center"><i><font color="#008000">Bienvenidos a nuestra tienda
      en Internet</font></i></h3>
    </td>
  </tr>
</table>