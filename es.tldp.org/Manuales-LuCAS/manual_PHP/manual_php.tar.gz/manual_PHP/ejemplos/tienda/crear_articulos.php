<?PHP
	
	$basedatos = "tienda";

	//conectamos con el servidor
	$link = @mysql_connect("localhost", "root", "");

	// comprobamos que hemos estabecido conexi�n en el servidor
	if (! $link){
		echo "<h2 align='center'>ERROR: Imposible establecer conecci�n con el servidor</h2>";
		exit;
	}

	// obtenemos una lista de las bases de datos del servidor
	$db = mysql_list_dbs();

	// vemos cuantas BD hay
	$num_bd = mysql_num_rows($db);
	
	//comprobamos si la BD que quermos crear exite ya
	$existe = "NO" ;
	for ($i=0; $i<$num_bd; $i++) {
		if (mysql_dbname($db, $i) == $basedatos) {
			$existe = "SI" ;
			break;
		}
	}

	// si no existe la creamos
	if ($existe == "NO") {
		/* manera 1 */
		if (! mysql_create_db($basedatos, $link)) {
			echo "<h2 align='center'>ERROR 1: Imposible crear base de datos</h2>";
			exit;
		} 
		/* manera 2 
		if (! mysql_query("CREATE DATABASE $basedatos", $link)){
			echo "<h2 align='center'>ERROR2: Imposible crear base de datos</h2>";
			exit;
		} */
	}

	// craamos la tabla
	$sql  = "CREATE TABLE articulos (";
    $sql .= "id_articulo int(11) DEFAULT '0' NOT NULL auto_increment, ";
	$sql .= "id_seccion int(11) DEFAULT '0' NOT NULL, ";
	$sql .= "articulo varchar(255) NOT NULL, ";
	$sql .= "descripcion text, ";
	$sql .= "precio double(16,0) DEFAULT '0', ";
	$sql .= "oferta double(16,0) DEFAULT '0', ";
	$sql .= "disponible char(2) DEFAULT 'SI' NOT NULL, ";
    $sql .= "img_name varchar(100), ";
	$sql .= "img_size int(11), ";
	$sql .= "img_type varchar(50), ";
	$sql .= "img_data blob, ";
	$sql .= "PRIMARY KEY (id_articulo), ";
	$sql .= "KEY id_articulo (id_articulo), ";
	$sql .= "UNIQUE id_articulo_2 (id_articulo) )";


	mysql_db_query($basedatos, $sql, $link);
	
	$error = mysql_error();

	if ($erorr) {
		echo "<h2 align='center'>$error</h2>";
	} else {
		echo "<h2 align='center'>La tabla se ha creado con �xito</h2>";
	}
	
?>

