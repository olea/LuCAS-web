<html>
<body>
<?PHP

	function form_seccion() {
		global $id, $seccion, $descripcion; 

		?>
			<p>&nbsp;</p>
			<div align="center">
			<center>
			<table border="1" bgcolor="#00CC99" width="312" cellspacing="0" cellpadding="10">
			  <tr>
				<td bgcolor="#0099FF" height="30">
				  <p align="center"><b><font color="#FFFF00">Agregar / Editar SECCI�N</font></b></td>
			  </tr>
			  <tr>
				<td width="304">
				  <form method="POST" action="" enctype='multipart/form-data'>
					<input type="hidden" name='id' value="<?PHP echo $id ?>">
					<p><b>Nombre</b><br><input type="text" name="seccion" size="20" value="<?PHP echo $seccion ?>"></p>
					<p><b>Descripci�n</b><br><textarea rows="5" name="descripcion" cols="37"><?PHP echo $descripcion ?></textarea></p>
					<input type="hidden" name='MAX_FILE_SIZE' value='100000'>
					<p align="left"><b>Imagen del enlace</b><br><input type="file" name="gif"></p>
					<p align="center"><input type="submit" value="Enviar" name="enviar"></p>
				  </form>
				</td>
			  </tr>
			</table>
			<p><a href="seccion.php">Listado de secciones</a></p>
			</center>
			</div>

		<?PHP
	}

	function list_seccion(){
		
		global $link;

		$sql = "SELECT id_seccion, seccion, descripcion, img_name, img_size FROM seccion";
		if (! $res = mysql_query($sql, $link)) {
			return "Imposible conecta con la tabla seccion";
		}


		echo "<div align='center'>\n";
		echo "<table width='550' bgcolor='#00CC99' cellspacing='1' cellpadding='5'>\n";
		echo "<tr>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>ID</b></td>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>Secci�n</b></td>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>Descripci�n</b></td>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>Imagen</b></td>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>Kb</b></td>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>&nbsp;</b></td>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>&nbsp;</b></td>\n";
		echo "<td bgcolor='#0099FF'><font color='#FFFF00'><b>&nbsp;</b></td>\n";

		echo "</tr>\n";

		while ($sec = mysql_fetch_object($res)) {
			echo "<tr>\n";
			echo "<td>".$sec->id_seccion."</td>\n";
			echo "<td><b>".$sec->seccion."</b></td>\n";
			echo "<td>".$sec->descripcion."</td>\n";
			echo "<td>".$sec->img_name."</td>\n";
			echo "<td>".round($sec->img_size/1024)."</td>\n";
			echo "<td><a href='$PHP_SELF?Eid=".$sec->id_seccion."'>Editar</a></td>\n";
			echo "<td><a href='$PHP_SELF?Bid=".$sec->id_seccion."'>Borrar</a></td>\n";
			if ($sec->img_name <> "") {
				echo "<td><a href='img.php?id=".$sec->id_seccion."' target='_blank'>Ver imagen</a></td>\n";
			} else {
				echo "<td>&nbsp;</td>\n";
			}
			echo "</tr>\n";
		}
		echo "</table>\n";
		echo "<p align='center'><a href='seccion.php?n=1'>Nueava seccion</a></p>\n";
		echo "</div>\n";

	}
	
	function editar_seccion($Eid){
		global $link, $id, $seccion, $descripcion, $gif;

		$sql  = "SELECT id_seccion, seccion, descripcion, img_name FROM seccion ";
		$sql .= "WHERE id_seccion=$Eid";
		$res = mysql_query($sql, $link);
		while ($sec = mysql_fetch_object($res)) {
			$id = $sec->id_seccion;			
			$seccion = $sec->seccion;
			$descripcion = $sec->descripcion;
			$gif = $sec->img_name;
		}
		form_seccion();
	}

	function guardar_seccion($id=0){
		
		global $link;
		global $seccion, $descripcion, $gif, $gif_name, $gif_size, $gif_type;


		if ($id <> 0) { //editar
			if ($gif <> "none" AND $gif_size > 0) {
				$imagen  = "img_name = '$gif_name', ";
				$imagen .= "img_size = $gif_size, ";
				$imagen .= "img_type = '$gif_type', ";
				$imagen .= "img_data = '".addslashes(fread(fopen($gif, "r"), filesize($gif)))."'";
			}
			$sql  = "UPDATE seccion SET seccion='$seccion', descripcion='$descripcion'";
			if ($imagen) $sql .= ", ".$imagen ;
			$sql .= " WHERE id_seccion=$id";

		} else { //a�adir
			if ($gif <> "none" AND $gif_size > 0) {
				$imagen  = "'$gif_name', $gif_size, '$gif_type', ";
				$imagen .= "'".addslashes(fread(fopen($gif, "r"), filesize($gif)))."'";
			} else {
				$imagen  = "'', '', 0, ''";
			}

			$sql  = "INSERT INTO seccion VALUES (0, '$seccion', '$descripcion', $imagen)";
		}

		$error = "";
		if (! mysql_query($sql, $link)) {
			$error = mysql_error();
		}

		return $error;

	}

	
	function borrar_seccion($id) {
		
		global $link;

		//comprobamos que las seccion no tiene articulos
		$sql = "SELECT id_articulo FROM articulos WHERE id_seccion=$id";
		
		$error = "";
		if ($res=mysql_query($sql, $link)) {
			if (mysql_num_rows($res)) {
				$ error = "Existen articulos en esa seccion";
			}
			
		} else {
			$error = "No se ha podido conectar con la base de datos de Articulos";
		}

		if (! $error) {
			$sql = "DELETE FROM seccion WHERE id_seccion= $id";
			if (! mysql_query($sql, $link)){
				$error = mysql_error();
			}
		}

		return $error;
	
	}

	// AQU� TERMINAN LAS FUNCIONES


	// conectamos al servidor 
	
	if ( $link = mysql_connect("localhost", "root","")) {
		mysql_select_db("tienda");
	} else {
		echo "Imposible conectar con el servidor";
		exit;
	}

	if ($enviar AND $seccion <> "") {
		echo guardar_seccion($Eid);
		$id = 0;
		$seccion = "";
		$descripcion = "";
		list_seccion();

	} elseif ($Eid) {
		echo editar_seccion($Eid);

	} elseif ($Bid) {
		echo borrar_seccion($Bid);
		list_seccion();
	
	} elseif ($n == 1) {
		form_seccion();

	} else {
		list_seccion();
	}


?>
</body>
</html>