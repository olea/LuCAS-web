<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Pagina nueva 1</title>
</head>
<body>

<?PHP

	if ($id) {
		echo "<p align='center'><img src=\"http://localhost/seccion_img.php?id=$id\"></p>";
	}
?>

</body>
</html>
