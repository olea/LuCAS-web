<?PHP
	
	$basedatos = "tienda";

	//conectamos con el servidor
	$link = @mysql_connect("localhost", "root", "");

	// comprobamos que hemos estabecido conexi�n en el servidor
	if (! $link){
		echo "<h2 align='center'>ERROR: Imposible establecer conecci�n con el servidor</h2>";
		exit;
	}

	// obtenemos una lista de las bases de datos del servidor
	$db = mysql_list_dbs();

	// vemos cuantas BD hay
	$num_bd = mysql_num_rows($db);
	
	//comprobamos si la BD que quermos crear exite ya
	$existe = "NO" ;
	for ($i=0; $i<$num_bd; $i++) {
		if (mysql_dbname($db, $i) == $basedatos) {
			$existe = "SI" ;
			break;
		}
	}

	// si no existe la creamos
	if ($existe == "NO") {
		/* manera 1 */
		if (! mysql_create_db($basedatos, $link)) {
			echo "<h2 align='center'>ERROR 1: Imposible crear base de datos</h2>";
			exit;
		} 
		/* manera 2 
		if (! mysql_query("CREATE DATABASE $basedatos", $link)){
			echo "<h2 align='center'>ERROR2: Imposible crear base de datos</h2>";
			exit;
		} */
	}

	// craamos la tabla
	$sql  = "CREATE TABLE seccion (";
    $sql .= "id_seccion int(11) DEFAULT '0' NOT NULL auto_increment, ";
	$sql .= "seccion varchar(20) NOT NULL, ";
	$sql .= "descripcion text, ";
    $sql .= "img_name varchar(100), ";
	$sql .= "img_size int(11), ";
	$sql .= "img_type varchar(50), ";
	$sql .= "img_data blob, ";
	$sql .= "PRIMARY KEY (id_seccion), ";
	$sql .= "KEY id_seccion (id_seccion), ";
	$sql .= "UNIQUE id_seccion_2 (id_seccion) )";



echo $sql;
	mysql_db_query($basedatos, $sql, $link);
	
	$error = mysql_error();

	if ($erorr) {
		echo "<h2 align='center'>$error</h2>";
	} else {
		echo "<h2 align='center'>La tabla se ha creado con �xito</h2>";
	}
	
?>

