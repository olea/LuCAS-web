<HTML>
<BODY bgcolor="#0080C0">

<?PHP
	require("agenda.lib.php");	
	
	$link = conectar_BD("agenda", "localhost", "root", "");
	
	if (!$link) {
		echo "<h2>$error<h2>\n";
		exit;
	}
	
	if ($enviar) {
			$nombre = substr($nombre, 0, 20);
			$apellidos = substr($apellidos, 0, 35);
			$direccion = substr($direccion, 0, 50);
			$localidad = substr($localidad, 0, 25);
			$provincia = substr($provincia, 0, 15);
			$cp = substr($cp, 0, 5);
			$telefono1 = substr($telefono1, 0, 15);
			$telefono2 = substr($telefono2, 0, 15);
			$fax = substr($fax, 0, 15);
			$mail = substr($mail, 0, 50);

		//Modificar
		if ($id) {
			//Modificar
			echo $i;
			$sql  = "UPDATE agenda SET ";
			$sql .= "nombre='$nombre', apellidos='$apellidos', direccion='$direccion', ";
			$sql .= "localidad='$localidad', provincia='$provincia', cp='$cp', ";
			$sql .= "telefono1='$telefono1', telefono2='$telefono2', fax='$fax', mail='$mail' ";
			$sql .= "WHERE id=$id";

			if (! mysql_query($sql, $link)) {
				echo "No se ha podido modificar<BR>\n";
			}
		} else {
			//A�adir
			if (!$nombre){
				echo "<H2 align='center'>ERROR: Debe especificar un nombre</h2>\n";
				formulario();
			} else {
				$sql  = "INSERT INTO agenda VALUES ";
				$sql .= "(0, '$nombre', '$apellidos', '$direccion', '$localidad','$provincia', ";
				$sql .= "'$cp', '$telefono1', '$telefono2', '$fax', '$mail')";

				if (! mysql_query($sql, $link)) {
					echo "No se ha podido a�adir<BR>\n";
				}
			}
		} 
		listado();

	} else {
		echo "<H2 align=\"center\"><font color=\"#FFFF00\">A�adir Contacto</H2>\n";
		formulario();

	} //fin if ($enviar)

?>

</BODY>
</HTML>