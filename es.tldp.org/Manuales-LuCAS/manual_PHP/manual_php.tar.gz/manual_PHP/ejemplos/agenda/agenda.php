<HTML>
<BODY bgcolor="#0080C0">

<?PHP
	require("agenda.lib.php");	
	
	$link = conectar_BD("agenda", "localhost", "root", "");
	
	if (!$link) {
		echo "<h2>$error<h2>\n";
		exit;
	} else {
		listado();
	}
?>

</BODY>
</HTML>