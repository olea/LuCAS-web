<HTML>
<BODY bgcolor="#0080C0">

<?PHP

	require("agenda.lib.php");

	$link = conectar_BD("agenda", "localhost", "root", "");
	
	if (!$link) {
		echo "<h2>$error<h2>\n";
		exit;
	}
	
	echo $i;

	if ($si) {
		$sql  = "DELETE FROM agenda WHERE id=$i";
		if (! mysql_query($sql, $link)) {
			echo "<h2 align='center'>ERROR: No se ha podido borrar</h2>\n";
		}
		listado();
	} elseif ($no) {
		listado();

	} else {
	
		echo "<h3 align='center'><font color=\"#FFFF00\">Borrar Contacto</h2>\n";
		if ($i) {
			$sql  = "SELECT * FROM agenda WHERE id=$i";
		} else {
			echo "<h2 align='center'>ERROR: Debe especificar un ID</h2>\n";
			exit;
		}

		$resultado = mysql_query($sql, $link);
		
		echo "<div align='center'>\n";
		echo "<table bgcolor='#99CCFF' border='2'>\n";
		echo "<tr><td>\n";
		echo "<table bgcolor='#99CCFF' border='0' width='400'>\n";
		

		while ($agenda = mysql_fetch_object($resultado)){
			$i = $agenda->id;
			echo "<tr>\n";
			echo "<td width='80'>Nombre:</td><td>&nbsp;<b>$agenda->nombre $agenda->apellidos</b></td>\n";
			echo "</tr>\n";
			echo "<tr>\n";
			echo "<td width='80'>Direcci�n:</td><td>&nbsp;<b>$agenda->direccion</b></td>\n";
			echo "</tr>\n";
			echo "<tr>\n";
			echo "<td width='80'>Localidad:</td><td>&nbsp;<b>$agenda->localidad</b></td>\n";
			echo "</tr>\n";
			echo "<tr>\n";
			echo "<td width='80'>Provincia:</td><td>&nbsp;<b>$agenda->provincia&nbsp;-&nbsp;$agenda->cp</b></td>\n";
			echo "</tr>\n";
			echo "<tr>\n";
			echo "<td width='80'>Telefono 1:</td><td>&nbsp;<b>$agenda->telefono1</b></td>\n";
			echo "</tr>\n";
			echo "<tr>\n";
			echo "<td width='80'>Telefono 2:</td><td>&nbsp;<b>$agenda->telefono2</b></td>\n";
			echo "</tr>\n";
			echo "<tr>\n";
			echo "<td width='80'>Fax:</td><td>&nbsp;<b>$agenda->fax</b></td>\n";
			echo "</tr>\n";
			echo "<tr>\n";
			echo "<td>E-mail:</td><td>&nbsp;<a href='mailto:$agenda->mail'><b>$agenda->mail</a></b></td>\n";
			echo "</tr>\n";
		}
		
		echo "</table>\n";
		echo "</td></tr>\n";
		echo "</table>\n";
		echo "<p><a href='modificar.php?i=$i'>Modificar</a>&nbsp;|&nbsp;";
		echo "<a href='listado.php'>Listado de contactos</a>&nbsp;|&nbsp;";
		echo "<a href='agenda_add.php'>A�adir contacto</a>&nbsp;|&nbsp;";
		echo "<a href='buscar.php'>Buscar</a></p>\n";
		
		echo "<form method='POST' action='$PHP_SELF'>\n";
		//variable oculta con el id del contacto
		echo "<input type='hidden' name='i' value='$i'>\n";
		echo "<table border='0'>\n";
		echo "<tr>\n";
		echo "<td>\n";
		echo "<p align='center'><b><font color='#FFFF00'>� Desea eliminar este contacto?</font></b></td>\n";
		echo "</tr>\n";
		echo "<tr>\n";
		echo "<td>\n";
		echo "<p align='center'><input type='submit' value='  SI  ' name='si'>&nbsp;&nbsp;\n";
		echo "<input type='submit' value=' NO ' name='no'></td>\n";
		echo "</tr>\n";
		echo "</table>\n";
		echo "<p>&nbsp;</p>\n";
		echo "</form>\n";

		echo "</div>\n";
	} 

?>

</BODY>
</HTML>
