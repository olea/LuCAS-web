<HTML>
<BODY bgcolor="#0080C0">
<H2 align="center"><font color=\"#FFFF00\">Modificar Datos</H2>

<?PHP

	require("agenda.lib.php");

	$link = conectar_BD("agenda", "localhost", "root", "");
	
	if (!$link) {
		echo "<h2>$error<h2>\n";
		exit;
	}

	if ($i) {
		$sql  = "SELECT * FROM agenda WHERE id=$i";
	} else {
		echo "<H2 align='center'>ERROR: Debe especificar un ID/h2>\n";
		exit;
	}



	$resultado = mysql_query($sql, $link);
	

	while ($agenda = mysql_fetch_object($resultado)){
		$id = $agenda->id;
		$nombre = $agenda->nombre;
		$apellidos = $agenda->apellidos;
		$direccion = $agenda->direccion;
		$localidad = $agenda->localidad;
		$provincia = $agenda->provincia;
		$cp = $agenda->cp;
		$telefono1 = $agenda->telefono1;
		$telefono2 = $agenda->telefono2;
		$fax = $agenda->fax;
		$mail = $agenda->mail;
	}
	formulario();	

?>

</BODY>
</HTML>
