<HTML>
<BODY bgcolor="#0080C0">

<?PHP

	require("agenda.lib.php");
	
	if (! $enviar){
		buscar();
	} else {

		if (!$link=conectar_BD("agenda", "localhost", "root", "")) {
			echo "<h2>$error<h2>\n";
			exit;
		} else {
			if ($nombre) {
				$sql_buscar = "nombre LIKE '%$buscar%' ";
			}
			if ($apellidos) {
				if ($sql_buscar <> "") {
					$sql_buscar .= "OR apellidos LIKE '%$buscar%' ";
				} else {
					$sql_buscar .= "apellidos LIKE '%$buscar%' ";
				}
			}
			if ($localidad) {
				if ($sql_buscar <> "") {
					$sql_buscar .= "OR localidad LIKE '%$buscar%' ";
				} else {
					$sql_buscar .= "localidad LIKE '%$buscar%' ";
				}
			}
			if ($provincia) {
				if ($sql_buscar <> "") {
					$sql_buscar .= "OR provincia LIKE '%$buscar%' ";
				} else {
					$sql_buscar .= "provincia LIKE '%$buscar%' ";
				}
			}
			if ($mail) {
				if ($sql_buscar <> "") {
					$sql_buscar .= "OR mail LIKE '%$buscar%' ";
				} else {
					$sql_buscar .= "mail LIKE '%$buscar%' ";
				}
			}

			echo "<H2 align=\"center\"><font color=\"#FFFF00\">Contactos disponibles</H2>\n";
			listado($sql_buscar);

		} //FIN if($link)

	} //FIN if($enviar)
?>

</BODY>
</HTML>
