<?PHP

	function conectar_BD($cfg_basedatos, $cfg_servidor, $cfg_usuario, $cfg_password) {

		global $error;
		
		/* conectamos al servidor */
		$link = @mysql_connect($cfg_servidor, $cfg_usuario, $cfg_password);
		if ($link) {
			/* seleccionamos la base de datos */
			if (!@mysql_select_db($cfg_basedatos, $link)) {
				$error = "Imposible conectar con la base de datos -".$cfg_basedatos."-" ;
			}
		} else {
			$error = "Imposible establecer conecci�n con el servidor -".$cfg_servidor."-" ;
		}

		return $link;

	} //FIN function conectar_BD


	function listado($buscar=""){

		global $link;
		
		$sql  = "SELECT id, nombre, apellidos, telefono1, mail ";
		$sql .= "FROM agenda ";
		if ($buscar) $sql .= "WHERE ".$buscar;
		$sql .= "ORDER BY apellidos, nombre";

		$resultado = mysql_query($sql, $link);

		echo "<H2 align=\"center\"><font color=\"#FFFF00\">Lista de Contactos</H2>\n";
	
		echo "<div align='center'>\n";
		echo "<table bgcolor='#99CCFF' border='2'>\n";
		echo "<tr><td>\n";
		echo "<table bgcolor='#99CCFF' cellspacing='2' cellpadding='4' border='0'>\n";
		echo "<tr>\n";
		echo "<td width='20'>&nbsp;</td>\n";
		echo "<td width='200'><b><u>NOMBRE</u></b></td>\n";
		echo "<td width='100'><b><u>TELEFONO</u></b></td>\n";
		echo "<td width='100'><b><u>E-MAIL</u></b></td>\n";
		echo "</tr>\n";
		
		$i=1;
		while ($agenda = mysql_fetch_object($resultado)){
			echo "<tr>\n";
			echo "<td width='20'><a href='contacto.php?i=".$agenda->id."'>".$i."</a></td>\n";
			echo "<td width='200'>".$agenda->apellidos.", ".$agenda->nombre."</td>\n";
			echo "<td width='100'>".$agenda->telefono1."</td>\n";
			echo "<td width='100'><a href='mailto:$agenda->mail'>".$agenda->mail."</a></td>\n";
			echo "</tr>\n";
			$i++ ;
		}
	
		echo "</table>\n";
		echo "</td></tr>\n";
		echo "</table>\n";
		echo "<p><a href='add_edit.php'>A�adir contacto</a> | <a href='buscar.php'>Buscar</a></p>\n";
		echo "</div>\n";
	
	} //FIN function listado



	function formulario() {
		global $id, $nombre, $apellidos, $direccion, $localidad, $provincia ;
		global $cp, $telefono1, $telefono2, $fax, $mail ;
		?>
			
			<div align="center">
			<table bgcolor="#99CCFF" cellspacing="2" cellpadding="4" border="2">
			<tr><td>
			<table bgcolor="#99CCFF" cellspacing="2" cellpadding="4" border="0">
			<form method="post" action="add_edit.php">
				<input type="hidden" name="id" value="<?PHP echo $id ?>">
				<tr>
				<td>Nombre&nbsp;&nbsp;&nbsp;<input type="text" name="nombre" size="20"  value="<?PHP echo $nombre ?>">
				&nbsp;&nbsp;Apellidos <input type="text" name="apellidos" size="35"  value="<?PHP echo $apellidos ?>"></td>
				</tr>
				<tr>
				<td>Direcci�n&nbsp; <input type="text" name="direccion" size="50"  value="<?PHP echo $direccion ?>">&nbsp;&nbsp;</td>
				</tr>
				<tr>
				<td>Localidad&nbsp; <input type="text" name="localidad" size="20"  value="<?PHP echo $localidad ?>">&nbsp;
				Provincia&nbsp;&nbsp;<input type="text" name="provincia" size="15"  value="<?PHP echo $provincia ?>">&nbsp;
				C.P. <input type="text" name="cp" size="10"  value="<?PHP echo $cp ?>"></td>
				</tr>
				</tr>		
				<td>Tel�fono 1 <input type="text" name="telefono1" size="15"  value="<?PHP echo $telefono1 ?>">&nbsp;
				Telefono 2 <input type="text" name="telefono2" size="15"  value="<?PHP echo $telefono2 ?>">&nbsp;
				Fax <input type="text" name="fax" size="15"  value="<?PHP echo $fax ?>"> &nbsp;</td>
				</tr>
				<tr>
				<td> Mail&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type="text" name="mail" size="50"  value="<?PHP echo $mail ?>"></td>
				</tr>
				<tr>
				<td align="center"><input type="submit" value="Enviar Datos" name="enviar">&nbsp;
				<input type="reset" value="Restablecer" name="B2"></td>
				</tr>
			</form>
			</table>
			</td></tr>
			</table>
			<p><a href='listado.php'>Listado de contacto</a> | <a href='buscar.php'>Buscar</a></p>
			</div>

		<?PHP
	}

	function buscar(){
	?>
		<h3 align="center"><font color="#FFFF00">Busqueda de cadenas</h3>
		<div align="center">
		<table width="425" border="2" bgcolor="#66CCFF">
			<tr><td width="417">
			<form method="POST" action="buscar.php">
				<p align="center">Cadena a buscar <input type="text" name="buscar" size="20"></p>
				<p align="center"><input type="checkbox" name="nombre" value="ON" checked>nombre&nbsp;
				<input type="checkbox" name="apellidos" value="ON" checked>apellidos&nbsp;
				<input type="checkbox" name="localidad" value="OFF"> localidad&nbsp;
				<input type="checkbox" name="provincia" value="OFF">provincia&nbsp;
				<input type="checkbox" name="mail" value="ON">mail</p>
				<p align="center">&nbsp;</p>
				<p align="center"><input type="submit" value="Buscar" name="enviar"></p>
			</form>
			</td></tr>
		</table>
		<p align="center"> <a href='listado.php'>Listado de contactos</a> | <a href='agenda_add.php'>A�adir contacto</a></p>
		</div>
	<?PHP
	}
?>