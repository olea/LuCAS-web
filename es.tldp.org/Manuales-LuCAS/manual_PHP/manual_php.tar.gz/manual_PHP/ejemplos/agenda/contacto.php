<HTML>
<BODY bgcolor="#0080C0">
<H3 align="center"><font color=\"#FFFF00\">Datos disponibles</H2>

<?PHP

	require("agenda.lib.php");

	$link = conectar_BD("agenda", "localhost", "root", "");
	
	if (!$link) {
		echo "<h2>$error<h2>\n";
		exit;
	}

	if ($i) {
		$sql  = "SELECT * FROM agenda WHERE id=$i";
	} else {
		echo "<H2 align='center'>ERROR: Debe especificar un ID/h2>\n";
		exit;
	}

	

	$resultado = mysql_query($sql, $link);
	
	echo "<div align='center'>\n";
	echo "<table bgcolor='#99CCFF' border='2'>\n";
	echo "<tr><td>\n";
	echo "<table bgcolor='#99CCFF' border='0' width='400'>\n";
	

	while ($agenda = mysql_fetch_object($resultado)){
		$i = $agenda->id;
		echo "<tr>\n";
		echo "<td width='80'>Nombre:</td><td>&nbsp;<b>$agenda->nombre $agenda->apellidos</b></td>\n";
		echo "</tr>\n";
		echo "<tr>\n";
		echo "<td width='80'>Direcci�n:</td><td>&nbsp;<b>$agenda->direccion</b></td>\n";
		echo "</tr>\n";
		echo "<tr>\n";
		echo "<td width='80'>Localidad:</td><td>&nbsp;<b>$agenda->localidad</b></td>\n";
		echo "</tr>\n";
		echo "<tr>\n";
		echo "<td width='80'>Provincia:</td><td>&nbsp;<b>$agenda->provincia&nbsp;-&nbsp;$agenda->cp</b></td>\n";
		echo "</tr>\n";
		echo "<tr>\n";
		echo "<td width='80'>Telefono 1:</td><td>&nbsp;<b>$agenda->telefono1</b></td>\n";
		echo "</tr>\n";
		echo "<tr>\n";
		echo "<td width='80'>Telefono 2:</td><td>&nbsp;<b>$agenda->telefono2</b></td>\n";
		echo "</tr>\n";
		echo "<tr>\n";
		echo "<td width='80'>Fax:</td><td>&nbsp;<b>$agenda->fax</b></td>\n";
		echo "</tr>\n";
		echo "<tr>\n";
		echo "<td>E-mail:</td><td>&nbsp;<a href='mailto:$agenda->mail'><b>$agenda->mail</a></b></td>\n";
		echo "</tr>\n";
	}
	
	echo "</table>\n";
	echo "</td></tr>\n";
	echo "</table>\n";
	echo "<p><a href='borrar.php?i=$i'>Eliminar</a>&nbsp;|&nbsp;";
	echo "<a href='modificar.php?i=$i'>Modificar</a>&nbsp;|&nbsp;";
	echo "<a href='listado.php'>Listado de contactos</a>&nbsp;|&nbsp;";
	echo "<a href='agenda_add.php'>A�adir contacto</a>&nbsp;|&nbsp;";
	echo "<a href='buscar.php'>Buscar</a></p>\n";
	echo "</div>\n";

?>

</BODY>
</HTML>
