<?PHP
	
	$basedatos = "phorum";

	//conectamos con el servidor
	$link = @mysql_connect("localhost", "root", "");

	// comprobamos que hemos estabecido conexi�n en el servidor
	if (! $link){
		echo "<h2 align='center'>ERROR: Imposible establecer conecci�n con el servidor</h2>";
		exit;
	}

	// obtenemos una lista de las bases de datos del servidor
	$db = mysql_list_dbs();

	// vemos cuantas BD hay
	$num_bd = mysql_num_rows($db);
	
	//comprobamos si la BD que quermos crear exite ya
	$existe = "NO" ;
	for ($i=0; $i<$num_bd; $i++) {
		if (mysql_dbname($db, $i) == $basedatos) {
			$existe = "SI" ;
			break;
		}
	}

	// si no existe la creamos
	if ($existe == "NO") {
		/* manera 1 */
		if (! mysql_create_db($basedatos, $link)) {
			echo "<h2 align='center'>ERROR 1: Imposible crear base de datos</h2>";
			exit;
		}
		/* manera 2 
		if (! mysql_query("CREATE DATABASE $basedatos", $link)){
			echo "<h2 align='center'>ERROR2: Imposible crear base de datos</h2>";
			exit;
		} */
	}

	// craamos la tabla
	$sql  = "CREATE TABLE mensajes (";
    $sql .= "id_mensaje int(11) DEFAULT '0' NOT NULL auto_increment, ";
	$sql .= "id_phorum int(11) DEFAULT '0' NOT NULL, ";
	$sql .= "id_padre int(11) DEFAULT '0' NOT NULL, ";
    $sql .= "asunto varchar(255) NOT NULL, ";
	$sql .= "descripcion text NOT NULL, ";
	$sql .= "autor varchar(255), ";
	$sql .= "autor_mail varchar(255), ";
	$sql .= "autor_host varchar(255), ";
	$sql .= "fecha timestamp(14), ";
	$sql .= "num_hijos int(11) DEFAULT '0' NOT NULL, ";
	$sql .= "PRIMARY KEY (id_mensaje), ";
	$sql .= "KEY id_mensaje (id_mensaje, id_phorum, id_padre), ";
	$sql .= "UNIQUE id_mensaje_2 (id_mensaje) )";

	if (@mysql_db_query($basedatos, $sql, $link)) {
		echo "<h2 align='center'>La tabla se ha creado con �xito</h2>";
	} else {
		echo "<h2 align='center'>No se ha podido crear la tabla</h2>";
	}
	
?>

