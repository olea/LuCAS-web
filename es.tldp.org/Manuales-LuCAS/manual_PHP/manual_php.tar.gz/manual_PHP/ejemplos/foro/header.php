
<HTML>
<HEAD>
<TITLE> Foro de discusi�n </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="Jos� Antonio Rodr�guez Rivero">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="Foro de discusi�n">
<META content="text/html" http-equiv=Content-Type><LINK href="hojaEstilo.css" rel=stylesheet type=text/css>
</HEAD>

<BODY BGCOLOR="#99CCFF">

<h2 align="center">Foro de discusi�n</h2>