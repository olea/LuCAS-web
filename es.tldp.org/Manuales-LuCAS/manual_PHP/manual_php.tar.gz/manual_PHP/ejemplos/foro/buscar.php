<?PHP

	require ("lib.inc.php");
	require ("header.php");

	function verEncontrados ($id_Foro, $buscar, $inicio = 0) {

		global $cfg_colorFondoTitEnc, $cfg_colorLetraTitEnc;
		global $cfg_colorLetraAsuntoEnc, $cfg_colorLetraTxtEnc;
		global $link, $cfg_tamanno_TB, $cfg_alinListaMsg ;
		global $cfg_colorTitListaMsg, $cfg_MaxFilas, $cfg_colorFondoEnlaces;

		$gif_enlace = "msg.gif";
		
		$nuevo = "<a href='foro.php?f=$id_Foro&n=1'>Nuevo mensaje</a>";
		$lista = "<a href='foro.php?f=$id_Foro'>Lista de mensajes</a>";

		// cabecera
		echo "<div align='$cfg_alinListaMsg'>\n";
		echo "<table width='$cfg_tamanno_TB' border = '0' cellspacing='0' cellpadding='3'>\n";
		echo "<tr>\n";
		echo "<td align='right' height='25'>$nuevo | $lista</td>\n";
		echo "</tr>\n";
		echo "<tr>\n";
		echo "<td bgcolor='$cfg_colorFondoTitEnc' height='25'><font color='$cfg_colorLetraTitEnc'>";
		echo "<b>Lista de mensajes encontrados</b></font></td>\n";
		echo "<tr>\n";
		echo "</table>\n";
		
		$sql  = "SELECT id_mensaje, id_phorum, asunto, fecha, descripcion ";
		$sql .= "FROM mensajes ";
		$sql .= "WHERE id_phorum = $id_Foro AND ";
		$sql .= "(asunto LIKE \"%$buscar%\" OR descripcion LIKE \"%$buscar%\") ";
		$sql .= "ORDER BY fecha DESC ";
		$sql .= "LIMIT $inicio, " . strval($cfg_MaxFilas+1) ;

		$numfilas = 0;

		$id_consulta = @mysql_query($sql, $link);

		while ($msg = @mysql_fetch_array($id_consulta)) {
	
			//para evitar mostrar el reg. que le hemos a�adido
			if ($numfilas == $cfg_MaxFilas) {
				break;
			} else {
				$numfilas++;
			}

			$hijos = $msg["num_hijos"];

			$dia = fecha($msg["fecha"], 1);
			$texto = substr($msg["descripcion"], 0, 200);

			echo "<table width='$cfg_tamanno_TB' border = '0' bgcolor='".asig_color()."'>";
			echo "<tr>\n";
			echo "<td><a href='$enlace'>";
			echo "<img src='$gif_enlace' border ='0'></a></td>\n";
			echo "<td width='100%'><font color='$cfg_colorLetraAsuntoEnc'><b>";
			echo $msg["asunto"]."</b></font></td>\n";
			echo "</tr>\n";
			echo "<tr>\n";
			echo "<td>&nbsp;</td>\n";
			echo "<td><font color='$cfg_colorLetraTxtEnc'>$texto<br><br>";
			echo "<font size='-1'>fecha: $dia</font></td>";
			echo "</tr>\n";
			echo "</table>\n";

		}
		
		//enviamos enlaces siguiente - anterior
		$numfilas = @mysql_num_rows($id_consulta);
		if ($numfilas > $cfg_MaxFilas) {
			// quedan m�s registros
			$siguiente  = "<a href='buscar.php?f=$id_Foro&b=$buscar&d=";
			$siguiente .= ($inicio+$cfg_MaxFilas) . "'>siguientes</a>" ;

		} elseif ($numfilas == 0) {
			echo "<h3 align='center'>No hay m�s mensajes</h3>\n";
		}

		if ($inicio >= $cfg_MaxFilas) {
			$anterior  = "<a href='buscar.php?f=$id_Foro&b=$buscar&d=";
			$anterior .= ($inicio-$cfg_MaxFilas) . "'>anteriores</a>" ;
		} 
		
		if (isset($anterior) AND isset($siguiente)) {
			$enlace = $anterior . " | " . $siguiente;
		} elseif (isset($anterior)) {
			$enlace = $anterior;
		} elseif (isset($siguiente)) {
			$enlace = $siguiente;
		}
		if (isset($enlace)){
			echo "<table width='$cfg_tamanno_TB' border = '0' bgcolor='$cfg_colorFondoEnlaces'>";
			echo "<tr>\n";
			echo "<td align='center'>$enlace</a></td>\n";
			echo "</tr>\n";
			echo "</table>\n";
		}

		echo "</div>\n";
		
	}//FIN verEncontrados

	function formBuscar(){
		
		global $foro;
		global $cfg_colorForm, $cfg_alinForm, $cfg_colorLetraForm, $cfg_colorFondoTitForm, $cfg_colorLetraTitForm;
		
		if (!isset($foro)) $foro = 0;

		?>
			<p>&nbsp;</p>
			<div align="<?PHP echo $cfg_alinForm ?>">
			<form method="POST" action="<?PHP echo $PHP_SELF ?>" enctype="multipart/form-data">
			<table border="0" bgcolor="<?PHP echo $cfg_colorForm ?>" 
			align = "<?PHP echo $cfg_alinForm ?>" cellspacing="0" cellpadding="3" width="300">
			<tr>
			<td bgcolor='<?PHP echo $cfg_colorFondoTitForm ?>' height="25">
			<font color='<?PHP echo $cfg_colorLetraTitForm ?>'><b>Escriba la cadena a buscar</b></font></td>
			</tr>
			<tr>
			<td height="60 valign="middle""><p align="center">
			<input type="text" name="b" size="25" maxlength="25">&nbsp;&nbsp;
			<input type="submit" value="buscar" name="buscar"></p>
		    </td>
			</tr>
			</table>
			</form>
			
			<table width='<?PHP echo $cfg_tamanno_TB ?>' border = '0' cellspacing='0' cellpadding='3'>
			<tr>
			<td align='right' height='25'><a href='foro.php?f=<?PHP echo $foro?>&n=1'>Nuevo mensaje</a> | <a href='foro.php?f=<?PHP echo $foro?>'>Lista de mensajes</a></td>
			</tr>		
			</table>
	
			</div>
		<?PHP
	}//FIN formBuscar

//--------------------------------------------------------
	$errorBD = conectar_BD();
	if ($errorBD <> ""){
		echo "<h2 align='center'><u>ERROR</u></h2>\n";
		echo "<h2 align='center'>$errorBD</h2>\n";
		exit;
	}

	/* $d indica el primer reg. a mostrar
	si no se especifica $d o se inicia una 
	nueva b�squda, $d = 0 */
	if ((! isset($d)) OR $buscar) $d = 0;

	if (isset($b)) {
		verEncontrados ($foro, $b, $d);
		formBuscar();

	} else {
		formBuscar();
	}

	require ("footer.php");
?>