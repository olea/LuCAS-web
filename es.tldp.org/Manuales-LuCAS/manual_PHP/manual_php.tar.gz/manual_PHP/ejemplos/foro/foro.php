
<?PHP

	require ("lib.inc.php");

	require ("header.php");


	if (isset($p)) {
		$padre = $p;
	} else {
		$padre = 0;
	}

	if (isset($i)) {
		$mensaje = $i;
	} else {
		$mensaje = 0;
	}
		
	if (isset($d)) {
		$inicio = $d;
	} else {
		$inicio = 0;
	}
	
	if (isset($r)) {
		$responder = 1; //"SI"
	} else {
		$responder = 0; //"NO"
	}


	$errorBD = conectar_BD();
	if ($errorBD <> ""){
		echo "<h2 align='center'><u>ERROR</u></h2>\n";
		echo "<h2 align='center'>$errorBD</h2>\n";
		exit;
	}


	/* si hemos recibido datos del formulario los guardamos */
	if ($enviar) {
		//Si el mensaje no tiene asunto volvemos al formulario
		if ($asunto) {
			$ip = gethostbyaddr("$REMOTE_ADDR");

			/* almacenamos los datos en una tabla */
			$form = array("foro"=>$foro, "padre"=>$padre, "asunto"=>$asunto, "autor"=>$autor, "autorIP"=>$ip, "autorMail"=>$mail, "descripcion"=>$descripcion);
			
			// guardamos el mensaje
			$error = guardarMsg($form);
			
			/* si se ha producido alg�n error volvemos al formulario
			si todo ha ido vien mostramos el listado de mensajes */
			if ($errorBD <> ""){
				echo "<h2 align='center'><u>ERROR</u></h2>\n";
				echo "<h2 align='center'>$error</h2>\n";
				formMensaje();
			} else {
				$mensaje = 0;
				$padre = 0;			
				listaMensajes($foro, $padre, 0);
			}
		} else {
			formMensaje();
		}

	} elseif ($mensaje > 0) {	
		
		verMsg($mensaje);
		if ($responder == 1) {
			$asunto = $a;
			formMensaje();
		}
	
	} elseif ($n == 1) {
		formMensaje();

	} else {
		listaMensajes($foro, $padre, $inicio);

	}
	
	
	require ("footer.php");
	
?>