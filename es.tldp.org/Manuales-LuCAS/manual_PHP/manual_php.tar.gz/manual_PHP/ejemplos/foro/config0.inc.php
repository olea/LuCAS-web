<?PHP
	/* Fichero de configuraci�n */

	$cfg_servidor = "localhost";
	$cfg_usuario = "root";
	$cfg_password = "";
	$cfg_basedatos = "phorum";

	$link;
	$error;
	
	/* asignamos el n� de foro por defecto */
	$foro = 0;

	$padre;
	$mensaje;
	$responder;
	$hijos;
	$inicio;

	/* var. formulario */
	$autor;
	$mail;
	$asunto;
	$descripcion;


	/* tama�o de las tablas */
	$cfg_tamanno_TB = "90%";

	/* tama�o de las tablas en pixels */
	//$cfg_tamanno_TB = "500";

	
	/* Config. de la lista de mensajes */
	$cfg_colorFondoListMsg = array("#354785", "#495991", "#66CCFF", "#FFC4C4", "#FFFFCC");
	$cfg_colorLetraListMsg = "#FFFF00";
	$cfg_colorTitListaMsg = "#F0D515";
	$cfg_alinListaMsg = "center";
	
	/* N� de mensajes a mostrar por pantalla
	sin contar con las respuestas */
	$cfg_MaxFilas = 2;
	
	/* color del texto de los mensajes */
	$cfg_colorFondoTxtMsg = "#0066FF";
	$cfg_colorLetraTxtMsg= "#FFFF00";
	$cfg_colorFondoTitMsg = "#F0D515";
	$cfg_colorLetraTitMsg= "#000000";

	$cfg_alinMsg = "center";

	/* color del formulario */
	$cfg_colorFondoTitForm = "#F0D515";
	$cfg_colorLetraTitForm = "#000000";
	$cfg_colorForm = "#354785";
	$cfg_colorLetraForm = "#FFFFFF";
	$cfg_alinForm = "center";

	/* Color de la celda de los enlaces */
	$cfg_colorFondoEnlaces = "#00C192";

	/* color de la lista de encontrados */
	$cfg_colorFondoTitEnc = "#F0D515";
	$cfg_colorLetraTitEnc= "#000000";
	$cfg_colorLetraAsuntoEnc= "#FFFFFF";
	$cfg_colorLetraTxtEnc= "#FFFF00";
?>
