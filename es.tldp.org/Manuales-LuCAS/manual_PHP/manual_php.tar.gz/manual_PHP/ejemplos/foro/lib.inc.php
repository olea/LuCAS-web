<?PHP
	
	/* Buscamos el archivo de configuraci�n correspondiente
	al n� de foro, sino tomamos uno por defecto*/
	if (isset($f)) {
		require ("config".$f.".inc.php");
		$foro = $f;
	} else {
		echo "<h2 align='center'>ERROR: debe especificar un FORO</h2>";
		exit;
	}


	function conectar_BD() {
		global $cfg_servidor, $cfg_usuario, $cfg_password, $cfg_basedatos, $link, $error;
		$error = "";
		
		/* conectamos al servidor */
		$link = @mysql_connect($cfg_servidor, $cfg_usuario, $cfg_password);
		if ($link) {
			/* seleccionamos la base de datos */
			if (!@mysql_select_db($cfg_basedatos, $link)) {
				$error = "Imposible conectar con la base de datos -".$cfg_basedatos."-" ;
			}
		} else {
			$error = "Imposible establecer conecci�n con el servidor -".$cfg_servidor."-" ;
		}
		return $error;

	} //FIN function conectar_BD


//--------------------------------------------------------------------------------------------------//

	function guardarMsg($form) {
		global $link;

		$error = "";
		$num_hijos = 0;

		$sql  = "INSERT INTO mensajes ";
		$sql .= "VALUES ( 0, ".$form["foro"].", ".$form["padre"].", '".$form["asunto"]."', '" ;
		$sql .= $form["descripcion"]."', '".$form["autor"]."', '".$form["autorMail"]."', '";
		$sql .= $form["autorIP"]."', NOW(), $num_hijos)";

//		echo $sql:

		//A�adimos mensaje
		if (!mysql_query($sql, $link)) $error = mysql_error($link); //"Imposible a�adir Mensaje";
		echo $error;

		//Actualizamos el num. hijos del padre
		if ($form["padre"] > 0) {
			$consulta = mysql_query ("SELECT num_hijos FROM mensajes WHERE id_mensaje = ".$form["padre"], $link);
			while (list($hijos) = mysql_fetch_row($consulta)) {
	
				$sql = "UPDATE mensajes SET num_hijos=".($hijos + 1)." WHERE id_mensaje = ".$form["padre"];
				if (!mysql_query($sql, $link)) $error = mysql_error($link);
						echo $error;

			}
		}
		if ($error =="") {
			//verListaMsg();
		}else{
			echo $error;
		}

		return $error;

	} // function guardarMsg


//-------------------------------------------------------------------------------------------------//

	function verListaMsg ($id_Foro = 0, $id_Padre = 0, $init=0, $nivel=0) {

		global $link, $cfg_tamanno_TB, $cfg_alinListaMsg, $cfg_colorFondoListMsg, $cfg_colorLetraListMsg ;
		global $cfg_colorTitListaMsg, $cfg_MaxFilas, $cfg_colorFondoEnlaces;
	
		$numfilas = 0;

		$escala = 30;
		$gif_enlace = "msg.gif";

		$sql  = "SELECT id_mensaje, id_padre, id_phorum, asunto, fecha ";
		$sql .= "FROM mensajes ";
		$sql .= "WHERE id_phorum = $id_Foro AND id_padre = ". $id_Padre ." ";

		if ($nivel == 0) {
			$sql .= "ORDER BY fecha DESC ";
			if ($id_Padre == 0) {
				// a�adimos 1 para saber si hay mas mensajes
				$sql .= "LIMIT $init, ".strval($cfg_MaxFilas+1);
			}
		} else {
			$sql .= "ORDER BY fecha ASC";
		}

		$id_consulta = @mysql_query($sql, $link);

		while ($msg = @mysql_fetch_array($id_consulta)) {
			//para evitar mostrar el reg. que le hemos a�adido
			if ($numfilas == $cfg_MaxFilas AND $nivel ==0) {
				break;
			} else {
				$numfilas++;
			}

			$hijos = $msg["num_hijos"];

			$enlace  = $PHP_SEF."?f=".$msg["id_phorum"]."&i=".$msg["id_mensaje"];
			$enlace .= "&d=".$init;

			$dia = fecha($msg["fecha"], 1);

			echo "<div align='$cfg_alinListaMsg'>\n";
			echo "<table width='$cfg_tamanno_TB' border = '0' bgcolor='".asig_color()."' ";
			echo "cellpadding='2' cellspacing='0'>\n";
			echo "<tr>\n";

			if ($nivel > 0) {
				for ($i=1; $i<=$nivel; $i++) {		
						echo "<td width = '$escala'>";
					}
			}

			echo "<td width='1'>";
			echo "<a href='$enlace'>";
			echo "<img src='$gif_enlace' border ='0'></a></td>\n";
			echo "<td><font color='$cfg_colorLetraListMsg'>".$msg["asunto"]."</font></td>\n";
			echo "<td align='right'><font color='$cfg_colorLetraListMsg'>$dia</font></td>";
			echo "</tr>\n";
			echo "</table>\n";
			echo "</div>\n";

			//mostramos los hijos
			verListaMsg ($id_Foro, $msg["id_mensaje"], $init, $nivel+1 );
		}
			
		//Devolvemos 0 si NO quedan m�s mensajes por mostrar en nivel 0
		if ($nivel == 0) {
				$mas = 0 ;
				$numfilas = @mysql_num_rows($id_consulta);

				if ($numfilas > $cfg_MaxFilas) {
					//queden m�s registros
					$mas = 1 ;
				} elseif ($numfilas == 0) {
					echo "<h3 align='center'>No hay mensajes</h3>\n";
				}
		}
		return $mas;
		
	}//FIN verListaMsg
//-----------------------------------------------------------------------------------------------------//

	function listaMensajes($id_foro, $id_padre, $inicio = 0) {

		global $link, $cfg_tamanno_TB, $cfg_alinListaMsg, $cfg_colorFondoListMsg, $cfg_colorLetraListMsg ;
		global $cfg_colorTitListaMsg, $cfg_MaxFilas, $cfg_colorFondoEnlaces, $mensaje;
		
		$buscar = "<a href='buscar.php?f=$id_foro'>Buscar</a>";
		$nuevo = "<a href='foro.php?f=$id_foro&n=1'>Nuevo mensaje</a>";

		//enviamos la cabecera
		echo "<div align='$cfg_alinListaMsg'>\n";
		echo "<table width='$cfg_tamanno_TB' border = '0'";
		echo "cellpadding='4' cellspacing='0'>\n";
		echo "<tr>\n";
		echo "<td align='right' colspan='2' height='30'>$nuevo | $buscar</td>";
		echo "</tr>\n";
		echo "<tr>\n";
		echo "<td align='left' bgcolor='$cfg_colorTitListaMsg' ><b>Asunto<b></td>";
		echo "<td align='right' bgcolor='$cfg_colorTitListaMsg'><b>Fecha<b></td>";
		echo "</tr>\n";
		echo "</table>\n";
		echo "</div>\n";
		
		$mas = verListaMsg($id_foro, $id_padre, $inicio);

		//Sino estamos viendo un mensaje mandamos enlaces
		if ($mensaje == 0) {

			$enlaces = "";
			if ($mas) {
				 $enlaces .= "<a href='$PHP_SELF?f=$id_foro&d=".($inicio+$cfg_MaxFilas)."'>Mensajes anteriores</a>";
			}
			if ($inicio >= $cfg_MaxFilas) {
				if ($enlaces <> "") $enlaces .= " | ";
				$enlaces .= " <a href='$PHP_SELF?f=$id_foro&d=".($inicio-$cfg_MaxFilas)."'>Mensajes siguientes</a>";
			}

			echo "<div align='$cfg_alinListaMsg'>\n";
			echo "<table width='$cfg_tamanno_TB' border = '0' cellpadding='6' cellspacing='0'>\n";
			echo "<tr>\n";
			echo "<td align='center' bgcolor='$cfg_colorFondoEnlaces' >$enlaces</td>\n";
			echo "</tr>\n";
			echo "</table>\n";
			echo "</div>\n";
			echo "<br>";
		}

	} //FIN function listaMensajes



//-------------------------------------------------------------------------------------------------//

	function verMsg ($id){
		
		global $link, $cfg_tamanno_TB, $cfg_colorMsg, $cfg_alinMsg;
		global $cfg_colorFondoTxtMsg, $cfg_colorLetraTxtMsg, $cfg_colorFondoTitMsg;
		global $cfg_colorLetraTitMsg,  $cfg_colorFondoEnlaces, $ responder, $inicio;
				
		$sql  = "SELECT * ";
		$sql .= "FROM mensajes ";
		$sql .= "WHERE id_mensaje = $id";
		
		$id_consulta = @mysql_query($sql, $link);
		
		while ($msg = @mysql_fetch_array($id_consulta)) {

			$foro = $msg["id_phorum"];

			if (trim($msg["asunto"]) == "") {
				$asunto = "No Asunto";
			} else {
				$asunto = $msg["asunto"];
			}
			if ($msg["autor"] != "") {
				if ($msg["autor_mail"] != "") {
					$mail = $msg["autor_mail"];
					$autor = "<b>Autor: </b><a href='mailto:$mail'>".$msg["autor"]."</a>";
				} else {
					$mail = "";
					$autor = "<b>Autor: </b>".$msg["autor"] ;
				}
			} else {
				$autor = "";
			}
			
			$fecha = fecha($msg["fecha"]);
			$id = $msg["id_mensaje"];
			$respuesta = $PHP_SELF."?f=".$msg["id_phorum"]."&p=".$id."&i=".$id."&a=RE: ".$msg["asunto"]."&r=1";
			$nuevo = $PHP_SELF."?f=".$msg["id_phorum"]."&n=1";
			$lista = $PHP_SELF."?f=".$msg["id_phorum"]."&d=".$inicio;
			$buscar = "buscar.php?f=".$msg["id_phorum"];

			echo "<div align = '$cfg_alinMsg'>\n";
			echo "<table border='0' width='$cfg_tamanno_TB' ";
			echo "cellpadding='5' cellspacing='0'>\n";
			echo "<tr>\n";
			echo "<td bgcolor = '$cfg_colorFondoTitMsg' height='30'>";
			echo "<font color='$cfg_colorLetraTitMsg'>";
			echo "<b>$asunto </b></font></td>\n";
			echo "</tr>\n";
			echo "<tr>\n";
			echo "<td bgcolor = '$cfg_colorFondoTxtMsg'><font color='$cfg_colorLetraTxtMsg'<br>";
			echo $autor."<br>\n";
			echo "<b>Enviado: </b>".$fecha."<br>\n";	
			echo "<br>".nl2br($msg["descripcion"])."<br></font>\n";
			echo "</td>\n";
			echo "</tr>\n";
			echo "<tr>\n";
			echo "<td bgcolor='$cfg_colorFondoEnlaces'>\n";
			echo "<a href='$respuesta'>Responder a este mensaje</a> | ";
			echo "<a href='$nuevo'>Nuevo mensaje</a> | ";
			echo "<a href='$lista'>Lista de mensajes</a> | ";
			echo "<a href='$buscar'>Buscar</a>";
			echo "</td>\n";
			echo "</tr>\n";
			echo "</table>\n";
			echo "</div>\n";
			echo "<br>";

			$hijos = $msg["num_hijos"];
		}
		

		if ($hijos > 0 AND !$responder) ListaMensajes($foro, $id, $inicio);

	} // FIN function verMsg

	
	function fecha($date, $tipo = 0){
		//$semana = array ("Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "S�bado", "Domingo");
		

		$nombremes = array (1=>"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre");

                $day = substr($timestamp, 6, 2); 
                $monthstamp = substr($timestamp, 4, 2); 

		
		
		$anno = substr($date, 0, 4);
		$mes = substr($date, 4, 2);
		$nombmes = $nombremes[intval($mes)];
		$dia = substr($date, 6, 2);
		$hora = substr($date, 8, 2).":".substr($date, 10, 2);

		if ($tipo == 0 ) {
			$fecha = $dia." de ".$nombmes." de ".$anno.", a las ".$hora;
		} elseif ($tipo == 1) {
			$fecha = $dia."-".$mes."-".substr($anno,2,2)."  ".$hora;
		}

		return $fecha;

	}

	
//----------------------------------------------------------------------------------------------//
	
	function restarDias($date) {
	
		global $cfg_dias;

		if (isset($date)) {
			$anno = substr($date, 0, 4);
			$mes = substr($date, 4, 2);
			$dia = substr($date, 6, 2);
			$hora = substr($date, 8, 2);
			$min = substr($date, 10, 2);
			$seg = substr($date,12,2);
		} else {
			list($hora, $min, $seg, $dia, $mes, $anno) = explode( " ", date( "H i s d m Y"));
		}
		
		$d =  $dia - $cfg_dias;

		$fecha = date("YmdHmi",mktime($hora, $min, $seg, $mes, $d, $anno))."<br>";

		return $fecha;
	
	} // function restarDias

	
	function asig_color() {
		global $cfg_colorFondoListMsg;
		static $x;
		if (!isset($x)) $x=1;
		if ($x==1) {
			$x = 0;
		} else {
			$x = 1;
		}
		return$ cfg_colorFondoListMsg[$x];

	} // FIN function asig_color




//-----------------------------------------------------------------------------------------------------------//

	function formMensaje(){
		
		global $padre, $foro, $autor, $mail, $asunto, $descripcion, $responder;
		global $cfg_colorForm, $cfg_alinForm, $cfg_colorLetraForm, $cfg_colorFondoTitForm, $cfg_colorLetraTitForm;
		if (!isset($foro)) $foro = 0;
		if (!isset($padre)) $padre = 0 ;
		
		if ($responder) {
			$titulo = "Responder";
		} else {
			$titulo = "Nuevo mensaje";
		}

		?>
			<p>&nbsp;</p>
			<div align="<?PHP echo $cfg_alinForm ?>">
			<form method="POST" action="<?PHP echo $PHP_SELF ?>" enctype="multipart/form-data">

			<input type="hidden" name="foro" value="<?PHP echo $foro; ?>">						
			<input type="hidden" name="padre" value="<?PHP echo $padre; ?>">

			<table border="0" bgcolor="<?PHP echo $cfg_colorForm ?>" 
			align = "<?PHP echo $cfg_alinForm ?>" cellspacing="0" cellpadding="3">
			<tr>
			<td bgcolor='<?PHP echo $cfg_colorFondoTitForm ?>' colspan ="2" height="30">
				<font color='<?PHP echo $cfg_colorLetraTitForm ?>'><b><?PHP echo $titulo ?></b></font></td>
			</tr>
			<tr>
			<td><font color="<?PHP echo $cfg_colorLetraForm ?>">Autor</font></td>
		    <td >
			<p><input type="text" name="autor" size="50" maxlength="255" value='<?PHP echo $autor ?>'></p>
		    </td>
			</tr>
			<tr>
		    <td><font color="<?PHP echo $cfg_colorLetraForm ?>">Correo-e</font></td>
		    <td>
		    <p><input type="text" name="mail" size="50" maxlength="255" value='<?PHP echo $mail ?>'></p>
		    </td>
			</tr>
			<tr>
			<td><font color="<?PHP echo $cfg_colorLetraForm ?>">Asunto</font></td>
		    <td>
		    <p><input type="text" name="asunto" size="50" maxlength="255" value='<?PHP echo $asunto ?>'></p>
		    </td>
			</tr>
			<tr>
		    <td><font color="<?PHP echo $cfg_colorLetraForm ?>">Descripci�n</font></td>
		    <td></td>
			</tr>
			<tr>
		    <td colspan="2"><textarea rows="10" name="descripcion" cols="75"><?PHP echo $descripcion ?></textarea></td>
			</tr>
			<tr>
		    <td colspan="2">&nbsp;
		    <p align="center"><input type="submit" value="Enviar" name="enviar"></p>
		    </td>
			</tr>
			</table>
			</form>
			<table width='<?PHP echo $cfg_tamanno_TB ?>' border = '0' cellspacing='0' cellpadding='3'>
			<tr>
			<td align='right' height='25'><a href='foro.php?f=<?PHP echo $foro?>'>Lista de mensajes</a>
			&nbsp;|&nbsp;<a href='buscar.php?f=<?PHP echo $foro?>&n=1'>Buscar</a></td>
			</tr>		
			</table
			</div>
			
		<?PHP
	
	} //FIN formulario

// FUNCIONES DE B�SQUEDA

	
?>
