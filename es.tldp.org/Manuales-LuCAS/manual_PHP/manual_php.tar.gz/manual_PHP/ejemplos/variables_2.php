<html>     
<body>
<?PHP
	define ("CONSTANTE", "Hola Mundo");
	printf (CONSTANTE);
?>
</body>
</html>
