<html>
<body>
<?php
	$link = mysql_connect("localhost", "nobody");
	mysql_select_db("mydb", $link);
	$result = mysql_query("SELECT * FROM agenda", $link);
	echo "Nombre: ".mysql_result($result, 0, "nombre")."<br>";
	echo "Direcci�n: ".mysql_result($result, 0, "direccion")."<br>";
	echo "Tel�fono :".mysql_result($result, 0, "telefono")."<br>";
	echo "E-Mail :".mysql_result($result, 0, "email")."<br>";
?>
</body>
</html>
