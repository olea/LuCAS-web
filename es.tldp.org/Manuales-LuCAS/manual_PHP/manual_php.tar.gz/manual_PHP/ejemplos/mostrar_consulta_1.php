<html>
<body>
<p>Consulta con mysql_fetch_row()</p>
<?php
	$link = mysql_connect("localhost", "nobody");
	mysql_select_db("mydb", $link);
	$result = mysql_query("SELECT nombre, email FROM agenda", $link);
	echo "<table border = '1'> \n";
	echo "<tr> \n";
	echo "<td><b>Nombre</b></td> \n";
	echo "<td><b>E-Mail</b></td> \n";
	echo "</tr> \n";
	while ($row = mysql_fetch_row($result)){
		echo "<tr> \n";
		echo "<td>$row[0]</td> \n";
		echo "<td>$row[1]</td> \n";
		echo "</tr> \n";
	}
	echo "</table> \n";
?>
</body>
</html>


