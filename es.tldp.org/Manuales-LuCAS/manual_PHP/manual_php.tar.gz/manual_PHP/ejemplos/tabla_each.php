<html>
<body>

<?PHP
	$visitas = array("lunes"=>200, "martes"=>186, "mi�rcoles"=>190, "jueves"=>175);
	reset($visitas);
	while (list($clave, $valor) = each($visitas)) {
		//$clave = key($valor);
		echo "el d�a $clave ha tenido $valor visitas<BR>";
	}
?>


</body>
</html>