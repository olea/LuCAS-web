<html>
<body>

<?PHP
	
	$basedatos = "agenda";

	//conectamos con el servidor
	$link = @mysql_connect("", "phpciber", "laleche");

	// comprobamos que hemos estabecido conexi�n en el servidor
	if (! $link){
		echo "<h2 align='center'>ERROR: Imposible establecer conecci�n con el servidor</h2>";
		exit;
	}

	// obtenemos una lista de las bases de datos del servidor
	$db = mysql_list_dbs();

	// vemos cuantas BD hay
	$num_bd = mysql_num_rows($db);
	
	//comprobamos si la BD que quermos crear exite ya
	$existe = "NO" ;
	for ($i=0; $i<$num_bd; $i++) {
		if (mysql_dbname($db, $i) == $basedatos) {
			$existe = "SI" ;
			break;
		}
	}

	// si no existe la creamos
	if ($existe == "NO") {
		/* manera 1 */
		if (! mysql_create_db($basedatos, $link)) {
			echo "<h2 align='center'>ERROR 1: Imposible crear base de datos</h2>";
			echo mysql_error();
			exit;
		} 
		/* manera 2 
		if (! mysql_query("CREATE DATABASE $basedatos", $link)){
			echo "<h2 align='center'>ERROR2: Imposible crear base de datos</h2>";
			exit;
		} */
	}

	// craamos la tabla
	$sql  = "CREATE TABLE agenda (";
    $sql .= "id int(11) DEFAULT '0' NOT NULL auto_increment, ";
	$sql .= "nombre varchar(20) NOT NULL,, ";
	$sql .= "apellidos varchar(35), ";
    $sql .= "direccion varchar(50), ";
	$sql .= "localidad varchar(25), ";
	$sql .= "provincia varchar(15), ";
	$sql .= "cp varchar(5), ";
	$sql .= "telefono1 varchar(15), ";
	$sql .= "telefono2 varchar(15), ";
	$sql .= "fax varchar(15), ";
	$sql .= "mail varchar(50), ";
	$sql .= "PRIMARY KEY (id), ";
	$sql .= "KEY id (id), ";
	$sql .= "UNIQUE id_2 (id) )";

	if (@mysql_db_query($basedatos, $sql, $link)) {
		echo "<h2 align='center'>La tabla se ha creado con �xito</h2>";
	} else {
		echo "<h2 align='center'>No se ha podido crear la tabla</h2>";
	}
	
?>

</body>
</html>