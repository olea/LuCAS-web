<?PHP
	
	if (! $id) exit ;

	// conectamos al servidor 
	if (! $link = mysql_connect("localhost", "root","")) {
		exit;
	}
	$sql = "SELECT id_seccion, img_type, img_data FROM seccion WHERE id_seccion=$id";


	$res = mysql_db_query("tienda", $sql, $link);
	$type = mysql_result($res, 0, "img_type");
	$data = mysql_result($res, 0, "img_data");

	header ('content-type: $type');
	echo $data;


?>