<html>
<body>

<?PHP
	$calendario[] = array(1, "enero", 31);
	$calendario[] = array(2, "febrero", 28);
	$calendario[] = array(3, "marzo", 31);
	$calendario[] = array(4, "abril", 30);
	$calendario[] = array(5, "mayo", 31);

	$c = count($calendario);
	while (list($clave, $valor) = each($calendario)) {
		$cadena = $valor[1];
		$cadena .= " es el mes n�mero " . $valor[0];
		$cadena .= " y tiene " . $valor[2] . " d�as<BR>\n";
		echo $cadena;
	}
?>

</body>
</html>