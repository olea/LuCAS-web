<html>
<body>
<?PHP
	$myvar = "SEVILLA \n";
	$Myvar = "MADRID \n";
	
	//Esto imprimir� SEVILLA
	echo $myvar;
	
	//Esto imprimir� MADRID
	ECHO $Myvar;
?>
</body>
</html>