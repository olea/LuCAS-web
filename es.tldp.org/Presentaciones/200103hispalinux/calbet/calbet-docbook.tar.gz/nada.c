#define MODULE
#include <linux/module.h>
