#!/usr/bin/perl -w


open(FIL,"< $ARGV[0]");

while (<FIL>) {
    if ($_=~ /\&lt;\&lt;/) {
	print "<code>\n";
    } elsif ($_=~ /\@/) {
	print "</code>\n";
    } else {
	print $_;
    }
}

close(FIL);
