#define MODULE
#include <linux/module.h>

int init_module(void) {
  printk("<1>Hola mundo\n");
  return 0;
}

void cleanup_module(void) {
  printk("<1>Adios mundo cruel\n");
}
