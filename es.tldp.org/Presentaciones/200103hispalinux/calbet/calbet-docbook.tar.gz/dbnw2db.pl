#!/usr/bin/perl -w


open(FIL,"< $ARGV[0]");

$list_flag=0;
$paracont=0;
while (<FIL>) {
    if ($_=~ /\&lt;\&lt;/ && $list_flag == 0) {
	print "<programlisting>\n";
	print $_;
	$list_flag=1;
    } elsif ($_=~ /\@/ && $list_flag) {
	print "</programlisting>\n";
	$list_flag=0;
    } elsif ($_=~ /<author>/) {
	print $_;
	$lee=<FIL>;
	@name=split(' ',$lee);
	print "<firstname>",$name[0],"</firstname>\n";
	print "<surname>",$name[1],"</surname>\n";
	$lee=<FIL>;
	print "<affiliation>\n<orgname>",$lee,"</orgname>\n";
	$lee=<FIL>;
	print "<address><email>",$lee,"</email></address>\n";
	print "</affiliation>\n";
    } elsif ($_ =~ /<para>/) {
	$lee=<FIL>;
	if ( $lee =~ /\/home\/xcalbet\/arti/ ) {
	    $fileref=$lee;
	    $fileref=~s/\/home\/xcalbet\/arti\/hispalinux4\///;
	    print $_;
	    print $fileref;
	} elsif ($lee =~ /\\/) {
	    while (1) {
		$lee=<FIL>;
		if ($lee =~ /<\/para>/) {
		    last;
		}
	    }
	} elsif ($lee =~ /\&lt;\&lt;/ && $list_flag == 0) {
	    print $_;
	    print "<programlisting>\n";
	    print $lee;
	    $list_flag=1;
	} else {
	    $paracont++;
	    if ($paracont == 1) {
		print "<abstract>\n";
		print $_;
		print $lee;
	    } elsif ($paracont == 5) {
		print $_;
		print $lee;
		$lee=<FIL>;
		print $lee;
		print "</abstract>\n";
	    } else {
		print $_;
		print $lee;
	    }
	}
    } else {
	print $_;
    }
}

close(FIL);
