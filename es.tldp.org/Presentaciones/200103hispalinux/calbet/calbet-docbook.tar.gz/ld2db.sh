#!/bin/bash

jade -t sgml -d '/usr/lib/sgml/stylesheet/dsssl/sgmltools/ld2db.dsl#db' $1