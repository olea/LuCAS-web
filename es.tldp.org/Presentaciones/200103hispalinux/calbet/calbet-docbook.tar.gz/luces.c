
#include <stdio.h>
#include <unistd.h>


int main() { 
  unsigned char byte,dummy;
  FILE * PUERTOPAR;

  /* Abrimos el dispositivo puertopar */
  PUERTOPAR=fopen("/dev/puertopar","w");
  /* Eliminamos el buffer del fichero */
  setvbuf(PUERTOPAR,&dummy,_IONBF,1);

  /* Iniciamos la variable a uno */
  byte=1;

  /* Realizamos el bucle indefinido */
  while (1) { 
    /* Escribimos al puerto paralelo */
    /* para encender un LED */
    printf("Byte vale %d\n",byte);
    fwrite(&byte,1,1,PUERTOPAR);
    sleep(1);

    /* Actualizamos el valor de byte */
    byte<<=1;
    if (byte == 0) byte = 1;
  }

  fclose(PUERTOPAR);

}

