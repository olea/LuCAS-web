%internal_labels = ();
1;		# hack in case there are no entries

%internal_labels = ();
1;		# hack in case there are no entries

%internal_labels = ();
1;		# hack in case there are no entries

%internal_labels = ();
1;		# hack in case there are no entries

$internal_labels{"l2h-1"} = "/node4.html";
$internal_labels{"l2h-2"} = "/node4.html";
$internal_labels{"l2h-3"} = "/node4.html";
$internal_labels{"l2h-4"} = "/node6.html";
$internal_labels{"l2h-5"} = "/node6.html";
$internal_labels{"l2h-6"} = "/node8.html";
$internal_labels{"l2h-7"} = "/node8.html";
$internal_labels{"l2h-8"} = "/node8.html";
$internal_labels{"l2h-9"} = "/node8.html";
$internal_labels{"l2h-10"} = "/node8.html";
$internal_labels{"l2h-11"} = "/node8.html";
$internal_labels{"l2h-12"} = "/node8.html";
$internal_labels{"l2h-13"} = "/node8.html";
$internal_labels{"l2h-14"} = "/node8.html";
$internal_labels{"l2h-15"} = "/node8.html";
$internal_labels{"l2h-16"} = "/node9.html";
$internal_labels{"l2h-17"} = "/node9.html";
$internal_labels{"l2h-18"} = "/node9.html";
$internal_labels{"l2h-19"} = "/node9.html";
$internal_labels{"l2h-20"} = "/node11.html";
$internal_labels{"l2h-21"} = "/node13.html";
