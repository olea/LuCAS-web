# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate images original text with physical files.


$key = q/{inline}mboxbullet{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="31" ALIGN="BOTTOM" BORDER="0"
 SRC="img2.gif"
 ALT="$\mbox{$\bullet$}$">|; 

$key = q/{displaymath}mathbfX=left(arraycccx_11&x_12&ldotsx_21&x_22&ldotsvdots&vdots&ddotsarrayright){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="342" HEIGHT="126"
 SRC="img8.gif"
 ALT="\begin{displaymath}\mathbf{X}=
\left(
\begin{array}{ccc}
x_{11} & x_{12} & \ldot...
..._{22} & \ldots \\\\
\vdots & \vdots & \ddots
\end{array}\right)
\end{displaymath}">|; 

$key = q/{inline}mboxmathbf{circ}{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="31" ALIGN="BOTTOM" BORDER="0"
 SRC="img1.gif"
 ALT="$\mbox{$\mathbf{\circ}$}$">|; 

$key = q/{displaymath}x^2geq0qquadtextrmparatodoxinmathbfR{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="438" HEIGHT="57"
 SRC="img3.gif"
 ALT="\begin{displaymath}
x^{2} \geq 0\qquad
\textrm{para todo }x\in\mathbf{R}
\end{displaymath}">|; 

$key = q/{inline}sqrtx^2+y^2{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="153" HEIGHT="89" ALIGN="MIDDLE" BORDER="0"
 SRC="img5.gif"
 ALT="$\sqrt{x^{2}+y^{2}}$">|; 

$key = q/{inline}underbracea+b+cdots+z{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="234" HEIGHT="62" ALIGN="MIDDLE" BORDER="0"
 SRC="img7.gif"
 ALT="$\underbrace{a+b+\cdots+z}$">|; 

$key = q/{inline}overlinem+n{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="104" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="img6.gif"
 ALT="$\overline{m+n}$">|; 

$key = q/{inline}alpha,Delta{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="78" HEIGHT="62" ALIGN="MIDDLE" BORDER="0"
 SRC="img4.gif"
 ALT="$\alpha,\Delta$">|; 

$key = q/{indisplay}displaystylecosx=1-fracx^22!+{indisplay}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="282" HEIGHT="113" ALIGN="MIDDLE" BORDER="0"
 SRC="img9.gif"
 ALT="$\displaystyle { \cos x = 1
- \frac{x^{2}}{2!} +{} }$">|; 

$key = q/{indisplay}displaystyle+fracx^44!-fracx^66!+cdots{indisplay}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="266" HEIGHT="113" ALIGN="MIDDLE" BORDER="0"
 SRC="img10.gif"
 ALT="$\displaystyle {}+\frac{x^{4}}{4!}
- \frac{x^{6}}{6!}+{}\cdots$">|; 

1;

