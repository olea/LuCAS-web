# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate internals original text with physical files.


$key = q/form1/;
$ref_files{$key} = "$dir".q|transparencias.html|; 
$noresave{$key} = "$nosave";

1;

