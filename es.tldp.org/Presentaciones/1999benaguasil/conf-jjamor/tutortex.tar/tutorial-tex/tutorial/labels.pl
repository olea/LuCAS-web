# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate labels original text with physical files.


$key = q/cite_texbook/;
$external_labels{$key} = "$URL/" . q|node29.html|; 
$noresave{$key} = "$nosave";

$key = q/fig-planinic/;
$external_labels{$key} = "$URL/" . q|node6.html|; 
$noresave{$key} = "$nosave";

$key = q/fig-caja/;
$external_labels{$key} = "$URL/" . q|node23.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_manual/;
$external_labels{$key} = "$URL/" . q|node29.html|; 
$noresave{$key} = "$nosave";

$key = q/fig-nopiense/;
$external_labels{$key} = "$URL/" . q|node22.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_tbautista/;
$external_labels{$key} = "$URL/" . q|node29.html|; 
$noresave{$key} = "$nosave";

$key = q/soportespanol/;
$external_labels{$key} = "$URL/" . q|node26.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_usrguide/;
$external_labels{$key} = "$URL/" . q|node29.html|; 
$noresave{$key} = "$nosave";

1;

