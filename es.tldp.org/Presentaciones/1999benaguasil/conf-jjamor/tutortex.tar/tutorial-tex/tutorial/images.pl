# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate images original text with physical files.


$key = q/{inline}mboxbullet{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="img1.gif"
 ALT="$\mbox{$\bullet$}$">|; 

$key = q/{figure}hrulemedskipfootnotesizepreform<verbatim_mark>verbatim1#preformnormalsizevspace-1exhrule{figure}FSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="556" HEIGHT="629"
 SRC="img2.gif"
 ALT="\begin{figure}\hrule\medskip\footnotesize
\begin{tex2html_preform}\begin{verbati...
...t}\end{verbatim}\end{tex2html_preform}\normalsize\vspace{-1ex}\hrule\end{figure}">|; 

$key = q/{figure}vspace5cm<comment_mark>{figure}FSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="2" HEIGHT="1265"
 SRC="img3.gif"
 ALT="\begin{figure}\vspace{5cm} %
\end{figure}">|; 

$key = q/{figure}psfigfigure=caja.ps,width=5cm{figure}FSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="223" HEIGHT="143"
 SRC="img4.gif"
 ALT="\begin{figure}\psfig{figure=caja.ps,width=5cm}\end{figure}">|; 

1;

