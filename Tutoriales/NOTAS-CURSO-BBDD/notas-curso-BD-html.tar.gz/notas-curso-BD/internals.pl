# LaTeX2HTML 2K.1beta (1.47)
# Associate internals original text with physical files.


$key = q/sec:dump/;
$ref_files{$key} = "$dir".q|node201.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:est/;
$ref_files{$key} = "$dir".q|node134.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:espacio/;
$ref_files{$key} = "$dir".q|node43.html|; 
$noresave{$key} = "$nosave";

$key = q/cap:normalizacion/;
$ref_files{$key} = "$dir".q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/sss:bloq/;
$ref_files{$key} = "$dir".q|node179.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Date1993/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:connectdb/;
$ref_files{$key} = "$dir".q|node204.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Ullman1999/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/alg:oper/;
$ref_files{$key} = "$dir".q|node25.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:def/;
$ref_files{$key} = "$dir".q|node3.html|; 
$noresave{$key} = "$nosave";

$key = q/ssec:lang/;
$ref_files{$key} = "$dir".q|node175.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:ext/;
$ref_files{$key} = "$dir".q|node134.html|; 
$noresave{$key} = "$nosave";

$key = q/alg1/;
$ref_files{$key} = "$dir".q|node163.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:blob/;
$ref_files{$key} = "$dir".q|node207.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:tipmap/;
$ref_files{$key} = "$dir".q|node208.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:catalogo/;
$ref_files{$key} = "$dir".q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/ssec:relprop/;
$ref_files{$key} = "$dir".q|node24.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:attribute/;
$ref_files{$key} = "$dir".q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:database/;
$ref_files{$key} = "$dir".q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:tabinter/;
$ref_files{$key} = "$dir".q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:acc/;
$ref_files{$key} = "$dir".q|node160.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Silberschatz/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:class/;
$ref_files{$key} = "$dir".q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:trans/;
$ref_files{$key} = "$dir".q|node163.html|; 
$noresave{$key} = "$nosave";

$key = q/idx:buffers/;
$ref_files{$key} = "$dir".q|node215.html|; 
$noresave{$key} = "$nosave";

1;

