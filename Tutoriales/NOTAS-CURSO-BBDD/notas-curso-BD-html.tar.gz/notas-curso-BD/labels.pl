# LaTeX2HTML 2K.1beta (1.47)
# Associate labels original text with physical files.


$key = q/sec:dump/;
$external_labels{$key} = "$URL/" . q|node201.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:est/;
$external_labels{$key} = "$URL/" . q|node134.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:espacio/;
$external_labels{$key} = "$URL/" . q|node43.html|; 
$noresave{$key} = "$nosave";

$key = q/cap:normalizacion/;
$external_labels{$key} = "$URL/" . q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/sss:bloq/;
$external_labels{$key} = "$URL/" . q|node179.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Date1993/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:connectdb/;
$external_labels{$key} = "$URL/" . q|node204.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Ullman1999/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/alg:oper/;
$external_labels{$key} = "$URL/" . q|node25.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:def/;
$external_labels{$key} = "$URL/" . q|node3.html|; 
$noresave{$key} = "$nosave";

$key = q/ssec:lang/;
$external_labels{$key} = "$URL/" . q|node175.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:ext/;
$external_labels{$key} = "$URL/" . q|node134.html|; 
$noresave{$key} = "$nosave";

$key = q/alg1/;
$external_labels{$key} = "$URL/" . q|node163.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:blob/;
$external_labels{$key} = "$URL/" . q|node207.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:tipmap/;
$external_labels{$key} = "$URL/" . q|node208.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:catalogo/;
$external_labels{$key} = "$URL/" . q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/ssec:relprop/;
$external_labels{$key} = "$URL/" . q|node24.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:attribute/;
$external_labels{$key} = "$URL/" . q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:database/;
$external_labels{$key} = "$URL/" . q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:tabinter/;
$external_labels{$key} = "$URL/" . q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:acc/;
$external_labels{$key} = "$URL/" . q|node160.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Silberschatz/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:class/;
$external_labels{$key} = "$URL/" . q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:trans/;
$external_labels{$key} = "$URL/" . q|node163.html|; 
$noresave{$key} = "$nosave";

$key = q/idx:buffers/;
$external_labels{$key} = "$URL/" . q|node215.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2K.1beta (1.47)
# labels from external_latex_labels array.


$key = q/sec:dump/;
$external_latex_labels{$key} = q|13.3|; 
$noresave{$key} = "$nosave";

$key = q/tab:est/;
$external_latex_labels{$key} = q|8.1|; 
$noresave{$key} = "$nosave";

$key = q/sec:espacio/;
$external_latex_labels{$key} = q|4.4|; 
$noresave{$key} = "$nosave";

$key = q/cap:normalizacion/;
$external_latex_labels{$key} = q|4|; 
$noresave{$key} = "$nosave";

$key = q/sss:bloq/;
$external_latex_labels{$key} = q|10.3.2|; 
$noresave{$key} = "$nosave";

$key = q/tab:connectdb/;
$external_latex_labels{$key} = q|14.1|; 
$noresave{$key} = "$nosave";

$key = q/alg:oper/;
$external_latex_labels{$key} = q|3.3.5|; 
$noresave{$key} = "$nosave";

$key = q/sec:def/;
$external_latex_labels{$key} = q|1.1|; 
$noresave{$key} = "$nosave";

$key = q/ssec:lang/;
$external_latex_labels{$key} = q|10.1|; 
$noresave{$key} = "$nosave";

$key = q/tab:ext/;
$external_latex_labels{$key} = q|8.2|; 
$noresave{$key} = "$nosave";

$key = q/alg1/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

$key = q/sec:blob/;
$external_latex_labels{$key} = q|14.1.1|; 
$noresave{$key} = "$nosave";

$key = q/tab:tipmap/;
$external_latex_labels{$key} = q|14.2|; 
$noresave{$key} = "$nosave";

$key = q/tab:catalogo/;
$external_latex_labels{$key} = q|9.1|; 
$noresave{$key} = "$nosave";

$key = q/ssec:relprop/;
$external_latex_labels{$key} = q|3.3.4|; 
$noresave{$key} = "$nosave";

$key = q/tab:attribute/;
$external_latex_labels{$key} = q|9.4|; 
$noresave{$key} = "$nosave";

$key = q/tab:database/;
$external_latex_labels{$key} = q|9.2|; 
$noresave{$key} = "$nosave";

$key = q/sec:tabinter/;
$external_latex_labels{$key} = q|9.1|; 
$noresave{$key} = "$nosave";

$key = q/sec:acc/;
$external_latex_labels{$key} = q|8.10|; 
$noresave{$key} = "$nosave";

$key = q/tab:class/;
$external_latex_labels{$key} = q|9.3|; 
$noresave{$key} = "$nosave";

$key = q/sec:trans/;
$external_latex_labels{$key} = q|8.11|; 
$noresave{$key} = "$nosave";

$key = q/idx:buffers/;
$external_latex_labels{$key} = q|15.1|; 
$noresave{$key} = "$nosave";

1;

