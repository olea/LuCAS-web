# LaTeX2HTML 2K.1beta (1.47)
# Associate images original text with physical files.


$key = q/A_{i};MSF=1.6;AAT/;
$cached_env_img{$key} = q|13#13|; 

$key = q/{algorithm}%latex2htmlidmarker1009{caption{Transacci�nsegura.}{algorithmic{[1]WHOMMITSTATEENDELSESTATEABORTSTATEROLLBACKENDIFENDWHILEalgorithmic{{algorithm};AAT/;
$cached_env_img{$key} = q|91#91|; 

$key = q/{displaymath}Cruz(langleH,Rrangle,langleH',Srangle)longmapstolangle(H,H'),R'rangle{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|51#51|; 

$key = q/{displaymath}Dif(langleH,Rrangle,langleH,Srangle)longmapstolangleH,R-Srangle{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|39#39|; 

$key = q/<=;MSF=1.6;AAT/;
$cached_env_img{$key} = q|93#93|; 

$key = q/R_1;MSF=1.6;AAT/;
$cached_env_img{$key} = q|85#85|; 

$key = q/R.XleftarrowR.Y;MSF=1.6;AAT/;
$cached_env_img{$key} = q|77#77|; 

$key = q/>;MSF=1.6;AAT/;
$cached_env_img{$key} = q|90#90|; 

$key = q/C;MSF=1.6;AAT/;
$cached_env_img{$key} = q|62#62|; 

$key = q/H;MSF=1.6;AAT/;
$cached_env_img{$key} = q|16#16|; 

$key = q/{displaymath}Rest(langleH,Rrangle,Condiciacuteon)longmapstolangleH,R_{(Cond)}rangle{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|53#53|; 

$key = q/A_j;MSF=1.6;AAT/;
$cached_env_img{$key} = q|19#19|; 

$key = q/R;MSF=1.6;AAT/;
$cached_env_img{$key} = q|1#1|; 

$key = q/R_{1};MSF=1.6;AAT/;
$cached_env_img{$key} = q|12#12|; 

$key = q/{displaymath}H={(A_1:D_1),(A_2:D_2),ldots,(A_n:D_n)}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|18#18|; 

$key = q/p;MSF=1.6;AAT/;
$cached_env_img{$key} = q|86#86|; 

$key = q/{displaymath}Alumnos=left{<comment_mark>20matrix{{{bf{No_Cta,}&{{bf{Nombre,}&{{blezcr8105765-9,&Magnolia,&Avalos,&Vacuteazquezcr}right}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|6#6|; 

$key = q/atributo:valor;MSF=1.6;AAT/;
$cached_env_img{$key} = q|24#24|; 

$key = q/D_j;MSF=1.6;AAT/;
$cached_env_img{$key} = q|20#20|; 

$key = q/{displaymath}IntercolonRtimesRlongmapstoR{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|36#36|; 

$key = q/(i;=;1,2,ldots,m);MSF=1.6;AAT/;
$cached_env_img{$key} = q|26#26|; 

$key = q/{(B_{n+1}:D_{n+1}),ldots,(B_m:D_m)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|71#71|; 

$key = q/{(A_1:v_{i1}),(A_2:v_{i2}),dots,(A_n:v_{in})|A_jinD_j,v_{ij}inD_j};MSF=1.6;AAT/;
$cached_env_img{$key} = q|4#4|; 

$key = q/{displaymath}D_{atributo}={valor_{1},valor_{2},ldots,valor_{m}}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|7#7|; 

$key = q/X_1;MSF=1.6;AAT/;
$cached_env_img{$key} = q|82#82|; 

$key = q/<0||getg_nargs;MSF=1.6;AAT/;
$cached_env_img{$key} = q|94#94|; 

$key = q/E;MSF=1.6;AAT/;
$cached_env_img{$key} = q|59#59|; 

$key = q/A_{i}neqA_{j};MSF=1.6;AAT/;
$cached_env_img{$key} = q|22#22|; 

$key = q/{(A_{1}:D_{1});MSF=1.6;AAT/;
$cached_env_img{$key} = q|40#40|; 

$key = q/R.AleftarrowR.C;MSF=1.6;AAT/;
$cached_env_img{$key} = q|80#80|; 

$key = q/n+m-j;MSF=1.6;AAT/;
$cached_env_img{$key} = q|64#64|; 

$key = q/T;MSF=1.6;AAT/;
$cached_env_img{$key} = q|17#17|; 

$key = q/Y;MSF=1.6;AAT/;
$cached_env_img{$key} = q|75#75|; 

$key = q/R=langleH,Trangle;MSF=1.6;AAT/;
$cached_env_img{$key} = q|15#15|; 

$key = q/{displaymath}Div(langle(HX,HY),Rrangle,langleHX,Srangle)longmapstolangleHY,RslashSrangle{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|73#73|; 

$key = q/B=b_1;MSF=1.6;AAT/;
$cached_env_img{$key} = q|54#54|; 

$key = q/m;MSF=1.6;AAT/;
$cached_env_img{$key} = q|27#27|; 

$key = q/{A=D};MSF=1.6;AAT/;
$cached_env_img{$key} = q|67#67|; 

$key = q/ldots;MSF=1.6;AAT/;
$cached_env_img{$key} = q|42#42|; 

$key = q/j=1,2,ldots,n;MSF=1.6;AAT/;
$cached_env_img{$key} = q|21#21|; 

$key = q/theta;MSF=1.6;AAT/;
$cached_env_img{$key} = q|66#66|; 

$key = q/[0..10];MSF=1.6;AAT/;
$cached_env_img{$key} = q|81#81|; 

$key = q/{item}item[{{bullet{}]{{tt{dollarfout}Descriptordearchivo,dondeescribe.item[{{buasenHTML.item[{{bullet{}]{{tt{dollarcaption}Cadena,piedetabla.{item};MSF=1.6;AAT/;
$cached_env_img{$key} = q|97#97|; 

$key = q/V_{ij}inD_{j};MSF=1.6;AAT/;
$cached_env_img{$key} = q|29#29|; 

$key = q/{item}item[{{bullet{}]PGRES_INV_WRITEParaescrituraitem[{{bullet{}]PGRES_INV_READtem[{{bullet{}]PGRES_INV_ARCHIVEParaseralmacenadaenunhist�rico{item};MSF=1.6;AAT/;
$cached_env_img{$key} = q|98#98|; 

$key = q/D_T={D_1,D_2,...,D_n};MSF=1.6;AAT/;
$cached_env_img{$key} = q|2#2|; 

$key = q/=;MSF=1.6;AAT/;
$cached_env_img{$key} = q|101#101|; 

$key = q/bullet;MSF=1.6;AAT/;
$cached_env_img{$key} = q|32#32|; 

$key = q/(A_{n}:D_{n});MSF=1.6;AAT/;
$cached_env_img{$key} = q|47#47|; 

$key = q/B;MSF=1.6;AAT/;
$cached_env_img{$key} = q|61#61|; 

$key = q/C={(A_1:D_1),(A_2:D_2),...,(A_n:D_n)|D_jinD_T,A_jinD_j};MSF=1.6;AAT/;
$cached_env_img{$key} = q|3#3|; 

$key = q/{(B_{1}:D_{1});MSF=1.6;AAT/;
$cached_env_img{$key} = q|44#44|; 

$key = q/R.BleftarrowR.C;MSF=1.6;AAT/;
$cached_env_img{$key} = q|79#79|; 

$key = q/{(A_1:D_1),(A_2:D_2),ldots,(A_n:D_n),(B_{n+1}:D_{n+1}),ldots,(B_m:D_m)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|68#68|; 

$key = q/Q;MSF=1.6;AAT/;
$cached_env_img{$key} = q|9#9|; 

$key = q/ineqj;MSF=1.6;AAT/;
$cached_env_img{$key} = q|23#23|; 

$key = q/j;MSF=1.6;AAT/;
$cached_env_img{$key} = q|65#65|; 

$key = q/t;MSF=1.6;AAT/;
$cached_env_img{$key} = q|31#31|; 

$key = q/{displaymath}CruzcolonRtimesRlongmapstoR{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|50#50|; 

$key = q/(A_{2}:D_{2});MSF=1.6;AAT/;
$cached_env_img{$key} = q|41#41|; 

$key = q/{displaymath}Proy(langleH,Rrangle,{atrib_{1},atrib{2},ldots,atrib_{m}})longmapstolangleH',R_{(atribs)}rangle{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|56#56|; 

$key = q/{item}item[{{bullet{}]{{tt{PGRES_EMPTY_QUERY}item[{{bullet{}]{{tt{PGRES_COMMAND_t{PGRES_NONFATAL_ERROR}item[{{bullet{}]{{tt{PGRES_FATAL_ERROR}{item};MSF=1.6;AAT/;
$cached_env_img{$key} = q|96#96|; 

$key = q/p==9,s=0;MSF=1.6;AAT/;
$cached_env_img{$key} = q|89#89|; 

$key = q/{displaymath}Uniacuteon(langleH,Rrangle,langleH,Srangle)longmapstolangleH,RcupSrangle{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|34#34|; 

$key = q/R_2;MSF=1.6;AAT/;
$cached_env_img{$key} = q|84#84|; 

$key = q/(A_{n}:D_{n})};MSF=1.6;AAT/;
$cached_env_img{$key} = q|43#43|; 

$key = q/slash;MSF=1.6;AAT/;
$cached_env_img{$key} = q|99#99|; 

$key = q/D;MSF=1.6;AAT/;
$cached_env_img{$key} = q|11#11|; 

$key = q/{displaymath}Inter(langleH,Rrangle,langleH,Srangle)longmapstolangleH,RcapSrangle{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|37#37|; 

$key = q/{displaymath}T_i={(A_{i1}:V_{i1}),(A_{i2}:V_{i2}),ldots,(A_{in}:V_{in})}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|25#25|; 

$key = q/m-n;MSF=1.6;AAT/;
$cached_env_img{$key} = q|70#70|; 

$key = q/{displaymath}DifcolonRtimesRlongmapstoR{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|38#38|; 

$key = q/S;MSF=1.6;AAT/;
$cached_env_img{$key} = q|35#35|; 

$key = q/R.AleftarrowR.B;MSF=1.6;AAT/;
$cached_env_img{$key} = q|78#78|; 

$key = q/X;MSF=1.6;AAT/;
$cached_env_img{$key} = q|76#76|; 

$key = q/p<=9,s=0;MSF=1.6;AAT/;
$cached_env_img{$key} = q|88#88|; 

$key = q/(B_{1}:D_{1});MSF=1.6;AAT/;
$cached_env_img{$key} = q|48#48|; 

$key = q/{displaymath}D_{No_Cta}=left{8315677-7,8409695-9,ldots,8759452-6right}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|8#8|; 

$key = q/p,q;MSF=1.6;AAT/;
$cached_env_img{$key} = q|74#74|; 

$key = q/(B_{2}:D_{2});MSF=1.6;AAT/;
$cached_env_img{$key} = q|45#45|; 

$key = q/>=;MSF=1.6;AAT/;
$cached_env_img{$key} = q|92#92|; 

$key = q/{displaymath}thetaUniacuteoncolonR_1timesR_2times(Condiciacuteon)longmapstoR{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|57#57|; 

$key = q/{(A_1:D_1),(A_2:D_2),ldots,(A_n:D_n)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|69#69|; 

$key = q/(B_{m}:D_{m})};MSF=1.6;AAT/;
$cached_env_img{$key} = q|46#46|; 

$key = q/A_{ij}=A_{j};MSF=1.6;AAT/;
$cached_env_img{$key} = q|28#28|; 

$key = q/{displaymath}DivcolonRtimesRlongmapstoR{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|72#72|; 

$key = q/X_2;MSF=1.6;AAT/;
$cached_env_img{$key} = q|83#83|; 

$key = q/{displaymath}Relaciacuteon={atributo_{1},atributo_{2},ldots,atributo_{n}}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|5#5|; 

$key = q/{displaymath}RestcolonRtimesCondiciacuteonlongmapstoR{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|52#52|; 

$key = q/<;MSF=1.6;AAT/;
$cached_env_img{$key} = q|100#100|; 

$key = q/A;MSF=1.6;AAT/;
$cached_env_img{$key} = q|10#10|; 

$key = q/F;MSF=1.6;AAT/;
$cached_env_img{$key} = q|60#60|; 

$key = q/{displaymath}ProycolonRtimes(atrib_{1},atrib{2},ldots,atrib_{m})longmapstoR{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|55#55|; 

$key = q/-1;MSF=1.6;AAT/;
$cached_env_img{$key} = q|95#95|; 

$key = q/p,s;MSF=1.6;AAT/;
$cached_env_img{$key} = q|87#87|; 

$key = q/{displaymath}thetaUniacuteon(langleH,Rrangle,langleH',Srangle,{Condiciacuteon})colonlongmapstolangleH'',R'Srangle{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|58#58|; 

$key = q/A_ineqB_j;MSF=1.6;AAT/;
$cached_env_img{$key} = q|49#49|; 

$key = q/n;MSF=1.6;AAT/;
$cached_env_img{$key} = q|30#30|; 

$key = q/s;MSF=1.6;AAT/;
$cached_env_img{$key} = q|63#63|; 

$key = q/R_{2};MSF=1.6;AAT/;
$cached_env_img{$key} = q|14#14|; 

$key = q/{displaymath}UniacuteoncolonRtimesRlongmapstoR{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|33#33|; 

1;

