# LaTeX2HTML 2K.1beta (1.62)
# Associate labels original text with physical files.


$key = q/sec:comandos-texto/;
$external_labels{$key} = "$URL/" . q|node43.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:cambios-visual/;
$external_labels{$key} = "$URL/" . q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:vimrc/;
$external_labels{$key} = "$URL/" . q|node136.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:cmd-set/;
$external_labels{$key} = "$URL/" . q|node18.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:movsimples/;
$external_labels{$key} = "$URL/" . q|node25.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:marcas/;
$external_labels{$key} = "$URL/" . q|node39.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:objtexto/;
$external_labels{$key} = "$URL/" . q|node20.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:visual/;
$external_labels{$key} = "$URL/" . q|node21.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:next/;
$external_labels{$key} = "$URL/" . q|node106.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:saltos-linea/;
$external_labels{$key} = "$URL/" . q|node61.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:rango/;
$external_labels{$key} = "$URL/" . q|node22.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:nombteclas/;
$external_labels{$key} = "$URL/" . q|node142.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:apendice/;
$external_labels{$key} = "$URL/" . q|node140.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-ambito/;
$external_labels{$key} = "$URL/" . q|node19.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2K.1beta (1.62)
# labels from external_latex_labels array.


$key = q/sec:cmd-set/;
$external_latex_labels{$key} = q|2.2.3|; 
$noresave{$key} = "$nosave";

$key = q/sec:objtexto/;
$external_latex_labels{$key} = q|2.3.1|; 
$noresave{$key} = "$nosave";

$key = q/sec:visual/;
$external_latex_labels{$key} = q|2.3.2|; 
$noresave{$key} = "$nosave";

$key = q/sec-ambito/;
$external_latex_labels{$key} = q|2.3|; 
$noresave{$key} = "$nosave";

1;

