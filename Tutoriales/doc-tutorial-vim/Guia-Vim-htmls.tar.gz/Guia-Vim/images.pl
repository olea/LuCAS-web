# LaTeX2HTML 2K.1beta (1.62)
# Associate images original text with physical files.


$key = q/longleftrightarrow;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="$\longleftrightarrow$">|; 

$key = q/-;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="$-$">|; 

$key = q/+;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="$+$">|; 

$key = q/=;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="$=$">|; 

$key = q/fbox{parminipage{[h]{11cm}parsmallmdseriesparCopyright(c)2004Joaqu�nAtazL�pez.bici�ntitulada``GNUFreeDocumentationLicense'').parminipage{par};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="522" HEIGHT="289" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\fbox{
\par
\begin{minipage}[h]{11cm}
\par
\small\mdseries
\par
Copyright (c) 20...
... secci�n titulada \lq\lq GNU
Free Documentation License'').
\par
\end{minipage}\par
}">|; 

$key = q/*,+,-,slash;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="69" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="$*, +, -, /$">|; 

1;

