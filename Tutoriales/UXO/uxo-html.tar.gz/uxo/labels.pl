# LaTeX2HTML 2K.1beta (1.47)
# Associate labels original text with physical files.


$key = q/confshell/;
$external_labels{$key} = "$URL/" . q|node24.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:variables/;
$external_labels{$key} = "$URL/" . q|node23.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:atributos/;
$external_labels{$key} = "$URL/" . q|node10.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:grep/;
$external_labels{$key} = "$URL/" . q|node10.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:varshell/;
$external_labels{$key} = "$URL/" . q|node23.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:expreg/;
$external_labels{$key} = "$URL/" . q|node25.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:batch/;
$external_labels{$key} = "$URL/" . q|node22.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:test/;
$external_labels{$key} = "$URL/" . q|node28.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2K.1beta (1.47)
# labels from external_latex_labels array.


1;

