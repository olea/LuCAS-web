# LaTeX2HTML 2K.1beta (1.47)
# Associate images original text with physical files.


$key = q/{table}{ixptpreform{<verbatim_mark>verbatim14#preform{}{{{table};LFS=12;AAT/;
$cached_env_img{$key} = q|1#1|; 

$key = q/c;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|3#3|; 

$key = q/ab;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|4#4|; 

$key = q/d;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|5#5|; 

$key = q/[A-Z][a-z]+;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|2#2|; 

$key = q/cd,cabd,cababd,cabababd;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|6#6|; 

1;

