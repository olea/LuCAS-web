#ifndef MAKETEXI_H
#define MAKETEXI_H

extern int multiwordheaders;

int write_texinfo(char *filename);

#endif
