#ifndef MAKECHM_H
#define MAKECHM_H

int write_chm(char *filename);

#endif
